                                                                               
                        
                                                                           

                                            
                       
                  
                        
                                       
                 

                                                                                  

                                                                                                          
                                                                         
                                                                             


                                                                               
                                                                               
                                                         
                                                                                                                     
                                                                                                  
                                                                             
DarkRP.disabledDefaults["modules"] = {
    ["afk"]              = true,
    ["chatsounds"]       = true,
    ["events"]           = false,
    ["fpp"]              = false,
    ["f1menu"]           = true,
    ["f4menu"]           = true,
    ["hitmenu"]          = false,
    ["hud"]              = true,
    ["hungermod"]        = true,
    ["playerscale"]      = false,
    ["sleep"]            = false,
    ["fadmin"]           = true,
    ["animations"]       = false,
    ["chatindicator"]    = true,
}

                                                                               
                                                            

                                                                                            
                                                                                                                
                                                                  
                                                                             
DarkRP.disabledDefaults["jobs"] = {
    ["chief"]     = false,
    ["citizen"]   = false,
    ["cook"]      = false, 
    ["cp"]        = false,
    ["gangster"]  = false,
    ["gundealer"] = false,
    ["hobo"]      = false,
    ["mayor"]     = false,
    ["medic"]     = false,
    ["mobboss"]   = false,
}

                                                                               
                     
                                                                             
DarkRP.disabledDefaults["shipments"] = {
    ["AK47"]         = false,
    ["Desert eagle"] = false,
    ["Fiveseven"]    = false,
    ["Glock"]        = false,
    ["M4"]           = false,
    ["Mac 10"]       = false,
    ["MP5"]          = false,
    ["P228"]         = false,
    ["Pump shotgun"] = false,
    ["Sniper rifle"] = false,
}

                                                                               
        
                                                                             
DarkRP.disabledDefaults["entities"] = {
    ["Drug lab"]      = true,
    ["Gun lab"]       = true,
    ["Money printer"] = true,
    ["Microwave"]     = true, 
    ["Tip Jar"]       = true,
}

                                                                               
        
                                             
                                                                                                               
                                                                             
DarkRP.disabledDefaults["vehicles"] = {

}

                                                                               
    
                                                                            
                                                                             
DarkRP.disabledDefaults["food"] = {
    ["Banana"]           = false,
    ["Bunch of bananas"] = false,
    ["Melon"]            = false,
    ["Glass bottle"]     = false,
    ["Pop can"]          = false,
    ["Plastic bottle"]   = false,
    ["Milk"]             = false,
    ["Bottle 1"]         = false,
    ["Bottle 2"]         = false,
    ["Bottle 3"]         = false,
    ["Orange"]           = false,
}

                                                                               
           
                                                                             
DarkRP.disabledDefaults["doorgroups"] = {
    ["Cops and Mayor only"] = false,
    ["Gundealer only"]      = false,
}


                                                                               
            
                                                                             
DarkRP.disabledDefaults["ammo"] = {
    ["Pistol ammo"]  = false,
    ["Rifle ammo"]   = false,
    ["Shotgun ammo"] = false,
}

                                                                               
       
                                                                             
DarkRP.disabledDefaults["agendas"] = {
    ["Gangster's agenda"] = false,
    ["Police agenda"] = false,
}

                                                                               
                          
                                                              
                                                                             
DarkRP.disabledDefaults["groupchat"] = {
    [1] = false, 
    [2] = false, 
    [3] = false, 
}

                                                                               
                    
                      
                                                                             
DarkRP.disabledDefaults["hitmen"] = {
    ["mobboss"] = false,
}

                                                                               
             
                                                                                  
                           
                                                                             
DarkRP.disabledDefaults["demotegroups"] = {
    ["Cops"]      = false,
    ["Gangsters"] = false,
}

                                                                               
           

                                                                             
                                                                         
                                                                             
DarkRP.disabledDefaults["workarounds"] = {
    ["os.date() Windows crash"]                      = false,
    ["SkidCheck"]                                    = false,
    ["nil SteamID64 and AccountID local server fix"] = false,
    ["Error on edict limit"]                         = false,
    ["Durgz witty sayings"]                          = false,
    ["ULX /me command"]                              = false,
    ["gm_save"]                                      = false,
    ["rp_downtown_v4c_v2 rooftop spawn"]             = false,
    ["White flashbang flashes"]                      = false,
    ["APAnti"]                                       = false,
    ["Wire field generator exploit fix"]             = false,
    ["Door tool class fix"]                          = false,
    ["Constraint crash exploit fix"]                 = false,
    ["Deprecated console commands"]                  = false,
    ["disable CAC"]                                  = false,
}
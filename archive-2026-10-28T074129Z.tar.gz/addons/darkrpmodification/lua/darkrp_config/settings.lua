                                                                             
                       
                                                                             

                                                                         

        
                                                                                                                   
                                                                                                              
                                                                             


    
                
                     
  


GM.Config.voice3D                       = true

GM.Config.AdminsCopWeapons              = false

GM.Config.adminBypassJobRestrictions    = true

GM.Config.allowActs                     = false

GM.Config.allowjobswitch                = false

GM.Config.allowrpnames                  = true

GM.Config.allowsprays                   = false

GM.Config.allowvehicleowning            = true

GM.Config.allowvnocollide               = false

GM.Config.alltalk                       = false

GM.Config.antimultirun                  = true

GM.Config.autovehiclelock               = false

GM.Config.babygod                       = true

GM.Config.canforcedooropen              = true

GM.Config.chatsounds                    = false

GM.Config.chiefjailpos                  = true

GM.Config.cit_propertytax               = false

GM.Config.copscanunfreeze               = true

GM.Config.copscanunweld                 = false

GM.Config.cpcanarrestcp                 = true

GM.Config.currencyLeft                  = false

GM.Config.customjobs                    = false

GM.Config.customspawns                  = true

GM.Config.deathblack                    = false

GM.Config.showdeaths                    = false

GM.Config.deadtalk                      = true

GM.Config.deadvoice                     = true

GM.Config.deathpov                      = false

GM.Config.decalcleaner                  = false

GM.Config.disallowClientsideScripts     = false

GM.Config.doorwarrants                  = true

GM.Config.dropmoneyondeath              = false

GM.Config.droppocketarrest              = false

GM.Config.droppocketdeath               = true

GM.Config.dropweapondeath               = false

GM.Config.dropspawnedweapons            = false

GM.Config.dynamicvoice                  = true

GM.Config.earthquakes                   = false

GM.Config.enablebuypistol               = true

GM.Config.enforceplayermodel            = true

GM.Config.globalshow                    = false

GM.Config.ironshoot                     = true

GM.Config.showjob                       = true

GM.Config.letters                       = false

GM.Config.license                       = false

GM.Config.lockdown                      = true

GM.Config.lockpickfading                = true

GM.Config.logging                       = true

GM.Config.lottery                       = false

GM.Config.showname                      = false

GM.Config.showhealth                    = false

GM.Config.needwantedforarrest           = false

GM.Config.noguns                        = false

GM.Config.norespawn                     = false

GM.Config.keepPickedUp                  = false

GM.Config.instantjob                    = false

GM.Config.npcarrest                     = true

GM.Config.ooc                           = true

GM.Config.propertytax                   = false

GM.Config.proppaying                    = false

GM.Config.propspawning                  = true

GM.Config.removeclassitems              = true

GM.Config.removeondisconnect            = true

GM.Config.respawninjail                 = true

GM.Config.restrictallteams              = false

GM.Config.restrictbuypistol             = false

GM.Config.restrictdrop                  = false

GM.Config.revokeLicenseOnJobChange      = true

GM.Config.shouldResetLaws               = false

GM.Config.strictsuicide                 = false

GM.Config.telefromjail                  = true

GM.Config.teletojail                    = true

GM.Config.unlockdoorsonstart            = false

GM.Config.voiceradius                   = true

GM.Config.wallettax                     = false

GM.Config.wantedrespawn                 = false

GM.Config.wantedsuicide                 = false

GM.Config.realisticfalldamage           = true

GM.Config.printeroverheat               = true

GM.Config.weaponCheckerHideDefault      = true

GM.Config.weaponCheckerHideNoLicense    = false

    
              
  

GM.Config.adminnpcs                     = 2

GM.Config.adminsents                    = 2

GM.Config.adminvehicles                 = 2

GM.Config.adminweapons                  = 1

GM.Config.arrestspeed                   = 120

GM.Config.babygodtime                   = 5


GM.Config.chatsoundsdelay               = 5

GM.Config.deathfee                      = 30

GM.Config.decaltimer                    = 120

GM.Config.demotetime                    = 120

GM.Config.doorcost                      = 3000000000

GM.Config.entremovedelay                = 0

GM.Config.gunlabweapon                  = "weapon_p2282"

GM.Config.jailtimer                     = 120

GM.Config.lockdowndelay                 = 120

GM.Config.maxadvertbillboards           = 3

GM.Config.maxCheques                    = 5

GM.Config.maxdoors                      = 20

GM.Config.maxdrugs                      = 2

GM.Config.maxfoods                      = 2

GM.Config.maxfooditems                  = 20

GM.Config.maxlawboards                  = 2

GM.Config.maxletters                    = 10

GM.Config.maxlotterycost                = 250

GM.Config.maxvehicles                   = 5

GM.Config.microwavefoodcost             = 30

GM.Config.minlotterycost                = 30

GM.Config.moneyRemoveTime               = 600

GM.Config.mprintamount                  = 250

GM.Config.normalsalary                  = 45

GM.Config.npckillpay                    = 10

GM.Config.paydelay                      = 600

GM.Config.pocketitems                   = 10

GM.Config.pricecap                      = 500

GM.Config.pricemin                      = 50

GM.Config.propcost                      = 10

GM.Config.quakechance                   = 4000

GM.Config.respawntime                   = 1

GM.Config.changejobtime                 = 10

GM.Config.runspeed                      = 240

GM.Config.runspeedcp                    = 255

GM.Config.searchtime                    = 30

GM.Config.ShipmentSpamTime              = 3

GM.Config.shipmentspawntime             = 10

GM.Config.startinghealth                = 100

GM.Config.startingmoney                 = 500



GM.Config.stunstickdamage               = 1000

GM.Config.vehiclecost                   = 40

GM.Config.wallettaxmax                  = 5

GM.Config.wallettaxmin                  = 1

GM.Config.wallettaxtime                 = 600

GM.Config.wantedtime                    = 120

GM.Config.walkspeed                     = 160

GM.Config.falldamagedamper              = 15

GM.Config.falldamageamount              = 10

GM.Config.printeroverheatchance         = 22

GM.Config.printerreward                 = 950

                                                                               
                      
                                               
                                                                             
GM.Config.talkDistance    = 250
GM.Config.whisperDistance = 90
GM.Config.yellDistance    = 550
GM.Config.meDistance      = 250
GM.Config.voiceDistance   = 550

                                                                               
              
                                                                             



GM.Config.MoneyClass = "spawned_money"

GM.Config.moneyModel = "models/props/cs_assault/money.mdl"


GM.Config.lockdownsound = "npc/overwatch/cityvoice/f_confirmcivilstatus_1_spkr.wav"


GM.Config.DarkRPSkin = "DarkRP"
GM.Config.currency = "¥"
GM.Config.currencyThousandSeparator = ","
GM.Config.chatCommandPrefix = "/"
GM.Config.F1MenuHelpPage = "https://darkrp.miraheze.org/wiki/Main_Page"
GM.Config.F1MenuHelpPageTitle = "DarkRP Wiki"


GM.Config.notificationSound = "buttons/lightswitch2.wav"


GM.Config.DefaultPlayerGroups = {
    ["STEAM_0:0:00000000"] = "superadmin",
    ["STEAM_0:0:11111111"] = "admin",
}


GM.Config.DisabledCustomModules = {
       ["hudreplacement"] = false,
       ["extraf4tab"] = false,
}


GM.Config.DisallowDrop = {
    ["arrest_stick"] = true,
    ["door_ram"] = true,
    ["gmod_camera"] = true,
    ["gmod_tool"] = true,
    ["keys"] = true,
    ["lockpick"] = true,
    ["med_kit"] = true,
    ["pocket"] = true,
    ["stunstick"] = true,
    ["unarrest_stick"] = true,
    ["weapon_keypadchecker"] = true,
    ["weapon_physcannon"] = true,
    ["weapon_physgun"] = true,
    ["weaponchecker"] = true,
}


GM.Config.DefaultWeapons = {
    "keys",
}






GM.Config.CategoryOverride = {
    jobs = {
        ["Citizen"]                             = "Citizens",
        ["Hobo"]                                = "Citizens",
        ["Gun Dealer"]                          = "Citizens",
        ["Medic"]                               = "Citizens",
        ["Civil Protection"]                    = "Civil Protection",
        ["Gangster"]                            = "Gangsters",
        ["Mob boss"]                            = "Gangsters",
        ["Civil Protection Chief"]              = "Civil Protection",
        ["Mayor"]                               = "Civil Protection",
    },
    entities = {
        ["Drug lab"]                            = "Other",
        ["Money printer"]                       = "Other",
        ["Gun lab"]                             = "Other",

    },
    shipments = {
        ["AK47"]                                = "Rifles",
        ["MP5"]                                 = "Rifles",
        ["M4"]                                  = "Rifles",
        ["Mac 10"]                              = "Other",
        ["Pump shotgun"]                        = "Shotguns",
        ["Sniper rifle"]                        = "Snipers",

    },
    weapons = {
        ["Desert eagle"]                        = "Pistols",
        ["Fiveseven"]                           = "Pistols",
        ["Glock"]                               = "Pistols",
        ["P228"]                                = "Pistols",
    },
    vehicles = {}, 
    ammo = {
        ["Pistol ammo"]                         = "Other",
        ["Shotgun ammo"]                        = "Other",
        ["Rifle ammo"]                          = "Other",
    },
}


GM.Config.AdminWeapons = {
    "keys",
}


GM.Config.DefaultLaws = {
    "Do not attack other citizens except in self-defence.",
    "Do not steal or break into people's homes.",
    "Money printers/drugs are illegal.",
}

GM.Config.PocketBlacklist = {
    ["fadmin_jail"] = true,
    ["meteor"] = true,
    ["door"] = true,
    ["func_"] = true,
    ["player"] = true,
    ["beam"] = true,
    ["worldspawn"] = true,
    ["env_"] = true,
    ["path_"] = true,
    ["prop_physics"] = true,
    ["money_printer"] = true,
    ["gunlab"] = true,
    ["prop_dynamic"] = true,
    ["prop_vehicle_prisoner_pod"] = true,
    ["keypad_wire"] = true,
    ["gmod_button"] = true,
    ["gmod_rtcameraprop"] = true,
    ["gmod_cameraprop"] = true,
    ["gmod_dynamite"] = true,
    ["gmod_thruster"] = true,
    ["gmod_light"] = true,
    ["gmod_lamp"] = true,
    ["gmod_emitter"] = true,
}






GM.Config.noStripWeapons = {

}




GM.Config.preventClassItemRemoval = {
    ["gunlab"] = false,
    ["microwave"] = false,
    ["spawned_shipment"] = false,
}


GM.Config.allowedProperties = {
    remover = true,
    ignite = false,
    extinguish = true,
    keepupright = true,
    gravity = true,
    collision = true,
    skin = true,
    bodygroups = true,
}

                                                                               
       
                                                                             


GM.Config.hideNonBuyable = false




GM.Config.hideTeamUnbuyable = true

                                                                               
          
                                                                             

GM.Config.afkdemotetime = 600

GM.Config.AFKDelay = 300

                                                                               
              
                                                                             

GM.Config.minHitPrice = 200

GM.Config.maxHitPrice = 50000

GM.Config.minHitDistance = 150

GM.Config.hudText = ""

GM.Config.hitmanText = ""

GM.Config.hitTargetCooldown = 120

GM.Config.hitCustomerCooldown = 240

                                                                               
                
                                                                             

GM.Config.hungerspeed = 0.3

GM.Config.starverate = 4
DarkRP.createCategory{
    name = "Скитальцы", 
    categorises = "jobs",
    startExpanded = true, 
    color = color_white, 
    canSee = function(ply) return true end,
    sortOrder = 101, 
}

local GAMEMODE = GAMEMODE or GM

TEAM_WANDERER = DarkRP.createJob('Скиталец', {
    color = color_white, description = '', max = 0, salary = 0, admin = 0, vote = false, hasLicense = false, candemote = true,
    model = { 'models/maha/shinsei/quincy_male_necromancie_torse_nue.mdl' },
    weapons = {'shibi_fists', 'keys'},
    command = 'TEAM_WANDERER',
    category = 'Скитальцы',
})


GAMEMODE.DefaultTeam = TEAM_WANDERER
GAMEMODE.CivilProtection = {
}


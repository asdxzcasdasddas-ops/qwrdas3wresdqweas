                                                                               
                                            
                                                                             

local hideHUDElements = {
    
    
    ["DarkRP_HUD"] = false,

    
    
    ["DarkRP_EntityDisplay"] = false,

    
    
    
    ["DarkRP_LocalPlayerHUD"] = false,

    
    
    ["DarkRP_Hungermod"] = false,

    
    ["DarkRP_Agenda"] = false,

    
    ["DarkRP_LockdownHUD"] = false,

    
    ["DarkRP_ArrestedHUD"] = false,

    
    ["DarkRP_ChatReceivers"] = false,
}


hook.Add("HUDShouldDraw", "HideDefaultDarkRPHud", function(name)
    if hideHUDElements[name] then return false end
end)

if true then return end 

                                                                               
              
                 
                                                                             
local Health = 0
local function hudPaint()
    local x, y = 30, ScrH() - 20
    local localplayer = LocalPlayer()
    Health = math.min(100, (Health == localplayer:Health() and Health) or Lerp(0.1, Health, localplayer:Health()))

    local DrawHealth = math.Min(Health / GAMEMODE.Config.startinghealth, 1)
    local Border = math.Min(6, math.pow(2, math.Round(3 * DrawHealth)))
    draw.RoundedBox(Border, x + 4, y - 30, 200 - 8, 20, Color(0,0,0,200))
    draw.RoundedBox(Border, x + 5, y - 29, (200 - 9) * DrawHealth, 18, Color(140,0,0,180))

    draw.DrawText(math.Max(0, math.Round(localplayer:Health())), "DarkRPHUD2", x + 4 + (200 - 8) / 2, y - 32, Color(255, 255, 255, 200), 1)

    
    local armor = localplayer:Armor()
    if armor ~= 0 then
        draw.RoundedBox(2, x + 4, y - 15, (200 - 8) * armor / 100, 5, Color(0, 0, 255, 255))
    end
end
hook.Add("HUDPaint", "DarkRP_Mod_HUDPaint", hudPaint)

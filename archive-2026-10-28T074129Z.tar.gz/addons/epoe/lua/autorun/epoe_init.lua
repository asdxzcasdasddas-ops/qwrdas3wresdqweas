if epoe then 
	


	if SERVER then
		pcall(function() 
			epoe.InEPOE=true 
			epoe.DisableTick()
		end)
		epoe=nil
		package.loaded.epoe=nil

	else 

		pcall(function()
			epoe.InEPOE=true
			e.GUI:Remove()
		end)
	end

end

include('epoe/shared.lua')


if SERVER then

	AddCSLuaFile("autorun/epoe_init.lua")

	AddCSLuaFile("epoe/client.lua")
	AddCSLuaFile("epoe/client_ui.lua")
	AddCSLuaFile("epoe/client_gui.lua")
	AddCSLuaFile("epoe/client_filter.lua")
	AddCSLuaFile("epoe/shared.lua")
	AddCSLuaFile("epoe/autoplace.lua")

	include('epoe/server.lua')

else
	include('epoe/client.lua')
	include('epoe/client_ui.lua')
	include("epoe/client_gui.lua")
	include('epoe/autoplace.lua')
	include("epoe/client_filter.lua")
end

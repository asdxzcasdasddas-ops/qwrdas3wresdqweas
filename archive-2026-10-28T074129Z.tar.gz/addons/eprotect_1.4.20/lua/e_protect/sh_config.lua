eProtect = eProtect or {}
eProtect.config = eProtect.config or {}

eProtect.config["language"] = "ru"
eProtect.config["prefix"] = "[eProtect] "
eProtect.config["storage_type"] = "sql_local"
eProtect.config["disablehttplogging"] = false
eProtect.config["ignoreDRM"] = false
eProtect.config["scURL"] = "https://stromic.dev/eprotect/img.php"
eProtect.config["punishMaliciousIntent"] = true

eProtect.config["disabledModules"] = {
    ["identifier"] = false,
    ["detection_log"] = false,
    ["net_limiter"] = false,
    ["net_logger"] = false,
    ["exploit_patcher"] = false,
    ["exploit_finder"] = false,
    ["fake_exploits"] = false,
    ["data_snooper"] = false
}
GProfiler.Access.AdminSystem = GProfiler.Access.AdminSystem or false

local function GlobalExists(name)
	local exists = false
	pcall(function() exists = _G[name] and true or false end)
	return exists
end

local AdminSystems = {
	["SAM"] = {
		Priority = 5,
		IsAvailable = function() return GlobalExists("SAM_LOADED") end,
		RegisterPrivilege = function(name)
			sam.permissions.add(name, "GProfiler", "superadmin")
		end,
		CheckAccess = function(ply, name)
			return ply:HasPermission(name)
		end
	},
	["CAMI"] = {
		Priority = 6,
		IsAvailable = function() return GlobalExists("CAMI") end,
		CheckAccess = function(ply, name)
			return ply:IsDeveloper()
		end
	}
}

function GProfiler.Access.FindAdminSystem()
	for name, system in SortedPairsByMemberValue(AdminSystems, "Priority") do
		if system.IsAvailable() then
			GProfiler.Access.AdminSystem = system
			GProfiler.Log("Found admin system: " .. name, 2)
			return
		end
	end

	GProfiler.Access.AdminSystem = false
end

function GProfiler.Access.RegisterPrivilege(name)
	if not GProfiler.Access.AdminSystem then
		GProfiler.Log("No admin system found, cannot register privilege: " .. name, 3)
		return
	end

	if GProfiler.Access.AdminSystem.RegisterPrivilege then
		GProfiler.Access.AdminSystem.RegisterPrivilege(name)
	end
end

hook.Add("Initialize", "GProfiler.Access.Register", function()
	GProfiler.Access.FindAdminSystem()
	GProfiler.Access.RegisterPrivilege("gprofiler")
end)

function GProfiler.Access.HasAccess(ply)
	if ply:IsDeveloper() then return true end
	if not GProfiler.Access.AdminSystem then return false end
	return GProfiler.Access.AdminSystem.CheckAccess(ply, "gprofiler")
end
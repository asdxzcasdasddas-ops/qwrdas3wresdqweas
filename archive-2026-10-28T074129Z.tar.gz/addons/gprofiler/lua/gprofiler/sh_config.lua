GProfiler.Version = "1.2.1"
GProfiler.Config.VersionCheck = true
GProfiler.Config.Language = "russian"
GProfiler.Config.LOG_DEBUG = true
GProfiler.Config.LOG_INFO = true
GProfiler.Config.LOG_WARNING = true
GProfiler.Config.LOG_ERROR = true
GProfiler.Config.LOG_LOAD = false

if CLIENT then
	GProfiler.MenuColors = {
		White = Color(255, 255, 255),
		Blue = Color(91, 118, 255),
		Background = Color(8, 27, 48, 220),
		OpaqueBlack = Color(0, 0, 0, 200),
		TopBarSeparator = Color(91, 118, 255, 10),
		HeaderSeparator = Color(91, 118, 255, 50),
		RealmSelectorBackground = Color(38, 57, 78),
		RealmSelectorOutline = Color(88, 107, 138),
		ActiveProfile = Color(10, 155, 10),
		DListBackground = Color(18, 37, 58),
		DListColumnBackground = Color(68, 87, 108),
		DListColumnOutline = Color(88, 107, 138),
		DListRowBackground = Color(48, 67, 88),
		DListRowHover = Color(68, 87, 108),
		DListRowTextColor = Color(235, 235, 235),
		DListRowSelected = Color(91, 118, 255, 50),
		ScrollBar = Color(38, 57, 78),
		ScrollBarGrip = Color(68, 87, 108),
		ScrollBarGripOutline = Color(88, 107, 138),
		ButtonOutline = Color(88, 107, 138),
		ButtonBackground = Color(38, 57, 78),
		ButtonHover = Color(58, 77, 98),
	}

	GProfiler.Config.MenuCommands = {
		Chat = "!gprofiler",
		Console = "gprofiler",
		Closekey = KEY_F4
	}
end
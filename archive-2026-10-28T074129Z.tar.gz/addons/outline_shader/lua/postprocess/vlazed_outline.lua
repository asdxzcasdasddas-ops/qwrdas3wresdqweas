if not CLIENT then return end

local mat_outline = Material("pp/vlazed/outline")
local cv = {}

cv.enabled = CreateClientConVar("pp_vlazedoutline", "0", true, false, "Outline players, character parts and weapons", 0, 1)
cv.depth = CreateClientConVar("pp_vlazedoutline_depththreshold", "0.1", true, false)
cv.scale = CreateClientConVar("pp_vlazedoutline_scale", "1", true, false)
cv.depthNormal = CreateClientConVar("pp_vlazedoutline_depthnormalthreshold", "1.0", true, false)
cv.depthNormalScale = CreateClientConVar("pp_vlazedoutline_depthnormalthresholdscale", "0.00", true, false)
cv.normal = CreateClientConVar("pp_vlazedoutline_normalthreshold", "1.59", true, false)
cv.red = CreateClientConVar("pp_vlazedoutline_r", "0", true, false)
cv.green = CreateClientConVar("pp_vlazedoutline_g", "0", true, false)
cv.blue = CreateClientConVar("pp_vlazedoutline_b", "0", true, false)
cv.alpha = CreateClientConVar("pp_vlazedoutline_a", "255", true, false)
cv.debug = CreateClientConVar("pp_vlazedoutline_debug", "0", true, false)
cv.luminance = CreateClientConVar("pp_vlazedoutline_luminancethreshold", "2", true, false)
cv.maskScale = CreateClientConVar("pp_vlazedoutline_maskscale", "1.06", true, false, "Outline mask expansion", 1, 1.2)

local width, height = ScrW(), ScrH()
local collected, seen = {}, {}
local viewOrigin, viewAngles, viewFov

hook.Add("OnScreenSizeChanged", "vlazed_outline_size", function(w, h)
    width, height = w, h
end)

hook.Add("CalcView", "vlazed_outline_view", function(ply, origin, angles, fov)
    if ply ~= LocalPlayer() then return end
    viewOrigin = origin
    viewAngles = angles
    viewFov = fov
end)

local function AddEntity(ent)
    if not IsValid(ent) or ent:IsDormant() or ent:GetNoDraw() or seen[ent] then return end
    seen[ent] = true
    collected[#collected + 1] = ent
end

local function CollectTargets()
    table.Empty(collected)
    table.Empty(seen)

    for _, ply in ipairs(player.GetAll()) do
        if not IsValid(ply) or not ply:Alive() then continue end

        AddEntity(ply)

        if IsValid(ply.SHIBI_HeadEnt) then
            AddEntity(ply.SHIBI_HeadEnt)
        end

        for _, child in ipairs(ply:GetChildren()) do
            if IsValid(child) and child:GetClass() == "prop_dynamic" then
                AddEntity(child)
            end
        end

        local weapon = ply:GetActiveWeapon()
        if IsValid(weapon) then
            AddEntity(weapon)
        end

        if ply == LocalPlayer() then
            local viewModel = ply:GetViewModel()
            if IsValid(viewModel) then
                AddEntity(viewModel)
            end
        end
    end

    return #collected > 0
end

local function DrawStencilMask()
    if not CollectTargets() then return false end

    render.ClearStencil()
    render.SetStencilEnable(true)
    render.SetStencilWriteMask(255)
    render.SetStencilTestMask(255)
    render.SetStencilReferenceValue(1)
    render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_ALWAYS)
    render.SetStencilPassOperation(STENCILOPERATION_REPLACE)
    render.SetStencilFailOperation(STENCILOPERATION_KEEP)
    render.SetStencilZFailOperation(STENCILOPERATION_KEEP)
    render.OverrideColorWriteEnable(true, false)
    render.OverrideDepthEnable(true, false)

    cam.Start3D(viewOrigin or EyePos(), viewAngles or EyeAngles(), viewFov or LocalPlayer():GetFOV())
    local maskScale = cv.maskScale:GetFloat()
    for i = 1, #collected do
        local ent = collected[i]
        if IsValid(ent) then
            local pos = ent:GetPos()
            local matrix = Matrix()
            matrix:Translate(pos)
            matrix:Scale(Vector(maskScale, maskScale, maskScale))
            matrix:Translate(-pos)
            cam.PushModelMatrix(matrix)
            ent:DrawModel()
            cam.PopModelMatrix()
        end
    end
    cam.End3D()

    render.OverrideDepthEnable(false, false)
    render.OverrideColorWriteEnable(false, false)
    render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_EQUAL)
    render.SetStencilPassOperation(STENCILOPERATION_KEEP)
    return true
end

local function DrawPlayerOutline()
    if not cv.enabled:GetBool() then return end
    if not DrawStencilMask() then
        render.SetStencilEnable(false)
        return
    end

    render.UpdateScreenEffectTexture()

    mat_outline:SetFloat("$c0_z", cv.depthNormal:GetFloat())
    mat_outline:SetFloat("$c0_y", cv.scale:GetInt())
    mat_outline:SetFloat("$c0_x", cv.depth:GetFloat())
    mat_outline:SetFloat("$c0_w", cv.depthNormalScale:GetFloat())
    mat_outline:SetFloat("$c1_x", cv.normal:GetFloat())
    mat_outline:SetFloat("$c2_x", 1 / math.max(width, 1))
    mat_outline:SetFloat("$c2_y", 1 / math.max(height, 1))
    mat_outline:SetFloat("$c2_z", cv.luminance:GetFloat())
    mat_outline:SetFloat("$c2_w", cv.debug:GetInt())
    mat_outline:SetFloat("$c3_x", cv.red:GetFloat() / 255)
    mat_outline:SetFloat("$c3_y", cv.green:GetFloat() / 255)
    mat_outline:SetFloat("$c3_z", cv.blue:GetFloat() / 255)
    mat_outline:SetFloat("$c3_w", cv.alpha:GetFloat() / 255)

    render.SetMaterial(mat_outline)
    render.DrawScreenQuad()
    render.SetStencilEnable(false)
end

hook.Add("RenderScreenspaceEffects", "vlazed_outline_players_only", DrawPlayerOutline)

list.Set("PostProcess", "Outline (vlazed, players only)", {
    icon = "gui/postprocess/vlazedoutline.png",
    convar = "pp_vlazedoutline",
    category = "#shaders_pp",
    cpanel = function(panel)
        panel:Help("Apply the Vlazed outline shader only to players, SHIBI separate heads and their active weapons.")
        local options = {
            pp_vlazedoutline = "0",
            pp_vlazedoutline_scale = "2",
            pp_vlazedoutline_depththreshold = "0.1",
            pp_vlazedoutline_depthnormalthreshold = "1.0",
            pp_vlazedoutline_depthnormalthresholdscale = "0.0",
            pp_vlazedoutline_normalthreshold = "1.59",
            pp_vlazedoutline_luminancethreshold = "0.85",
            pp_vlazedoutline_r = "0",
            pp_vlazedoutline_g = "0",
            pp_vlazedoutline_b = "0",
            pp_vlazedoutline_a = "255",
            pp_vlazedoutline_debug = "0",
            pp_vlazedoutline_maskscale = "1.06"
        }
        panel:ToolPresets("vlazedoutline", options)
        panel:ColorPicker("Color", "pp_vlazedoutline_r", "pp_vlazedoutline_g", "pp_vlazedoutline_b", "pp_vlazedoutline_a")
        panel:CheckBox("Enable", "pp_vlazedoutline")
        panel:CheckBox("Debug", "pp_vlazedoutline_debug")
        panel:NumSlider("Scale", "pp_vlazedoutline_scale", 0, 10, 0)
        panel:NumSlider("Depth Threshold", "pp_vlazedoutline_depththreshold", 0, 1)
        panel:NumSlider("Depth Normal Threshold", "pp_vlazedoutline_depthnormalthreshold", 0, 1)
        panel:NumSlider("Depth Normal Threshold Scale", "pp_vlazedoutline_depthnormalthresholdscale", 0, 10)
        panel:NumSlider("Normal Threshold", "pp_vlazedoutline_normalthreshold", 0, 10)
        panel:NumSlider("Luminance Threshold", "pp_vlazedoutline_luminancethreshold", 0, 10)
        panel:NumSlider("Mask Expansion", "pp_vlazedoutline_maskscale", 1, 1.2, 2)
    end
})

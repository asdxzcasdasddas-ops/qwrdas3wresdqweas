  
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                   
                                                                                   
  

sql.Query("CREATE TABLE IF NOT EXISTS permaprops('id' INTEGER NOT NULL, 'map' TEXT NOT NULL, 'content' TEXT NOT NULL, PRIMARY KEY('id'));")

if not PermaProps then PermaProps = {} end

PermaProps.SQL = {}

                                                                                         
                            
                                 
                                    
                                    
                                           
                                   
                                           
  

function PermaProps.SQL.Query( data )

	return sql.Query( data )

end
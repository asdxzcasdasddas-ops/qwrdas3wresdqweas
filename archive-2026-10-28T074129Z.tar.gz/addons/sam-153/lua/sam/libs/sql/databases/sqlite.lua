local _SQL = sam.SQL
local _error = sam.SQL.Error
local sql_query = sql.Query

local SQL = {}

function SQL.Connect(callback)
	timer.Simple(0, callback)
	return true
end




local transactions

local add_transaction = function(query)
	table.insert(transactions, query)
end

function SQL.Begin()
	transactions = {}
	sql_query("BEGIN TRANSACTION")
	return add_transaction
end

function SQL.Commit(callback)
	for i = 1, #transactions do
		if sql_query(transactions[i]) == false then
			sql_query("ROLLBACK TRANSACTION")
			transactions = nil
			_error("Transaction error: " .. sql.LastError())
			return
		end
	end

	transactions = nil

	sql_query("COMMIT TRANSACTION")

	if callback then
		callback()
	end
end







local query_obj = {
	wait = function() end 
}

function SQL.Query(query, callback, first_row, callback_obj)
	local data = sql_query(query)
	if data == false then
		_error("Query error: " .. sql.LastError())
	elseif callback then
		if data == nil then
			if not first_row then
				data = {}
			end
		elseif first_row then
			data = data[1]
		end

		callback(data, callback_obj)
	end

	return query_obj
end



















































local SQLStr = SQLStr
function SQL.EscapeString(value, no_quotes)
	return SQLStr(value, no_quotes)
end

function SQL.TableExistsQuery(name)
	return "SELECT `name` FROM `sqlite_master` WHERE `name` = " .. SQL.EscapeString(name) .. " AND `type` = 'table'"
end





return SQL
if SAM_LOADED then return end

return {
	
	
	
	
	MySQL = false,

	
	
	
	Host = "sss",

	
	
	
	Username = "sss",

	
	
	
	Password = "sss",

	
	
	
	Database = "sss",
}
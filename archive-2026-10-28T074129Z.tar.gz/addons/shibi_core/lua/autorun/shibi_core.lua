if SERVER then
    AddCSLuaFile("shibi/init.lua")
    AddCSLuaFile("shibi/shared.lua")
end

include("shibi/init.lua")

SHIBI.Cutscene.Define("bankai", {
    duration = 5.5,

    keys = {
        { t = 0.00, pos = Vector(170,  90, 60), look = Vector(0, 0, 50), fov = 70 },
        { t = 0.18, pos = Vector(120,  45, 40), look = Vector(0, 0, 55), fov = 66 },
        { t = 0.30, pos = Vector( 65, -30, 20), look = Vector(0, 0, 70), fov = 56 },
        { t = 0.50, pos = Vector( 85, -15, 35), look = Vector(0, 0, 85), fov = 60 },
        { t = 0.65, pos = Vector(100,  20, 55), look = Vector(0, 0, 80), fov = 66 },
        { t = 0.85, pos = Vector(140,  10, 75), look = Vector(0, 0, 70), fov = 72 },
        { t = 1.00, pos = Vector(190, -60, 100), look = Vector(0, 0, 60), fov = 74 },
    },

    impulses = {
        { at = 1.6, pitch = -2.5, yaw = 1.2, dur = 0.6 },
        { at = 3.6, pitch = -1.5, yaw = -0.8, dur = 0.5 },
    },
})

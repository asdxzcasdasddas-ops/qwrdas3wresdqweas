local CFG = {
    duration   = 5.5,
    stanceAnim = "evo_0q2c9haz72pt6uxkw",
    raiseAnim  = "evo_1p5fwm4s0jsh",
    stanceTime = 1.6,
    raiseTime  = 2.0,
    raiseAt    = 1.6,
    auraAt     = 3.6,
    auraTime   = 15,

    sound      = "bankai/bankai-byakuya.mp3",
    soundLevel = 100,

    particles = {
        stance = "[14]_danse_mortelle",
        petals = "[14]_ocean_de_petales",
        rain   = "[14]_pluie_cinglante",
        aura   = "[14]_bankai_aura",
    },
}

SHIBI.Abilities.Register("bankai", {
    duration = CFG.duration,

    OnCast = function(ctx, ply)
        ply:Freeze(true)
        SHIBI.Cutscene.Play(ply, "bankai")

        if CFG.sound ~= "" then
            SHIBI.SoundPlay(ply, CFG.sound, CFG.soundLevel)
        end

        SHIBI.ParticleAura(ply, CFG.particles.stance, CFG.stanceTime)
        ctx:Anim(CFG.stanceAnim, 1, CFG.stanceTime)

        ctx:Wait(CFG.raiseAt, function(c, owner)
            c:Anim(CFG.raiseAnim, 1, CFG.raiseTime)
            SHIBI.ParticleStop(owner)
            SHIBI.ParticleAura(owner, CFG.particles.petals, CFG.raiseTime + 0.6)
            SHIBI.ParticleAura(owner, CFG.particles.rain, CFG.raiseTime + 0.6)
        end)

        ctx:Wait(CFG.auraAt, function(_, owner)
            SHIBI.ParticleStop(owner)
            SHIBI.ParticleAura(owner, CFG.particles.aura, CFG.auraTime)
        end)
    end,

    OnEnd = function(ctx, ply, reason)
        if not IsValid(ply) then return end

        ply:Freeze(false)
        SHIBI.Cutscene.Stop(ply)

        if reason ~= "done" then
            SHIBI.ParticleStop(ply)
        end
    end,
})

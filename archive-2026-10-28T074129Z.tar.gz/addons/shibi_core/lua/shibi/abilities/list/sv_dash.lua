local CFG = {
    anim        = "yin1_0_battle_skill6_1_base",
    animTime    = 0.6,

    power       = 1700,
    duration    = 0.35,
    lift        = 12,
    rampOut     = 0.25,
    stopTime    = 0.12,

    radius      = 70,
    damage      = 35,
    stun        = 0.5,

    auraParticle = "[13]_resurreccion_aura",
    hitParticle  = "[0]_crushing_grip",
    hitSound     = "",
    soundLevel   = 85,
}

local LIFT_VEC = Vector(0, 0, CFG.lift)

local function IsCharacter(ent)
    return IsValid(ent) and (ent:IsPlayer() or ent:IsNPC() or ent:IsNextBot())
end

local function HitVictim(attacker, victim)
    local dealt = takedamage(victim, CFG.damage, attacker)
    if dealt <= 0 then return end

    SHIBI.ParticleEffectOnPos(attacker, CFG.hitParticle, victim:WorldSpaceCenter(), angle_zero, 0.6)
    if CFG.hitSound ~= "" then
        SHIBI.SoundPlay(victim, CFG.hitSound, CFG.soundLevel)
    end

    if victim:IsPlayer() and SHIBI.StunPlayer then
        SHIBI.StunPlayer(victim, CFG.stun)
    end
end

local function LiftOffGround(ply)
    local tr = util.TraceHull({
        start  = ply:GetPos(),
        endpos = ply:GetPos() + LIFT_VEC,
        mins   = ply:OBBMins(),
        maxs   = ply:OBBMaxs(),
        filter = ply,
        mask   = MASK_SOLID_BRUSHONLY,
    })
    if not tr.StartSolid and not tr.Hit then
        ply:SetPos(ply:GetPos() + LIFT_VEC)
    end
end

local function FindContact(ply, pos)
    for _, ent in ipairs(ents.FindInSphere(pos, CFG.radius)) do
        if ent ~= ply and IsCharacter(ent) then
            return ent
        end
    end
end

SHIBI.Abilities.Register("dash", {
    duration = CFG.duration,

    feel = {
        punch = { pitch = -1.5, yaw = 1, roll = 0.5 },
        shake = { amp = 1.5, freq = 22, dur = 0.2 },
    },

    OnCast = function(ctx, ply)
        if ply:InVehicle() or ply:WaterLevel() >= 2 then
            ctx:End("blocked")
            return
        end

        local dir       = ply:GetAimVector():GetNormalized()
        local startTime = CurTime()
        local contactTime

        LiftOffGround(ply)

        if CFG.anim ~= "" then
            ctx:Anim(CFG.anim, 1, CFG.animTime)
        end
        SHIBI.ParticleAura(ply, CFG.auraParticle, CFG.duration)

        ply:SetVelocity(-ply:GetVelocity())

        local timerName = "SHIBI::Dash::" .. ply:EntIndex()
        ctx.dashTimer = timerName

        timer.Create(timerName, 0, 0, function()
            if not IsValid(ply) or not ply:Alive() then
                ctx:End("death")
                return
            end

            local now = CurTime()
            local factor

            if contactTime then
                factor = 1 - (now - contactTime) / CFG.stopTime
                if factor <= 0 then
                    ctx:End("hit")
                    return
                end
            else
                local t = math.Clamp((now - startTime) / CFG.duration, 0, 1)
                if t >= 1 then
                    ctx:End("done")
                    return
                end
                factor = math.min(1, (1 - t) / CFG.rampOut)
            end

            ply:SetVelocity(dir * CFG.power * factor - ply:GetVelocity())

            if not contactTime then
                local victim = FindContact(ply, ply:GetPos() + Vector(0, 0, 36))
                if victim then
                    contactTime = now
                    HitVictim(ply, victim)
                end
            end
        end)
    end,

    OnEnd = function(ctx, ply, reason)
        if ctx.dashTimer then timer.Remove(ctx.dashTimer) end
        if not IsValid(ply) then return end

        ply:SetVelocity(-ply:GetVelocity())
    end,
})

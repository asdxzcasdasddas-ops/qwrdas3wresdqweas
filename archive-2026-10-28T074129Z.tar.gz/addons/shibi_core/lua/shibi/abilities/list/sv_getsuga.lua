local CFG = {
    anim       = "baizai4_0_battle_attack1_1_base",
    animTime   = 0.8,
    windup     = 0.3,

    model      = "models/gluk/fireslash3_bleu_fonce/fireslash3_bleu_fonce.mdl",
    speed      = 1400,
    lifetime   = 3,
    fadeTime   = 0.4,
    fadeScale  = 0.5,
    spawnDist  = 60,
    modelYaw   = 180,
    hullMins   = Vector(-16, -16, -16),
    hullMaxs   = Vector(16, 16, 16),

    damage     = 60,
    stun       = 0.6,
    hitAnim    = "enmu_a_p1011_v00_c00_dmg02_g",

    sound      = "",
    soundLevel = 85,
}

util.PrecacheModel(CFG.model)

local function IsCharacter(ent)
    return IsValid(ent) and (ent:IsPlayer() or ent:IsNPC() or ent:IsNextBot())
end

local function HitVictim(attacker, victim)
    local dealt = takedamage(victim, CFG.damage, attacker)
    if dealt <= 0 then return end

    if victim:IsPlayer() then
        if SHIBI.StunPlayer then SHIBI.StunPlayer(victim, CFG.stun) end
        SHIBI.Anim.Play(victim, CFG.hitAnim, 1, false, CFG.stun)
    end
end

local function Finish(prop, timerName)
    timer.Remove(timerName)
    if IsValid(prop) then prop:Remove() end
end

local function SpawnSlash(ply, origin, dir)
    local prop = ents.Create("prop_dynamic")
    if not IsValid(prop) then return end

    prop:SetModel(CFG.model)
    prop:SetPos(origin)
    local _, modelAng = LocalToWorld(vector_origin, Angle(0, CFG.modelYaw, 0), vector_origin, dir:Angle())
    prop:SetAngles(modelAng)
    prop:SetOwner(ply)
    prop:SetSolid(SOLID_NONE)
    prop:SetMoveType(MOVETYPE_NONE)
    prop:SetRenderMode(RENDERMODE_TRANSCOLOR)
    prop:SetColor(Color(255, 255, 255, 255))
    prop:Spawn()

    local hit       = {}
    local pos       = origin
    local lastTime  = CurTime()
    local stopTime  = lastTime + CFG.lifetime
    local fadeStart = nil
    local timerName = "SHIBI::Getsuga::" .. prop:EntIndex() .. "::" .. lastTime

    timer.Create(timerName, 0, 0, function()
        if not IsValid(prop) or not IsValid(ply) then
            Finish(prop, timerName)
            return
        end

        local now = CurTime()
        local dt  = now - lastTime
        lastTime  = now

        if not fadeStart and now > stopTime then
            fadeStart = now
        end

        local nextPos = pos
        if not fadeStart then
            nextPos = pos + dir * CFG.speed * dt

            local world = util.TraceHull({
                start  = pos,
                endpos = nextPos,
                mins   = CFG.hullMins,
                maxs   = CFG.hullMaxs,
                filter = { ply, prop },
                mask   = MASK_SOLID_BRUSHONLY,
            })
            if world.Hit then
                fadeStart = now
                nextPos   = pos
            else
                for _, ent in ipairs(ents.FindAlongRay(pos, nextPos, CFG.hullMins, CFG.hullMaxs)) do
                    if ent ~= ply and ent ~= prop and IsCharacter(ent) and not hit[ent] then
                        hit[ent] = true
                        HitVictim(ply, ent)
                    end
                end
            end
        end

        if fadeStart then
            local fade = math.Clamp((now - fadeStart) / CFG.fadeTime, 0, 1)
            if fade >= 1 then
                Finish(prop, timerName)
                return
            end

            local eased = fade * fade * (3 - 2 * fade)
            nextPos = pos + dir * CFG.speed * dt * (1 - eased)
            prop:SetColor(Color(255, 255, 255, math.floor(255 * (1 - eased))))
            prop:SetModelScale(1 - (1 - CFG.fadeScale) * eased, 0)
        end

        prop:SetPos(nextPos)
        pos = nextPos
    end)
end

SHIBI.Abilities.Register("getsuga", {
    duration = CFG.animTime,

    feel = {
        punch = { pitch = -3, yaw = 2, roll = 1 },
        shake = { amp = 3.5, freq = 18, dur = 0.35,
                  opts = { roll = 0.5, pos = 0.2, ax = { x = 1, y = 0.6, z = 1 } } },
    },

    OnCast = function(ctx, ply)
        ctx:Anim(CFG.anim, 1, CFG.animTime)

        if CFG.sound ~= "" then
            SHIBI.SoundPlay(ply, CFG.sound, CFG.soundLevel)
        end

        ctx:Wait(CFG.windup, function(_, caster)
            local dir    = caster:GetAimVector()
            local origin = caster:WorldSpaceCenter() + dir * CFG.spawnDist
            SpawnSlash(caster, origin, dir)
        end)
    end,
})

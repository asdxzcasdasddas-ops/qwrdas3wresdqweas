local CFG = {
    castAnim    = "evo_0f49worqgi5pnbymd",
    castTime    = 1.0,
    hitAnim     = "evo_0ygirbvk15d8x4ic",
    particle    = "[0]_takitsubo",
    fxTime      = 2.0,
    maxRange    = 1500,
    impactDelay = 0.4,
    radius      = 70,
    damage      = 80,
    stun        = 1.0,
}

local UP   = Vector(0, 0, 40)
local DOWN = Vector(0, 0, 4096)

local function AimPoint(ply)
    local start = ply:EyePos()
    local tr = util.TraceLine({
        start  = start,
        endpos = start + ply:GetAimVector() * CFG.maxRange,
        filter = ply,
        mask   = MASK_SOLID_BRUSHONLY,
    })
    if tr.HitWorld and tr.HitNormal.z >= 0.5 then return tr.HitPos end
    return util.TraceLine({ start = tr.HitPos, endpos = tr.HitPos - DOWN, mask = MASK_SOLID_BRUSHONLY }).HitPos
end

local function CanHit(attacker, victim)
    local filter = {attacker}
    if attacker.GetActiveWeapon and IsValid(attacker:GetActiveWeapon()) then
        table.insert(filter, attacker:GetActiveWeapon())
    end

    local center = victim:WorldSpaceCenter()
    local points = {
        center,
        center + Vector(0, 0, 15),
        center + Vector(0, 0, -15),
    }

    for _, point in ipairs(points) do
        local tr = util.TraceLine({
            start  = attacker:EyePos(),
            endpos = point,
            filter = filter,
            mask   = MASK_SHOT_HULL,
        })
        if not tr.Hit or tr.Entity == victim then return true end
    end
    return false
end

local function DamageInSphere(attacker, center, radius, damage)
    local hits = 0
    for _, victim in ipairs(ents.FindInSphere(center, radius)) do
        if IsValid(victim)
            and (victim:IsPlayer() or victim:IsNPC() or victim:IsNextBot())
            and victim ~= attacker
            and victim:Health() > 0
            and CanHit(attacker, victim)
        then
            if takedamage(victim, damage, attacker) > 0 then
                hits = hits + 1

                if victim:IsPlayer() then
                    if SHIBI.StunPlayer then SHIBI.StunPlayer(victim, CFG.stun) end
                    SHIBI.Anim.Play(victim, CFG.hitAnim, 1, false, CFG.stun)
                end
            end
        end
    end
    return hits
end

SHIBI.Abilities.Register("takitsubo", {
    name     = "Такицубо",
    cooldown = 1,
    cost     = 30,
    duration = CFG.castTime,

    OnCast = function(ctx, ply)
        local pos = AimPoint(ply)

        ctx:Anim(CFG.castAnim, 1, CFG.castTime)
        SHIBI.ParticleEffectOnPos(ply, CFG.particle, pos, angle_zero, CFG.fxTime)

        ctx:Wait(CFG.impactDelay, function()
            if not IsValid(ply) then return end
            DamageInSphere(ply, pos + UP, CFG.radius, CFG.damage)
        end)
    end,
})

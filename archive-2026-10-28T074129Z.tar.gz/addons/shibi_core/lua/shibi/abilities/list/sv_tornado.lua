local CFG = {
    castAnim     = "bailegang_attack1_3_base",
    castTime     = 1.0,
    windup       = 0.35,
    spawnDist    = 60,
    groundUp     = 64,
    groundDown   = 256,
    groundOffset = 4,

    particle     = "[10]_foam_cyclone",
    fxRefresh    = 0.15,
    fxTime       = 0.4,
    auraParticle = "[13]_resurreccion_aura",
    liftAnim     = "m_beaten_fall_behind_loop",
    fallAnim     = "enmu_a_p1011_v00_c00_dmgfall01_2",

    speed        = 900,
    lifetime     = 2.5,
    radius       = 70,
    tornadoMins  = Vector(-12, -12, 0),
    tornadoMaxs  = Vector(12, 12, 24),

    holdTime     = 0.3,
    liftTime     = 1.2,
    liftHeight   = 160,
    liftRadius   = 30,
    liftSpins    = 2,

    launchSpeed  = 700,
    launchUp     = 320,
    minAir       = 0.3,
    landTimeout  = 8,
    landCheck    = 6,

    stun         = 1.2,
    damage       = 40,
}

local function IsAlive(ent)
    if not IsValid(ent) then return false end
    if ent:IsPlayer() then return ent:Alive() end
    return ent:Health() > 0
end

local function IsCharacter(ent)
    return IsValid(ent) and (ent:IsPlayer() or ent:IsNPC() or ent:IsNextBot())
end

local function HasLanded(ent)
    if ent:GetVelocity().z > 0 then return false end

    local pos = ent:GetPos()
    local tr = util.TraceHull({
        start  = pos,
        endpos = pos - Vector(0, 0, CFG.landCheck),
        mins   = ent:OBBMins(),
        maxs   = ent:OBBMaxs(),
        filter = ent,
        mask   = MASK_SOLID_BRUSHONLY,
    })
    return tr.Hit and tr.HitNormal.z >= 0.7
end

local function StopVelocity(ent)
    ent:SetVelocity(-ent:GetVelocity())
end

local function Every(name, fn)
    timer.Create(name, 0, 0, function()
        if fn() then timer.Remove(name) end
    end)
end

local timerSerial = 0

local function NewName(tag)
    timerSerial = timerSerial + 1
    return "SHIBI::Tornado::" .. tag .. "::" .. timerSerial
end

local function ClearVictim(victim)
    if not IsValid(victim) then return end
    SHIBI.ParticleStop(victim)
    SHIBI.Anim.Stop(victim)
end

local function WaitOnGround(ent, onLand)
    local launchTime = CurTime()

    Every(NewName("Ground"), function()
        if not IsAlive(ent) then
            ClearVictim(ent)
            return true
        end

        local air = CurTime() - launchTime
        if air < CFG.minAir then return false end

        if HasLanded(ent) then
            onLand(ent)
            return true
        end

        if air >= CFG.landTimeout then
            ClearVictim(ent)
            return true
        end
        return false
    end)
end

local function Land(caster, victim)
    ClearVictim(victim)

    takedamage(victim, CFG.damage, IsValid(caster) and caster or nil)

    if victim:IsPlayer() then
        if SHIBI.StunPlayer then SHIBI.StunPlayer(victim, CFG.stun) end
        SHIBI.Anim.Play(victim, CFG.fallAnim, 1, false, CFG.stun)
    end
end

local function Launch(victim, flatDir)
    SHIBI.Anim.Stop(victim)

    local v = flatDir * CFG.launchSpeed + Vector(0, 0, CFG.launchUp)
    victim:SetVelocity(v - victim:GetVelocity())
end

local LIFT_CLEAR = Vector(0, 0, 4)

local function Lift(caster, victim, onDone)
    local startTime = CurTime()
    local center    = victim:GetPos()
    local lastPos   = center
    local lastFx    = 0

    SHIBI.ParticleAura(victim, CFG.auraParticle, CFG.holdTime + CFG.liftTime + CFG.landTimeout)
    SHIBI.Anim.Play(victim, CFG.liftAnim, 1, true, CFG.holdTime + CFG.liftTime)

    Every(NewName("Lift"), function()
        if not IsAlive(victim) or not IsAlive(caster) then
            ClearVictim(victim)
            return true
        end

        local now    = CurTime()
        local t      = math.Clamp((now - startTime - CFG.holdTime) / CFG.liftTime, 0, 1)
        local eased  = t * t * (3 - 2 * t)
        local angle  = t * CFG.liftSpins * math.pi * 2
        local radius = CFG.liftRadius * eased

        local pos = Vector(
            center.x + math.cos(angle) * radius,
            center.y + math.sin(angle) * radius,
            center.z + CFG.liftHeight * eased
        )

        local tr = util.TraceHull({
            start  = lastPos + LIFT_CLEAR,
            endpos = pos + LIFT_CLEAR,
            mins   = victim:OBBMins(),
            maxs   = victim:OBBMaxs(),
            filter = { victim, caster },
            mask   = MASK_SOLID_BRUSHONLY,
        })
        if tr.StartSolid then
            ClearVictim(victim)
            return true
        end
        if tr.Hit and tr.HitNormal.z < 0.7 then
            victim:SetPos(tr.HitPos - LIFT_CLEAR)
            StopVelocity(victim)
            onDone(victim)
            return true
        end

        victim:SetPos(pos)
        StopVelocity(victim)
        lastPos = pos

        if now - lastFx >= CFG.fxRefresh then
            lastFx = now
            SHIBI.ParticleEffectOnPos(caster, CFG.particle,
                Vector(center.x, center.y, pos.z), angle_zero, CFG.fxTime)
        end

        if t >= 1 then
            onDone(victim)
            return true
        end
        return false
    end)
end

local function CaptureSequence(caster, victim, flatDir)
    Lift(caster, victim, function(lifted)
        Launch(lifted, flatDir)
        WaitOnGround(lifted, function(landed)
            Land(caster, landed)
        end)
    end)
end

local function GroundAt(pos, caster)
    local tr = util.TraceLine({
        start  = pos + Vector(0, 0, CFG.groundUp),
        endpos = pos - Vector(0, 0, CFG.groundDown),
        filter = caster,
        mask   = MASK_SOLID_BRUSHONLY,
    })
    if not tr.Hit or tr.HitNormal.z < 0.7 then return nil end
    return tr.HitPos
end

local function StartTornado(caster)
    local flatDir   = Angle(0, caster:EyeAngles().y, 0):Forward()
    local ground    = GroundAt(caster:GetPos() + flatDir * CFG.spawnDist, caster)
    if not ground then return end

    local pos       = ground + Vector(0, 0, CFG.groundOffset)
    local startTime = CurTime()
    local lastTick  = startTime
    local lastFx    = 0

    Every(NewName("Fly"), function()
        if not IsAlive(caster) then return true end

        local now = CurTime()
        local dt  = now - lastTick
        lastTick  = now

        if now - startTime > CFG.lifetime then return true end

        if now - lastFx >= CFG.fxRefresh then
            lastFx = now
            SHIBI.ParticleEffectOnPos(caster, CFG.particle, pos, angle_zero, CFG.fxTime)
        end

        local nextXY = pos + flatDir * CFG.speed * dt

        local wall = util.TraceHull({
            start  = pos + Vector(0, 0, 8),
            endpos = nextXY + Vector(0, 0, 8),
            mins   = CFG.tornadoMins,
            maxs   = CFG.tornadoMaxs,
            filter = caster,
            mask   = MASK_SOLID_BRUSHONLY,
        })
        if wall.Hit then return true end

        local floor = GroundAt(nextXY, caster)
        if not floor then return true end
        pos = floor + Vector(0, 0, CFG.groundOffset)

        for _, ent in ipairs(ents.FindInSphere(pos + Vector(0, 0, 36), CFG.radius)) do
            if ent ~= caster and IsCharacter(ent) and IsAlive(ent) then
                CaptureSequence(caster, ent, flatDir)
                return true
            end
        end
        return false
    end)
end

SHIBI.Abilities.Register("tornado", {
    duration = CFG.castTime,

    OnCast = function(ctx, ply)
        ctx:Anim(CFG.castAnim, 1, CFG.castTime)

        ctx:Wait(CFG.windup, function(_, caster)
            StartTornado(caster)
        end)
    end,
})

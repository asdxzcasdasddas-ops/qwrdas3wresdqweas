SHIBI.Abilities = SHIBI.Abilities or {}
local A = SHIBI.Abilities
A.List       = A.List or {}
A.Catalog    = A.Catalog or {}
A.Categories = A.Categories or {}

-- каст, кулдауны, гкд — вот это всё
local NET_CAST  = "SHIBI::Ability::Cast"
local CD_PREFIX = "SHIBI::CD::"
local LIST_DIR  = "shibi/abilities/list/"
local MAX_ID_LEN = 32

local CurTime, IsValid, math_max = CurTime, IsValid, math.max

function A.GetCooldown(ply, id)
    return math_max(0, ply:GetNW2Float(CD_PREFIX .. id, 0) - CurTime())
end

if CLIENT then
    function A.Request(id)
        if not isstring(id) or id == "" or #id > MAX_ID_LEN then return end
        net.Start(NET_CAST)
            net.WriteString(id)
        net.SendToServer()
    end
    return
end

util.AddNetworkString(NET_CAST)

A.GlobalCooldown = 0.35
A.NetThrottle    = 0.05
A.ResetOnSpawn   = true

A._state = A._state or setmetatable({}, { __mode = "k" })
local State = A._state

local function St(ply)
    local s = State[ply]
    if not s then
        s = { cd = {}, gcd = 0, net = 0 }
        State[ply] = s
    end
    return s
end

function A.Register(id, def)
    assert(isstring(id) and id ~= "" and #id <= MAX_ID_LEN, "[Abilities] bad id: " .. tostring(id))
    assert(istable(def) and isfunction(def.OnCast), "[Abilities] " .. id .. ": нет OnCast")

    local meta = A.Catalog[id]
    assert(meta and isstring(meta.category) and meta.category ~= "",
        "[Abilities] " .. id .. ": нет записи в sh_ability_registry.lua с категорией")
    for k, v in pairs(meta) do def[k] = v end

    def.id       = id
    def.name     = def.name or id
    def.cooldown = tonumber(def.cooldown) or 0
    def.cost     = tonumber(def.cost) or 0
    def.duration = tonumber(def.duration) or 0.5
    def.cdKey    = CD_PREFIX .. id

    A.List[id] = def
    return def
end

local CTX = {}
CTX.__index = CTX

local function Alive(ctx)
    if not ctx.alive then return false end
    local ply = ctx.ply
    if not IsValid(ply) or not ply:Alive() then
        ctx:End("death")
        return false
    end
    if ctx.def.stunBreaks ~= false and SHIBI.IsStunned(ply) then
        ctx:End("stun")
        return false
    end
    return true
end

function CTX:Wait(delay, fn)
    timer.Simple(delay, function()
        if Alive(self) then fn(self, self.ply) end
    end)
end

function CTX:Repeat(interval, count, fn)
    for i = 1, count do
        timer.Simple(interval * (i - 1), function()
            if Alive(self) then fn(self, self.ply, i) end
        end)
    end
end

function CTX:Anim(seq, speed, duration)
    self.animGen = SHIBI.Anim.Play(self.ply, seq, speed, false, duration) or nil
    return self.animGen
end

function CTX:End(reason)
    if not self.alive then return end
    self.alive = false
    reason = reason or "done"

    local ply, def = self.ply, self.def
    if IsValid(ply) then
        local s = State[ply]
        if s and s.cast == self then s.cast = nil end
        if reason ~= "done" and self.animGen then SHIBI.Anim.Stop(ply, self.animGen) end
    end
    if def.OnEnd then
        local ok, err = pcall(def.OnEnd, self, ply, reason)
        if not ok then SHIBI.LogError("[Abilities] " .. def.id .. " OnEnd: " .. tostring(err)) end
    end
end

function A.IsUnlocked(ply, id)
    local def = A.List[id]
    if not def or not def.category then return false end
    if not IsValid(ply) then return false end

    local st = ply.SHIBI_AbilityState
    return st ~= nil and st.unlocked[id] == true
end

local function Check(ply, def, s, now)
    if not ply:Alive() then return "dead" end
    if s.cast then return "busy" end
    if now < s.gcd then return "gcd" end
    if now < (s.cd[def.id] or 0) then return "cooldown" end
    if ply:InVehicle() then return "vehicle" end
    if SHIBI.IsStunned(ply) then return "stunned" end
    if ply:GetNW2Bool("SHIBI::Dash::Active", false) then return "dash" end
    if not A.IsUnlocked(ply, def.id) then return "locked" end
    if def.ground and not ply:OnGround() then return "air" end
    if def.CanCast and def.CanCast(ply) == false then return "custom" end
    if hook.Run("SHIBI.Ability.CanCast", ply, def) == false then return "hook" end
    if def.cost > 0 and not SHIBI.Stamina.TrySpend(ply, def.cost) then return "mana" end
end

local function ApplyFeel(ply, feel)
    if not istable(feel) then return end

    local punch = feel.punch
    if istable(punch) then
        ply:ViewPunch(Angle(
            tonumber(punch.pitch) or 0,
            math.Rand(-(tonumber(punch.yaw) or 0), tonumber(punch.yaw) or 0),
            math.Rand(-(tonumber(punch.roll) or 0), tonumber(punch.roll) or 0)
        ))
    end

    local shake = feel.shake
    if istable(shake) and SHIBI.ScreenShake then
        SHIBI.ScreenShake(ply, shake.amp, shake.freq, shake.dur, shake.opts)
    end
end

function A.Cast(ply, id)
    if not IsValid(ply) then return false, "invalid" end
    local def = A.List[id]
    if not def then return false, "unknown" end

    local s, now = St(ply), CurTime()
    local fail = Check(ply, def, s, now)
    if fail then return false, fail end

    s.gcd = now + A.GlobalCooldown
    A.SetCooldown(ply, id, def.cooldown)

    local ctx = setmetatable({ ply = ply, def = def, alive = true, start = now }, CTX)
    s.cast = ctx

    local ok, err = pcall(def.OnCast, ctx, ply)
    if not ok then
        SHIBI.LogError("[Abilities] " .. id .. " OnCast: " .. tostring(err))
        ctx:End("error")
        return false, "error"
    end
    if ctx.alive then
        ctx:Wait(def.duration, function(c) c:End("done") end)
    end

    if SERVER then ApplyFeel(ply, def.feel) end
    return true
end

function A.Interrupt(ply, reason)
    local s = State[ply]
    if s and s.cast then s.cast:End(reason or "interrupt") end
end

function A.IsCasting(ply)
    local s = State[ply]
    return s ~= nil and s.cast ~= nil
end

function A.SetCooldown(ply, id, seconds)
    local def = A.List[id]
    if not def then return end
    seconds = tonumber(seconds) or 0
    local t = seconds > 0 and CurTime() + seconds or 0
    St(ply).cd[id] = t
    ply:SetNW2Float(def.cdKey, t)
end

function A.ResetCooldowns(ply)
    local s = State[ply]
    if not s then return end
    for id in pairs(s.cd) do A.SetCooldown(ply, id, 0) end
end

function A.Reload()
    for _, f in ipairs(file.Find(LIST_DIR .. "sv_*.lua", "LUA")) do
        include(LIST_DIR .. f)
    end
end

local function Loaded()
    local ids = table.GetKeys(A.List)
    table.sort(ids)
    return #ids > 0 and table.concat(ids, ", ") or "ничего"
end

hook.Add("PlayerDeath", "SHIBI::Abilities", function(ply) A.Interrupt(ply, "death") end)
hook.Add("PlayerDisconnected", "SHIBI::Abilities", function(ply) A.Interrupt(ply, "disconnect") end)
hook.Add("PlayerSpawn", "SHIBI::Abilities", function(ply)
    A.Interrupt(ply, "spawn")
    if A.ResetOnSpawn then A.ResetCooldowns(ply) end
end)
hook.Add("InitPostEntity", "SHIBI::Abilities", function()
    SHIBI.Log("[Abilities] загружены: " .. Loaded())
end)

net.Receive(NET_CAST, function(_, ply)
    local s, now = St(ply), CurTime()
    if now < s.net then return end
    s.net = now + A.NetThrottle

    local id = net.ReadString()
    if #id == 0 or #id > MAX_ID_LEN then return end
    A.Cast(ply, id)
end)

local function Reply(ply, msg)
    msg = "[Abilities] " .. msg
    if IsValid(ply) then
        ply:PrintMessage(HUD_PRINTCONSOLE, msg .. "\n")
    else
        print(msg)
    end
end

concommand.Add("shibi_ability", function(ply, _, args)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end
    local id = args[1] or ""
    local ok, reason = A.Cast(ply, id)
    Reply(ply, id .. ": " .. (ok and "ok" or (reason == "unknown" and "unknown, загружены: " .. Loaded() or reason)))
end)

concommand.Add("shibi_ability_reload", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    A.Reload()
    Reply(ply, "загружены: " .. Loaded())
end)

SHIBI.Abilities = SHIBI.Abilities or {}
local A = SHIBI.Abilities
A.Catalog    = A.Catalog or {}
A.Categories = A.Categories or {}

SHIBI.AbilityRegistry = SHIBI.AbilityRegistry or {}
local R = SHIBI.AbilityRegistry

R.LockedIcon = "shibi_core/ability_menu/locked_icon"

function R.DefineCategory(id, data)
    assert(isstring(id) and istable(data), "[AbilityRegistry] bad category")
    data.id   = id
    data.name = data.name or id
    A.Categories[id] = data
    return data
end

function R.DefineAbility(id, data)
    assert(isstring(id) and id ~= "" and istable(data), "[AbilityRegistry] bad ability id")
    assert(not data.category or A.Categories[data.category],
        "[AbilityRegistry] " .. id .. ": неизвестная категория " .. tostring(data.category))

    data.name        = data.name or id
    data.description = data.description or ""
    data.icon        = isstring(data.icon) and data.icon or ""
    data.cooldown    = tonumber(data.cooldown) or 0
    data.cost        = tonumber(data.cost) or 0
    data.unlockCost  = tonumber(data.unlockCost) or 0

    A.Catalog[id] = data
    return data
end

-- начинаем с гетсуги, это классика
R.DefineCategory("starter", {
    name = "Начальные способности",
})

R.DefineCategory("starter2", {
    name = "Начальные способности",
})

R.DefineCategory("bankai", {
    name = "Банкай",
})

R.DefineAbility("getsuga", {
    category    = "starter",
    name        = "Гецуга",
    description = "Высвобождает дугу энергии перед игроком. Наносит урон всем врагам в конусе.",
    icon        = "materials/shibi_core/ability_menu/1ability",
    cooldown    = 1,
    cost        = 25,
    unlockCost  = 1,
})

R.DefineAbility("dash", {
    category    = "starter",
    name        = "Дэш",
    description = "Резкий рывок по направлению взгляда. Во время рывка вы летите без гравитации и наносите урон тем, кого задели.",
    icon        = "materials/shibi_core/ability_menu/2ability",
    cooldown    = 1,
    cost        = 15,
    unlockCost  = 1,
})

R.DefineAbility("takitsubo", {
    category    = "starter",
    name        = "Такицубо",
    description = "Призывает огненный удар с неба в точку прицела. Оглушает и наносит урон в радиусе.",
    icon        = "materials/shibi_core/ability_menu/3ability",
    cooldown    = 1,
    cost        = 30,
    unlockCost  = 2,
})

R.DefineAbility("tornado", {
    category    = "starter",
    name        = "Циклон",
    description = "Выпускает один вихрь. Если он задевает противника, то поднимает его вверх, затем отбрасывает, и при приземлении противник оглушён.",
    icon        = "materials/shibi_core/ability_menu/4ability",
    cooldown    = 1,
    cost        = 40,
    unlockCost  = 2,
})

R.DefineAbility("bankai", {
    category    = "starter",
    name        = "Пробуждение банкая",
    description = "Пробуждение банкая. Все рядом видят кат-сцену, персонаж замирает на время пробуждения.",
    icon        = "",
    cooldown    = 1,
    cost        = 1,
    unlockCost  = 3,
})

-- меню способностей. много UI, мало сна. не трогай, работает же
SHIBI.AbilitiesMenu = SHIBI.AbilitiesMenu or {}
local AM = SHIBI.AbilitiesMenu

if IsValid(AM.Frame) then AM.Frame:Remove() end
AM.Frame       = nil
AM._anims      = nil
AM._listenSlot = nil
AM._tabBtns    = nil
AM._actions    = nil
AM._pages      = nil

local MAT = {
    ["shibi_core/ability_menu/aizen"]                      = Material("shibi_core/ability_menu/aizen.png", "smooth"),
    ["shibi_core/ability_menu/line"]                       = Material("shibi_core/ability_menu/line.png", "smooth"),
    ["shibi_core/ability_menu/line2"]                      = Material("shibi_core/ability_menu/line2.png", "smooth"),
    ["shibi_core/ability_menu/circer"]                     = Material("shibi_core/ability_menu/circer.png", "smooth"),
    ["shibi_core/ability_menu/small_circe_Ability_noicon"] = Material("shibi_core/ability_menu/small_circe_Ability_noicon.png", "smooth"),
    ["shibi_core/ability_menu/locked_icon"]                = Material("shibi_core/ability_menu/locked_icon.png", "smooth"),
    ["shibi_core/ability_menu/return_button"]              = Material("shibi_core/ability_menu/return_button.png", "smooth"),
    ["shibi_core/ability_menu/return_icon"]                = Material("shibi_core/ability_menu/return_icon.png", "smooth"),
    ["shibi_core/ability_menu/text_ability"]               = Material("shibi_core/ability_menu/text_ability.png", "smooth"),
}

local function Mat(path)
    return MAT[path] or Material(path .. ".png", "smooth")
end

local vgui_Create     = vgui.Create
local IsValid         = IsValid
local input_IsKeyDown = input.IsKeyDown
local draw_RoundedBox = draw.RoundedBox
local math_Clamp      = math.Clamp
local math_Approach   = math.Approach
local math_exp        = math.exp
local RealTime        = RealTime
local FrameTime       = FrameTime

local CFG = {
    radius = 14,
    bg     = Color(25, 25, 25, 153),
    border = Color(255, 255, 255, 26),
    blur   = 6,
    topbar = { x = 329, y = 232, w = 1262, h = 58 },
    list   = { x = 329, y = 302, w = 859,  h = 593 },
    slots  = { x = 329 + 859 + 12, y = 302, w = 391, h = 593 },
    textAbility = { x = 346, y = 249, w = 248, h = 20 },

    anim = { duration = 0.28, stagger = 0.06 },

    defaultCategory = "starter",

    tabs = {
        startX = 357, startY = 330, boxW = 155, boxH = 40, boxRadius = 6,
        gap = 40, paddingX = 14,
        fontSize = 20, weight = 1000, italic = true,
        textColor       = Color(255, 255, 255, 255),
        textColorActive = Color(25, 25, 25, 255),
        bgColor         = Color(215, 68, 49, 255),
        hoverSpeed = 0.18, activeSpeed = 0.20, moveSpeed = 14,
    },

    section = {
        x = 357, y = 406, text = "НАЧАЛЬНЫЕ СПОСОБНОСТИ",
        textColor = Color(255, 255, 255, 255),
        lineGap = 9, lineMaterial = "shibi_core/ability_menu/line",
        lineW = 564, lineH = 1,
        bgOffsetY = 13, bgW = 813, bgH = 122, bgRadius = 10,
        bgColor = Color(25, 25, 25, 26),
        circleMaterial = "shibi_core/ability_menu/circer",
        circleSize = 86, circlePadLeft = 19,
        iconMaterial   = "shibi_core/ability_menu/small_circe_Ability_noicon",
        lockedMaterial = "shibi_core/ability_menu/locked_icon",
        iconSize = 72, iconCount = 7, iconGap = 28,
        selGlowColor = Color(215, 68, 49, 255),
        selGlowAlpha = 0.40,
        selScale     = 0.08,
        hoverScale   = 0.08,
    },

    selected = {
        x = 440, y = 916,
        circleMaterial = "shibi_core/ability_menu/circer",
        iconMaterial = "shibi_core/ability_menu/small_circe_Ability_noicon",
        circleSize = 86, iconSize = 72, count = 6, gap = 28,
        numberY = 991,
        fontSize = 20, weight = 1000, italic = false,
        textColor   = Color(255, 255, 255, 255),
        listenColor = Color(215, 68, 49, 255),
    },

    aizen = { x = 1214, y = 269, w = 363, h = 208, material = "shibi_core/ability_menu/aizen" },

    preview = {
        x = 1214, y = 483, text = "Посмотреть превью способности",
        alphaIdle = 38, hoverSpeed = 0.12,
    },

    desc = {
        x = 1214, w = 363, lineY = 555, textY = 570,
        lineMaterial = "shibi_core/ability_menu/line2",
        lineGap = 14, maxH = 120,
    },

    infoPanel = {
        x = 1214, y = 318, w = 363, h = 159, radius = 5,
        color = Color(25, 25, 25, 26),
    },

    actionButtons = {
        w = 175, h = 36, radius = 5, gap = 11, y = 506,
        fontSize = 12, weight = 1000, italic = false,
        hoverLerp = 10, hoverFillBoost = 2.0,
        buttons = {
            { id = "learn", x = 1214, label = "ИЗУЧИТЬ НАВЫК",
              color = Color(215, 68, 49, 255), fill = Color(215, 68, 49, 38) },
            { id = "apply", x = 1400, label = "ПРИМЕНИТЬ НАВЫК",
              color = Color(52, 199, 89, 255), fill = Color(52, 199, 89, 38) },
        },
    },

    closeBtn = {
        x = 1544, y = 245, size = 33, iconSize = 14,
        buttonMaterial = "shibi_core/ability_menu/return_button",
        iconMaterial   = "shibi_core/ability_menu/return_icon",
        hoverScale = 1.12, hoverLerpSpeed = 10, brightenMax = 0.20,
    },
}

local SLOT_COUNT  = CFG.selected.count
local DEFAULT_KEY = function(i) return KEY_1 + i - 1 end

local NET_SAVE   = "SHIBI::Ability::SaveLoadout"
local NET_LOAD   = "SHIBI::Ability::Loadout"
local NET_UNLOCK = "SHIBI::Ability::Unlock"

AM.ClientList = AM.ClientList or {}
AM.Categories = AM.Categories or {}
AM.Loadout    = AM.Loadout or {}
AM.Points     = AM.Points or 0
AM._selected  = AM._selected or nil
AM._page      = AM._page or 1
AM._tab       = AM._tab or "all"
AM._category  = AM._category or CFG.defaultCategory

local function EaseOutCubic(t)
    local u = 1 - t
    return 1 - u * u * u
end

local function Alpha(c, f)
    return Color(c.r, c.g, c.b, c.a * f)
end

local function IconPath(id, fallback)
    local def = id and AM.ClientList[id]
    if def and isstring(def.icon) and def.icon ~= "" then return def.icon end
    return fallback
end

local function IsUnlocked(id)
    local def = id and AM.ClientList[id]
    return def ~= nil and def.unlocked == true
end

local function CategoryOwned(id)
    local c = id and AM.Categories[id]
    return c ~= nil and c.owned == true
end

local MATERIAL_PATHS = {
    CFG.section.lineMaterial, CFG.section.circleMaterial,
    CFG.section.iconMaterial, CFG.section.lockedMaterial,
    CFG.selected.circleMaterial, CFG.selected.iconMaterial,
    CFG.closeBtn.buttonMaterial, CFG.closeBtn.iconMaterial,
    CFG.aizen.material, CFG.desc.lineMaterial,
    "shibi_core/ability_menu/text_ability",
}

local function PrecacheMaterials()
    for _, p in ipairs(MATERIAL_PATHS) do
        local m = Mat(p)
        if m:IsError() then
            MsgC(Color(230, 60, 60), "[AbilitiesMenu] материал не найден: materials/" .. p .. ".png (или .jpg/.vmt)\n")
        end
    end
end

PrecacheMaterials()

local blurMat = Material("pp/blurscreen")

function AM.DrawBlur(panel, amount)
    if amount <= 0 then return end
    local px, py = panel:LocalToScreen(0, 0)
    surface.SetDrawColor(255, 255, 255, 255)
    surface.SetMaterial(blurMat)
    for i = 1, 3 do
        blurMat:SetFloat("$blur", (i / 3) * amount)
        blurMat:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(-px, -py, ScrW(), ScrH())
    end
end

local function AddOpenAnim(p, delay)
    p:SetAlpha(0)
    AM._anims = AM._anims or {}
    AM._anims[#AM._anims + 1] = {
        p   = p,
        t0  = RealTime() + (delay or 0),
        dur = CFG.anim.duration,
    }
end

local function DriveOpenAnims()
    local anims = AM._anims
    if not anims then return end

    local now = RealTime()
    for i = #anims, 1, -1 do
        local a = anims[i]
        if not IsValid(a.p) then
            table.remove(anims, i)
        else
            local t = math_Clamp((now - a.t0) / a.dur, 0, 1)
            if t > 0 then
                a.p:SetAlpha(math.floor(EaseOutCubic(t) * 255 + 0.5))
            end
            if t >= 1 then table.remove(anims, i) end
        end
    end

    if #anims == 0 then AM._anims = nil end
end

local function SaveLoadout()
    if not IsValid(LocalPlayer()) then return end
    net.Start(NET_SAVE)
        for i = 1, SLOT_COUNT do
            local s = AM.Loadout[i]
            net.WriteBool(s ~= nil)
            if s then
                net.WriteString(s.id)
                net.WriteUInt(s.key or DEFAULT_KEY(i), 8)
            end
        end
    net.SendToServer()
end

local function RequestUnlock(id)
    net.Start(NET_UNLOCK)
        net.WriteString(id)
    net.SendToServer()
end

local function CanAssign(id)
    return id ~= nil and AM.ClientList[id] ~= nil and IsUnlocked(id)
end

local function AssignAbility(slot, id)
    for i = 1, SLOT_COUNT do
        local other = AM.Loadout[i]
        if i ~= slot and other and other.id == id then AM.Loadout[i] = nil end
    end

    local old = AM.Loadout[slot]
    AM.Loadout[slot] = { id = id, key = (old and old.key) or DEFAULT_KEY(slot) }
    SaveLoadout()
    AM.RefreshSlots()
    if AM._tab ~= "all" then AM.RefreshSection() end
end

local function ClearSlot(slot)
    AM.Loadout[slot] = nil
    SaveLoadout()
    AM.RefreshSlots()
    if AM._tab ~= "all" then AM.RefreshSection() end
end

function AM.AssignFirstFree(id)
    if not CanAssign(id) then return false end
    for i = 1, SLOT_COUNT do
        local entry = AM.Loadout[i]
        if entry and entry.id == id then return false end
    end
    for i = 1, SLOT_COUNT do
        if not AM.Loadout[i] then
            AssignAbility(i, id)
            return true
        end
    end
    return false
end

function AM.ClearSelection()
    if not AM._selected then return end
    AM._selected = nil
    AM.RefreshInfo()
    if SHIBI.PlaySound then SHIBI.PlaySound("mugen/ui/notifications/undo.mp3") end
end

net.Receive(NET_LOAD, function()
    local cats = {}
    for _ = 1, net.ReadUInt(8) do
        local id    = net.ReadString()
        local name  = net.ReadString()
        local owned = net.ReadBool()
        cats[id] = { id = id, name = name, owned = owned }
    end
    AM.Categories = cats

    local list = {}
    for _ = 1, net.ReadUInt(8) do
        local id          = net.ReadString()
        local name        = net.ReadString()
        local description = net.ReadString()
        local icon        = net.ReadString()
        local category    = net.ReadString()
        local cooldown    = net.ReadFloat()
        local cost        = net.ReadUInt(16)
        local unlockCost  = net.ReadUInt(16)
        local unlocked    = net.ReadBool()

        list[id] = {
            name = name, description = description, icon = icon,
            category = category, cooldown = cooldown, cost = cost,
            unlockCost = unlockCost, unlocked = unlocked,
        }
    end
    AM.ClientList = list
    AM.Points     = net.ReadUInt(16)

    AM.Loadout = {}
    for i = 1, SLOT_COUNT do
        if net.ReadBool() then
            local id  = net.ReadString()
            local key = net.ReadUInt(8)
            AM.Loadout[i] = { id = id, key = key }
        end
    end

    if AM._selected and not AM.ClientList[AM._selected] then
        AM._selected = nil
    end

    if IsValid(AM.Frame) then
        AM.RefreshSection()
        AM.RefreshSlots()
        AM.RefreshInfo()
    end
end)

local keyPrev = {}

hook.Add("Think", "SHIBI::AbilitiesMenu::Cast", function()
    local ply = LocalPlayer()
    local active = not IsValid(AM.Frame)
        and IsValid(ply) and ply:Alive()
        and vgui.GetKeyboardFocus() == nil
        and not gui.IsConsoleVisible()

    for i = 1, SLOT_COUNT do
        local s    = AM.Loadout[i]
        local down = false
        if s and AM.ClientList[s.id] then
            down = input_IsKeyDown(s.key or DEFAULT_KEY(i))
            if active and down and not keyPrev[i] then
                SHIBI.Abilities.Request(s.id)
            end
        end
        keyPrev[i] = down
    end
end)

local bindWasDown = {}
local bindInit    = false

local function IsBindable(code)
    return code ~= MOUSE_LEFT and code ~= MOUSE_RIGHT and code ~= KEY_ESCAPE
end

local function ResetBindState()
    bindInit = false
    for k in pairs(bindWasDown) do bindWasDown[k] = nil end
end

local function BindKey(slot, code)
    local entry = AM.Loadout[slot]
    if not entry then return end

    local old = entry.key or DEFAULT_KEY(slot)
    for i = 1, SLOT_COUNT do
        local other = AM.Loadout[i]
        if i ~= slot and other and other.key == code then
            other.key = old
        end
    end

    entry.key = code
    SaveLoadout()
    AM.RefreshSlots()
    if SHIBI.PlaySound then SHIBI.PlaySound("mugen/ui/notifications/generic.mp3") end
end

hook.Add("Think", "SHIBI::AbilitiesMenu::BindPoll", function()
    local slot = AM._listenSlot
    if not slot then
        if bindInit then ResetBindState() end
        return
    end
    if not IsValid(AM.Frame) then
        AM._listenSlot = nil
        return
    end

    if not bindInit then
        bindInit = true
        for code = 1, 255 do bindWasDown[code] = input_IsKeyDown(code) end
        return
    end

    for code = 1, 255 do
        local down    = input_IsKeyDown(code)
        local wasDown = bindWasDown[code] or false
        bindWasDown[code] = down

        if down and not wasDown and IsBindable(code) then
            BindKey(slot, code)
            AM._listenSlot = nil
            ResetBindState()
            return
        end
    end
end)

local function GlassPanel(parent, data, delay)
    local p = vgui_Create("DPanel", parent)
    p:SetSize(SHIBI.ResponsiveX(data.w), SHIBI.ResponsiveY(data.h))
    p:SetPos(SHIBI.ResponsiveX(data.x), SHIBI.ResponsiveY(data.y))
    local rad = SHIBI.ResponsiveY(CFG.radius)
    p.Paint = function(self, w, h)
        local f = self:GetAlpha() / 255
        if f <= 0 then return end
        AM.DrawBlur(self, CFG.blur * f)
        draw_RoundedBox(rad, 0, 0, w, h, Alpha(CFG.bg, f))
        paint.startVGUI()
            SHIBI.DrawOutlinedBox(rad, 0, 0, w, h, Alpha(CFG.border, f), 1)
        paint.endVGUI()
    end
    AddOpenAnim(p, delay or 0)
    return p
end

local function MatPanel(parent, path, x, y, w, h, delay)
    local p = vgui_Create("DPanel", parent)
    p:SetSize(SHIBI.ResponsiveX(w), SHIBI.ResponsiveY(h))
    p:SetPos(SHIBI.ResponsiveX(x), SHIBI.ResponsiveY(y))
    p:SetMouseInputEnabled(false)
    p.Paint = function(self, ww, hh)
        local a = self:GetAlpha()
        if a <= 0 then return end
        surface.SetDrawColor(255, 255, 255, a)
        surface.SetMaterial(Mat(path))
        surface.DrawTexturedRect(0, 0, ww, hh)
    end
    AddOpenAnim(p, delay or 0)
    return p
end

local function MakeFont(name, size, weight, italic)
    return SHIBI.Fonts:CreateEx("Inter", name, size, { weight = weight, italic = italic, suffix = name })
end

local tabFont, btnFont, keyFont, descFont, previewFont, rowFont, rowSubFont, bindDescFont

local function Fonts()
    tabFont     = tabFont     or MakeFont("AbTab",     CFG.tabs.fontSize,          CFG.tabs.weight,          CFG.tabs.italic)
    btnFont     = btnFont     or MakeFont("AbBtn",     CFG.actionButtons.fontSize, CFG.actionButtons.weight, CFG.actionButtons.italic)
    keyFont     = keyFont     or MakeFont("AbKey",     14,   1000, false)
    descFont    = descFont    or MakeFont("AbDesc",    10,   700,  false)
    previewFont = previewFont or MakeFont("AbPreview", 10,   700,  false)
    rowFont     = rowFont     or MakeFont("AbRow",     15,   700,  false)
    rowSubFont  = rowSubFont  or MakeFont("AbRowSub",  11,   700,  false)
    bindDescFont = bindDescFont or MakeFont("AbBindDesc", 13, 500, false)
    return tabFont
end

local function WrapText(text, font, maxW)
    surface.SetFont(font)
    local lines, line = {}, ""
    for word in string.gmatch(text or "", "%S+") do
        local try = (line == "") and word or (line .. " " .. word)
        if line ~= "" and surface.GetTextSize(try) > maxW then
            lines[#lines + 1] = line
            line = word
        else
            line = try
        end
    end
    if line ~= "" then lines[#lines + 1] = line end
    return lines
end

local TABS = {
    { id = "all",   label = "ВСЕ НАВЫКИ" },
    { id = "yours", label = "ВАШИ СПОСОБНОСТИ" },
    { id = "binds", label = "БИНДЫ" },
}

local function BuildTabs(f)
    local t    = CFG.tabs
    local font = Fonts()
    surface.SetFont(font)

    local bg = vgui_Create("DPanel", f)
    bg:SetSize(0, SHIBI.ResponsiveY(t.boxH))
    bg:SetPos(SHIBI.ResponsiveX(t.startX), SHIBI.ResponsiveY(t.startY))
    bg:SetMouseInputEnabled(false)
    bg._tx, bg._tw = SHIBI.ResponsiveX(t.startX), 0
    bg._cx, bg._cw = bg._tx, bg._tw
    local rad = SHIBI.ResponsiveY(t.boxRadius)
    local col = t.bgColor
    bg.Paint = function(self, w, h)
        local a = self:GetAlpha()
        if a <= 0 or w <= 1 then return end
        draw_RoundedBox(rad, 0, 0, w, h, Color(col.r, col.g, col.b, col.a * a / 255))
    end
    bg.Think = function(self)
        local sp = t.moveSpeed * FrameTime() * 60
        self._cx = math_Approach(self._cx, self._tx, sp)
        self._cw = math_Approach(self._cw, self._tw, sp)
        self:SetPos(self._cx, SHIBI.ResponsiveY(t.startY))
        self:SetSize(self._cw, SHIBI.ResponsiveY(t.boxH))
    end
    AddOpenAnim(bg, CFG.anim.stagger * 3)

    AM._tabBtns = {}
    local x = SHIBI.ResponsiveX(t.startX)
    local y = SHIBI.ResponsiveY(t.startY)

    local function SelectTab(id, silent)
        if AM._tab == id and not silent then return end
        AM._tab = id
        for _, b in ipairs(AM._tabBtns) do
            b._active = (b._id == id)
            if b._active then bg._tx, bg._tw = b:GetX(), b:GetWide() end
        end
        AM._page = 1
        AM.ApplyTabLayout()
        AM.RefreshSection()
        if not silent and SHIBI.PlaySound then SHIBI.PlaySound("mugen/ui/notifications/generic.mp3") end
    end
    AM.SelectTab = SelectTab

    for i, tab in ipairs(TABS) do
        local tw = surface.GetTextSize(tab.label)
        local w  = math.max(SHIBI.ResponsiveX(t.boxW), tw + SHIBI.ResponsiveX(t.paddingX) * 2)
        local b  = vgui_Create("DButton", f)
        b:SetText("")
        b:SetSize(w, SHIBI.ResponsiveY(t.boxH))
        b:SetPos(x, y)
        b._id, b._label, b._font = tab.id, tab.label, font
        b._hoverK, b._activeK, b._active = 0, 0, false
        b.Paint = function(self, ww, hh)
            local a = self:GetAlpha() / 255
            if a <= 0 then return end
            local k = self._activeK
            local c = t.textColor
            local d = t.textColorActive
            SHIBI.DrawSimpleText(self._label, self._font, ww * .5, hh * .5,
                Color(c.r + (d.r - c.r) * k, c.g + (d.g - c.g) * k, c.b + (d.b - c.b) * k, c.a * a), 1, 1)
        end
        b.Think = function(self)
            local dt = FrameTime()
            self._hoverK  = math_Approach(self._hoverK,  self:IsHovered() and 1 or 0, dt / t.hoverSpeed)
            self._activeK = math_Approach(self._activeK, self._active and 1 or 0, dt / t.activeSpeed)
        end
        b.DoClick = function(self) SelectTab(self._id) end
        b:SetCursor("hand")
        AddOpenAnim(b, CFG.anim.stagger * (3 + i))
        AM._tabBtns[i] = b
        x = x + w + SHIBI.ResponsiveX(t.gap)
    end

    SelectTab(AM._tab or "all", true)
end

local function SectionItems()
    local out = {}
    if not CategoryOwned(AM._category) then return out end

    if AM._tab == "all" then
        for id, def in pairs(AM.ClientList) do
            if def.category == AM._category then
                out[#out + 1] = id
            end
        end
        table.sort(out)
        return out
    end
    for i = 1, SLOT_COUNT do
        local s = AM.Loadout[i]
        if s and AM.ClientList[s.id] then out[#out + 1] = s.id end
    end
    return out
end

local sectionIcons = {}

function AM.RefreshSection()
    if not IsValid(AM.Frame) then return end

    local s     = CFG.section
    local items = SectionItems()
    local per   = s.iconCount
    local pages = math.max(1, math.ceil(#items / per))

    AM._pages = pages
    AM._page  = math_Clamp(AM._page, 1, pages)

    for i = 1, per do
        local icon = sectionIcons[i]
        if not IsValid(icon) then break end

        local id = items[(AM._page - 1) * per + i]
        icon._id = id

        if id and IsUnlocked(id) then
            icon._path = IconPath(id, s.iconMaterial)
        elseif id then
            icon._path = s.lockedMaterial
        else
            icon._path = nil
        end

        icon._selK = (id and AM._selected == id) and 1 or 0
    end

    AM.RefreshBindRows()
end

local function BuildSection(f)
    local s    = CFG.section
    local font = Fonts()
    surface.SetFont(font)
    local _, th = surface.GetTextSize(s.text)

    local lbl = vgui_Create("DPanel", f)
    lbl:SetSize(SHIBI.ResponsiveX(s.bgW), math.max(th, 1))
    lbl:SetPos(SHIBI.ResponsiveX(s.x), SHIBI.ResponsiveY(s.y))
    lbl:SetMouseInputEnabled(false)
    lbl.Paint = function(self, w, h)
        local a = self:GetAlpha()
        if a <= 0 then return end

        local cat   = AM.Categories[AM._category]
        local title = (cat and cat.name) or s.text
        surface.SetFont(font)
        local tw = surface.GetTextSize(title)

        SHIBI.DrawSimpleText(title, font, 0, h * .5, Color(s.textColor.r, s.textColor.g, s.textColor.b, a), 0, 1)

        surface.SetDrawColor(255, 255, 255, a)
        surface.SetMaterial(Mat(s.lineMaterial))
        surface.DrawTexturedRect(tw + SHIBI.ResponsiveX(s.lineGap), h * .5 - 1, SHIBI.ResponsiveX(s.lineW), 1)

        SHIBI.DrawSimpleText("", keyFont, w, h * .5,
            Color(s.textColor.r, s.textColor.g, s.textColor.b, a), 2, 1)
    end
    lbl._ab = "normal"
    AddOpenAnim(lbl, CFG.anim.stagger * 6)

    local bgY = SHIBI.ResponsiveY(s.y) + th + SHIBI.ResponsiveY(s.bgOffsetY)
    local bg  = vgui_Create("DPanel", f)
    bg:SetSize(SHIBI.ResponsiveX(s.bgW), SHIBI.ResponsiveY(s.bgH))
    bg:SetPos(SHIBI.ResponsiveX(s.x), bgY)
    bg:SetPaintBackground(false)

    local cSize  = SHIBI.ResponsiveY(s.circleSize)
    local step   = cSize + SHIBI.ResponsiveX(s.iconGap)
    local firstX = SHIBI.ResponsiveX(s.circlePadLeft)
    local bgRad  = SHIBI.ResponsiveY(s.bgRadius)
    local bgc    = s.bgColor

    bg.Paint = function(self, w, h)
        local a = self:GetAlpha()
        if a <= 0 then return end
        AM.DrawBlur(self, CFG.blur * a / 255)
        draw_RoundedBox(bgRad, 0, 0, w, h, Color(bgc.r, bgc.g, bgc.b, bgc.a * a / 255))
        local cy = (h - cSize) * .5
        surface.SetDrawColor(255, 255, 255, a)
        surface.SetMaterial(Mat(s.circleMaterial))
        for i = 0, s.iconCount - 1 do
            surface.DrawTexturedRect(firstX + i * step, cy, cSize, cSize)
        end
    end
    bg.OnMouseWheeled = function(_, d)
        if AM._pages and AM._pages > 1 then
            AM._page = math_Clamp(AM._page - d, 1, AM._pages)
            AM.RefreshSection()
        end
    end
    bg._ab = "normal"
    AddOpenAnim(bg, CFG.anim.stagger * 7)

    local iSize = SHIBI.ResponsiveY(s.iconSize)
    local cy    = (bg:GetTall() - cSize) * .5

    for i = 1, s.iconCount do
        local icon = vgui_Create("DButton", bg)
        icon:SetText("")
        icon:SetSize(cSize, cSize)
        icon:SetPos(firstX + (i - 1) * step, cy)
        icon._id, icon._path = nil, nil
        icon._hoverK, icon._selK = 0, 0

        icon.Paint = function(self, w, h)
            local a = self:GetAlpha()
            if a <= 0 then return end
            if not self._id or not self._path then return end

            if self._selK > 0.01 then
                local gc    = s.selGlowColor
                local glowA = gc.a * self._selK * a / 255 * s.selGlowAlpha
                draw_RoundedBox(w * 0.5, 0, 0, w, h, Color(gc.r, gc.g, gc.b, glowA))
            end

            local scale = 1 + self._hoverK * s.hoverScale + self._selK * s.selScale
            local dw    = iSize * scale
            surface.SetDrawColor(255, 255, 255, a)
            surface.SetMaterial(Mat(self._path))
            surface.DrawTexturedRect((w - dw) * .5, (h - dw) * .5, dw, dw)
        end

        icon.Think = function(self)
            local dt = FrameTime()
            self._hoverK = math_Approach(self._hoverK, (self._id and self:IsHovered()) and 1 or 0, dt / .15)
            local target = (self._id and AM._selected == self._id) and 1 or 0
            self._selK = math_Approach(self._selK, target, dt / .18)
        end

        icon.DoClick = function(self)
            if not self._id then return end
            AM._selected = (AM._selected == self._id) and nil or self._id
            AM.RefreshInfo()
            if SHIBI.PlaySound then SHIBI.PlaySound("mugen/ui/notifications/generic.mp3") end
        end

        icon.DoRightClick = function(self)
            if self._id and AM._selected == self._id then AM.ClearSelection() end
        end

        icon:SetCursor("hand")
        AddOpenAnim(icon, i * 0.03)
        sectionIcons[i] = icon
    end
end

local infoPanel, descPanel

function AM.RefreshInfo()
    Fonts()
    local id = AM._selected

    if IsValid(infoPanel) then infoPanel._id = id end

    if IsValid(descPanel) then
        local def = id and AM.ClientList[id]
        descPanel._lines = def and WrapText(def.description, descFont, CFG.desc.w) or {}
    end

    local card = AM._bindCard
    if IsValid(card) then
        local def = id and AM.ClientList[id]
        card._name  = def and def.name or "Выберите способность"
        card._lines = WrapText(def and def.description or "Нажмите на способность слева, чтобы увидеть её описание.",
            bindDescFont, SHIBI.ResponsiveX(CFG.infoPanel.w - 32))
    end
end

local function BuildPreview(f)
    local a = CFG.aizen
    MatPanel(f, a.material, a.x, a.y, a.w, a.h, 0.02)._ab = "normal"
end

local function BuildDescription(f)
    local d = CFG.desc
    MatPanel(f, d.lineMaterial, d.x, d.lineY, d.w, 1, 0.04)._ab = "normal"

    descPanel = vgui_Create("DPanel", f)
    descPanel:SetSize(SHIBI.ResponsiveX(d.w), SHIBI.ResponsiveY(d.maxH))
    descPanel:SetPos(SHIBI.ResponsiveX(d.x), SHIBI.ResponsiveY(d.textY))
    descPanel:SetMouseInputEnabled(false)
    descPanel._lines = {}
    descPanel.Paint = function(self, w, h)
        local a = self:GetAlpha()
        if a <= 0 then return end
        local y = 0
        for _, line in ipairs(self._lines or {}) do
            SHIBI.DrawSimpleText(line, descFont, 0, y, Color(255, 255, 255, a), 0, 0)
            y = y + d.lineGap
        end
    end
    descPanel._ab = "normal"
    AddOpenAnim(descPanel, 0.06)
end

local function BuildPreviewButton(f)
    local p    = CFG.preview
    local font = Fonts()
    surface.SetFont(font)
    local tw, th = surface.GetTextSize(p.text)

    local b = vgui_Create("DButton", f)
    b:SetText("")
    b:SetSize(tw, th)
    b:SetPos(SHIBI.ResponsiveX(p.x), SHIBI.ResponsiveY(p.y))
    b._k = 0

    b.Paint = function(self, w, h)
        local a = self:GetAlpha() / 255
        if a <= 0 then return end
        local alpha = (p.alphaIdle + (255 - p.alphaIdle) * self._k) * a
        SHIBI.DrawSimpleText(p.text, previewFont, 0, h * .5, Color(255, 255, 255, math.floor(alpha)), 0, 1)
    end
    b.Think = function(self)
        self._k = math_Approach(self._k, self:IsHovered() and 1 or 0, FrameTime() / p.hoverSpeed)
    end
    b.DoClick = function() end

    b:SetCursor("hand")
    b._ab = "normal"
    AddOpenAnim(b, 0.08)
end

local function BuildInfoPanel(f)
    local i = CFG.infoPanel
    infoPanel = vgui_Create("DPanel", f)
    infoPanel:SetSize(SHIBI.ResponsiveX(i.w), SHIBI.ResponsiveY(i.h))
    infoPanel:SetPos(SHIBI.ResponsiveX(i.x), SHIBI.ResponsiveY(i.y))
    infoPanel:SetMouseInputEnabled(false)
    infoPanel._id = AM._selected
    local rad = SHIBI.ResponsiveY(i.radius)
    local col = i.color

    infoPanel.Paint = function(self, w, h)
        local a = self:GetAlpha()
        if a <= 0 then return end
        draw_RoundedBox(rad, 0, 0, w, h, Color(col.r, col.g, col.b, col.a * a / 255))
    end
    infoPanel._ab = "normal"
    AddOpenAnim(infoPanel, CFG.anim.stagger * 2)
end

local slotPanels = {}

function AM.RefreshSlots()
    for i, slot in ipairs(slotPanels) do
        if not IsValid(slot) then break end
        local data = AM.Loadout[i]
        slot._id   = data and data.id or nil
        slot._key  = data and (data.key or DEFAULT_KEY(i)) or nil
        slot._path = slot._id and IconPath(slot._id, CFG.selected.iconMaterial) or nil
    end
end

local function BuildSlots(f)
    local s     = CFG.selected
    Fonts()
    local cSize = SHIBI.ResponsiveY(s.circleSize)
    local iSize = SHIBI.ResponsiveY(s.iconSize)
    local step  = cSize + SHIBI.ResponsiveX(s.gap)
    local numY  = SHIBI.ResponsiveY(s.numberY) - SHIBI.ResponsiveY(s.y)

    for i = 1, s.count do
        local slot = vgui_Create("DButton", f)
        slot:SetText("")
        slot:SetSize(cSize, cSize)
        slot:SetPos(SHIBI.ResponsiveX(s.x) + (i - 1) * step, SHIBI.ResponsiveY(s.y))
        slot._id, slot._path, slot._key = nil, nil, nil
        slot._hoverK = 0

        slot.Paint = function(self, w, h)
            local a = self:GetAlpha()
            if a <= 0 then return end
            local f2     = a / 255
            local scale  = 1 + self._hoverK * 0.06
            local dw, dh = w * scale, h * scale
            local dx, dy = (w - dw) * .5, (h - dh) * .5

            surface.SetDrawColor(255, 255, 255, a)
            surface.SetMaterial(Mat(s.circleMaterial))
            surface.DrawTexturedRect(dx, dy, dw, dh)

            if self._path then
                local iw = iSize * scale
                surface.SetDrawColor(255, 255, 255, a)
                surface.SetMaterial(Mat(self._path))
                surface.DrawTexturedRect((w - iw) * .5, (h - iw) * .5, iw, iw)
            end

            local listening = AM._listenSlot == i
            local tc = listening and s.listenColor or s.textColor
            if listening then
                if math.sin(RealTime() * 6) > 0 then
                    SHIBI.DrawSimpleText("КЛАВИША?", keyFont, w * .5, numY, Color(tc.r, tc.g, tc.b, a), 1, 1)
                end
            elseif self._key then
                local name = input.GetKeyName(self._key) or "?"
                SHIBI.DrawSimpleText(string.upper(name), keyFont, w * .5, numY,
                    Color(tc.r, tc.g, tc.b, tc.a * f2), 1, 1)
            end
        end

        slot.Think = function(self)
            self._hoverK = math_Approach(self._hoverK, self:IsHovered() and 1 or 0, FrameTime() / .15)
        end

        slot.DoClick = function(self)
            if AM._tab == "binds" then
                if CanAssign(AM._selected) then
                    AssignAbility(i, AM._selected)
                    AM._listenSlot = i
                    ResetBindState()
                    if SHIBI.PlaySound then SHIBI.PlaySound("mugen/ui/notifications/generic.mp3") end
                elseif self._id then
                    AM._listenSlot = (AM._listenSlot == i) and nil or i
                    ResetBindState()
                end
                return
            end

            if CanAssign(AM._selected) then
                AssignAbility(i, AM._selected)
                if SHIBI.PlaySound then SHIBI.PlaySound("mugen/ui/notifications/generic.mp3") end
            elseif self._id then
                ClearSlot(i)
            end
        end

        slot.DoRightClick = function()
            if AM._tab == "binds" then
                if AM.Loadout[i] then ClearSlot(i) end
                return
            end
            AM.ClearSelection()
        end

        slot:SetCursor("hand")
        AddOpenAnim(slot, CFG.anim.stagger * 8 + i * 0.02)
        slotPanels[i] = slot
    end
end

local function BuildActionButtons(f)
    local a   = CFG.actionButtons
    Fonts()
    local rad = SHIBI.ResponsiveY(a.radius)
    AM._actions = {}

    for i, data in ipairs(a.buttons) do
        local b = vgui_Create("DButton", f)
        b:SetText("")
        b:SetSize(SHIBI.ResponsiveX(a.w), SHIBI.ResponsiveY(a.h))
        b:SetPos(SHIBI.ResponsiveX(data.x), SHIBI.ResponsiveY(a.y))
        b._id, b._hoverK = data.id, 0

        local col, fill = data.color, data.fill
        b.Paint = function(self, w, h)
            local f2 = self:GetAlpha() / 255
            if f2 <= 0 then return end
            local k = self._hoverK
            draw_RoundedBox(rad, 0, 0, w, h,
                Color(fill.r, fill.g, fill.b, fill.a * (1 + (a.hoverFillBoost - 1) * k) * f2))
            paint.startVGUI()
                SHIBI.DrawOutlinedBox(rad, 0, 0, w, h, Color(col.r, col.g, col.b, col.a * f2), 1)
            paint.endVGUI()
            SHIBI.DrawSimpleText(data.label, btnFont, w * .5, h * .5,
                Color(col.r, col.g, col.b, col.a * f2), 1, 1)
        end

        b.Think = function(self)
            local dt = FrameTime()
            local t  = self:IsHovered() and 1 or 0
            self._hoverK = self._hoverK + (t - self._hoverK) * math_Clamp(1 - math_exp(-a.hoverLerp * dt), 0, 1)
        end

        b.DoClick = function(self)
            local id = AM._selected

            if self._id == "learn" and id then
                local def = AM.ClientList[id]
                if def and not def.unlocked and CategoryOwned(def.category) then
                    if AM.Points >= (def.unlockCost or 0) then
                        RequestUnlock(id)
                    elseif SHIBI.PlaySound then
                        SHIBI.PlaySound("mugen/ui/notifications/undo.mp3")
                    end
                end
            elseif self._id == "apply" and id then
                AM.AssignFirstFree(id)
            end

            hook.Run("SHIBI.AbilitiesMenu.ActionPressed", self._id, id)
            if SHIBI.PlaySound then SHIBI.PlaySound("mugen/ui/notifications/generic.mp3") end
        end

        b:SetCursor("hand")
        b._ab = "normal"
        AddOpenAnim(b, CFG.anim.stagger * 8 + 0.15 + i * 0.03)
        AM._actions[data.id] = b
    end
end

local BIND = { rowX = 357, rowY = 412, rowW = 813, rowH = 50, rowGap = 6, rows = 8 }

local function BindItems()
    local out = {}
    for id, def in pairs(AM.ClientList) do
        if def.category == AM._category and def.unlocked then out[#out + 1] = id end
    end
    table.sort(out)
    return out
end

local function SlotOf(id)
    for i = 1, SLOT_COUNT do
        local s = AM.Loadout[i]
        if s and s.id == id then return i, s.key or DEFAULT_KEY(i) end
    end
    return nil
end

local function ResetBindPanels()
    AM._rows     = nil
    AM._rowEmpty = nil
    AM._bindCard = nil
    AM._rowPage  = 1
    AM._rowPages = 1
end

function AM.RefreshBindRows()
    if not AM._rows then return end
    for _, row in ipairs(AM._rows) do
        if not IsValid(row) then return end
    end

    local items = BindItems()
    local per   = BIND.rows
    local pages = math.max(1, math.ceil(#items / per))

    AM._rowPages = pages
    AM._rowPage  = math_Clamp(AM._rowPage or 1, 1, pages)

    for i, row in ipairs(AM._rows) do
        local id = items[(AM._rowPage - 1) * per + i]
        row._id       = id
        row._path     = id and IconPath(id, CFG.section.iconMaterial) or nil
        row._selected = id ~= nil and AM._selected == id
    end

    if IsValid(AM._rowEmpty) then AM._rowEmpty:SetVisible(#items == 0) end
end

local function BuildBindRows(f)
    local b = BIND
    Fonts()
    AM._rows = {}

    for i = 1, b.rows do
        local row = vgui_Create("DButton", f)
        row:SetText("")
        row:SetSize(SHIBI.ResponsiveX(b.rowW), SHIBI.ResponsiveY(b.rowH))
        row:SetPos(SHIBI.ResponsiveX(b.rowX), SHIBI.ResponsiveY(b.rowY) + (i - 1) * SHIBI.ResponsiveY(b.rowH + b.rowGap))
        row:SetCursor("hand")
        row._ab = "binds"
        row._id, row._path, row._selected = nil, nil, false
        row._hoverK, row._selK = 0, 0

        row.Paint = function(self, w, h)
            local a = self:GetAlpha()
            if a <= 0 or not self._id then return end
            local def = AM.ClientList[self._id]
            if not def then return end

            local f2  = a / 255
            local rad = SHIBI.ResponsiveY(8)
            local hk, sk = self._hoverK, self._selK

            draw_RoundedBox(rad, 0, 0, w, h, Color(12 + 10 * hk, 12 + 10 * hk, 12 + 10 * hk, (150 + 40 * hk) * f2))
            if sk > 0 then
                draw_RoundedBox(rad, 0, 0, w, h, Color(215, 68, 49, 34 * sk * f2))
                paint.startVGUI()
                    SHIBI.DrawOutlinedBox(rad, 0, 0, w, h, Color(215, 68, 49, 200 * sk * f2), 1)
                paint.endVGUI()
                draw_RoundedBox(2, 0, h * 0.2, 3, h * 0.6, Color(215, 68, 49, 255 * sk * f2))
            end

            local iconS = h - 14
            local ix, iy = 14, 7
            draw_RoundedBox(iconS * 0.5, ix - 1, iy - 1, iconS + 2, iconS + 2, Color(255, 255, 255, 18 * f2))
            surface.SetDrawColor(255, 255, 255, a)
            surface.SetMaterial(Mat(self._path))
            surface.DrawTexturedRect(ix, iy, iconS, iconS)

            local tx = ix + iconS + 14
            SHIBI.DrawSimpleText(def.name, rowFont, tx, h * 0.34, Color(255, 255, 255, a), 0, 1)
            SHIBI.DrawSimpleText(string.format("КД %gс   ·   МАНАКОСТ %d", def.cooldown or 0, math.floor(def.cost or 0)),
                rowSubFont, tx, h * 0.7, Color(255, 255, 255, 110 * f2), 0, 1)

            local _, key = SlotOf(self._id)
            local rightX = w - 14
            if key then
                local keyName = string.upper(input.GetKeyName(key) or "?")
                surface.SetFont(keyFont)
                local kw = math.max(36, surface.GetTextSize(keyName) + 18)
                local kh = h - 18
                local kx, ky = rightX - kw, (h - kh) * 0.5
                draw_RoundedBox(6, kx, ky, kw, kh, Color(242, 239, 238, 235 * f2))
                SHIBI.DrawSimpleText(keyName, keyFont, kx + kw * 0.5, ky + kh * 0.5,
                    Color(25, 25, 25, a), 1, 1)
            else
                SHIBI.DrawSimpleText("НЕ НАЗНАЧЕНО", rowSubFont, rightX, h * 0.5,
                    Color(255, 255, 255, 90 * f2), 2, 1)
            end
        end

        row.Think = function(self)
            local dt = FrameTime()
            self._hoverK = math_Approach(self._hoverK, self:IsHovered() and 1 or 0, dt / 0.12)
            self._selK   = math_Approach(self._selK, self._selected and 1 or 0, dt / 0.16)
        end

        row.DoClick = function(self)
            if not self._id then return end
            AM._selected = (AM._selected == self._id) and nil or self._id
            AM.RefreshInfo()
            AM.RefreshBindRows()
            if SHIBI.PlaySound then SHIBI.PlaySound("mugen/ui/notifications/generic.mp3") end
        end

        row.OnMouseWheeled = function(_, d)
            if (AM._rowPages or 1) > 1 then
                AM._rowPage = math_Clamp((AM._rowPage or 1) - d, 1, AM._rowPages)
                AM.RefreshBindRows()
            end
        end

        AM._rows[i] = row
    end

    AM._rowEmpty = vgui_Create("DPanel", f)
    AM._rowEmpty._ab = "binds"
    AM._rowEmpty:SetPos(SHIBI.ResponsiveX(b.rowX), SHIBI.ResponsiveY(b.rowY))
    AM._rowEmpty:SetSize(SHIBI.ResponsiveX(b.rowW), SHIBI.ResponsiveY(40))
    AM._rowEmpty:SetMouseInputEnabled(false)
    AM._rowEmpty.Paint = function(self, w, h)
        SHIBI.DrawSimpleText("НЕТ ОТКРЫТЫХ СПОСОБНОСТЕЙ В ЭТОЙ КАТЕГОРИИ", rowSubFont,
            0, h * 0.5, Color(255, 255, 255, 140), 0, 1)
    end
    AM._rowEmpty:SetVisible(false)
end

local function BuildBindCard(f)
    local i = CFG.infoPanel
    Fonts()
    local p = vgui_Create("DPanel", f)
    p._ab = "binds"
    p:SetPos(SHIBI.ResponsiveX(i.x), SHIBI.ResponsiveY(i.y))
    p:SetSize(SHIBI.ResponsiveX(i.w), SHIBI.ResponsiveY(i.h))
    p:SetMouseInputEnabled(false)
    p._name, p._lines = "Выберите способность", {}
    local rad   = SHIBI.ResponsiveY(i.radius)
    local lineH = SHIBI.ResponsiveY(18)

    p.Paint = function(self, w, h)
        local a = self:GetAlpha()
        if a <= 0 then return end
        local f2 = a / 255
        draw_RoundedBox(rad, 0, 0, w, h, Color(i.color.r, i.color.g, i.color.b, i.color.a * f2))

        SHIBI.DrawSimpleText("ОПИСАНИЕ", rowSubFont, 18, 16, Color(215, 68, 49, a), 0, 0)
        SHIBI.DrawSimpleText(self._name or "", rowFont, 18, 32, Color(255, 255, 255, a), 0, 0)
        draw_RoundedBox(0, 18, 62, w - 36, 1, Color(255, 255, 255, 26 * f2))

        local y = 74
        for _, line in ipairs(self._lines or {}) do
            SHIBI.DrawSimpleText(line, bindDescFont, 18, y, Color(255, 255, 255, 200 * f2), 0, 0)
            y = y + lineH
        end
    end

    AM._bindCard = p
    AddOpenAnim(p, 0.05)
end

function AM.ApplyTabLayout()
    local f = AM.Frame
    if not IsValid(f) then return end
    local binds = AM._tab == "binds"
    for _, c in ipairs(f:GetChildren()) do
        if c._ab == "normal" then c:SetVisible(not binds)
        elseif c._ab == "binds" then c:SetVisible(binds) end
    end
end

local function BuildCloseButton(f)
    local c     = CFG.closeBtn
    local iSize = SHIBI.ResponsiveX(c.iconSize)
    local b     = vgui_Create("DButton", f)

    b:SetText("")
    b:SetSize(SHIBI.ResponsiveX(c.size), SHIBI.ResponsiveY(c.size))
    b:SetPos(SHIBI.ResponsiveX(c.x), SHIBI.ResponsiveY(c.y))
    b._hoverK = 0

    b.Paint = function(self, w, h)
        local a = self:GetAlpha()
        if a <= 0 then return end
        local scale  = 1 + self._hoverK * (c.hoverScale - 1)
        local dw, dh = w * scale, h * scale
        local tint   = math.min(255, math.floor(255 * (1 + self._hoverK * c.brightenMax)))

        surface.SetDrawColor(tint, tint, tint, a)
        surface.SetMaterial(Mat(c.buttonMaterial))
        surface.DrawTexturedRect((w - dw) * .5, (h - dh) * .5, dw, dh)

        local ids = iSize * scale
        surface.SetDrawColor(255, 255, 255, a)
        surface.SetMaterial(Mat(c.iconMaterial))
        surface.DrawTexturedRect((w - ids) * .5, (h - ids) * .5, ids, ids)
    end

    b.Think = function(self)
        local t = self:IsHovered() and 1 or 0
        self._hoverK = self._hoverK + (t - self._hoverK) * math_Clamp(1 - math_exp(-c.hoverLerpSpeed * FrameTime()), 0, 1)
    end

    b.DoClick = function()
        if SHIBI.PlaySound then SHIBI.PlaySound("mugen/ui/notifications/undo.mp3") end
        AM.Close()
    end

    b:SetCursor("hand")
    AddOpenAnim(b, 0.05)
end

function AM.Open()
    if IsValid(AM.Frame) then
        AM.Close()
        return
    end

    AM._anims      = nil
    AM._listenSlot = nil
    ResetBindState()
    ResetBindPanels()
    AM._tab = "all"

    local f = vgui_Create("DPanel")
    AM.Frame = f
    f:SetSize(ScrW(), ScrH())
    f:SetPos(0, 0)
    f:MakePopup()
    f:SetKeyboardInputEnabled(false)
    f:SetPaintBackground(false)
    f.Paint = function() end

    local escPrev = false
    f.Think = function()
        local esc = input_IsKeyDown(KEY_ESCAPE)
        if esc and not escPrev then
            if AM._listenSlot then
                AM._listenSlot = nil
                AM.RefreshSlots()
            else
                AM.Close()
            end
        end
        escPrev = esc
        DriveOpenAnims()
    end

    GlassPanel(f, CFG.topbar, 0)
    MatPanel(f, "shibi_core/ability_menu/text_ability",
             CFG.textAbility.x, CFG.textAbility.y, CFG.textAbility.w, CFG.textAbility.h, 0.03)
    GlassPanel(f, CFG.list,  CFG.anim.stagger)
    GlassPanel(f, CFG.slots, CFG.anim.stagger * 2)
    BuildPreview(f)
    BuildDescription(f)
    BuildInfoPanel(f)
    BuildTabs(f)
    BuildSection(f)
    BuildSlots(f)
    BuildActionButtons(f)
    BuildPreviewButton(f)
    BuildBindRows(f)
    BuildBindCard(f)
    BuildCloseButton(f)

    AM.RefreshSection()
    AM.RefreshSlots()
    AM.RefreshInfo()
    AM.ApplyTabLayout()
end

function AM.Close()
    local frame = AM.Frame
    AM.Frame       = nil
    AM._anims      = nil
    AM._listenSlot = nil
    ResetBindState()
    ResetBindPanels()

    if IsValid(frame) then
        frame:SetVisible(false)
        frame:Remove()
    end
end

concommand.Add("shibi_abilities_menu", function() AM.Open() end)

SHIBI.Log("[AbilitiesMenu] Модуль загружен")

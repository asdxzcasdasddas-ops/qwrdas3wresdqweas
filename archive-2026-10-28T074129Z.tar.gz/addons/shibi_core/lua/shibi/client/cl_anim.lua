local Active = {}

local function GetSeqId(ply, seq)
    local id = ply:LookupSequence(seq)
    if id and id >= 0 then return id end
    id = ply:LookupSequence(string.lower(seq))
    if id and id >= 0 then return id end
    return -1
end

local function StartAnim(ply, seq, speed, loop, generation, targetDuration)
    if not IsValid(ply) then return end
    speed = math.Clamp(tonumber(speed) or 1, 0.05, 4)
    targetDuration = tonumber(targetDuration)
    generation = tonumber(generation) or 0
    local previous = Active[ply]
    if previous and generation < previous.generation then return end

    if Active[ply] then
        ply:AnimResetGestureSlot(SHIBI.Anim.Slot)
        Active[ply] = nil
    end

    local seqId = GetSeqId(ply, seq)
    if seqId < 0 then return end

    local baseDur = math.max(tonumber(ply:SequenceDuration(seqId)) or 0.75, 0.01)
    if targetDuration and targetDuration > 0 then
        speed = math.Clamp(speed * baseDur / targetDuration, 0.05, 4)
    end

    local function ApplySequence(cycle)
        ply:AnimResetGestureSlot(SHIBI.Anim.Slot)
        ply:AddVCDSequenceToGestureSlot(SHIBI.Anim.Slot, seqId, cycle or 0, not loop)
        ply:AnimSetGestureWeight(SHIBI.Anim.Slot, SHIBI.Anim.Weight)
        if isfunction(ply.SetLayerPlaybackRate) then
            ply:SetLayerPlaybackRate(SHIBI.Anim.Slot, math.Clamp(speed, 0.05, 4))
        end
    end

    ApplySequence()

    local dur = baseDur / math.max(speed, 0.01)

    Active[ply] = {
        seq     = seq,
        seqId   = seqId,
        speed   = speed,
        loop    = loop,
        dur     = dur,
        endTime = CurTime() + dur,
        generation = generation,
        lastCycle = 0,
    }
end

local function StopAnim(ply)
    if not IsValid(ply) then return end
    ply:AnimResetGestureSlot(SHIBI.Anim.Slot)
    Active[ply] = nil
end

net.Receive("SHIBI::Anim::Play", function()
    local ply   = net.ReadEntity()
    local seq   = net.ReadString()
    local speed = net.ReadFloat()
    local loop  = net.ReadBool()
    local generation = net.ReadUInt(32)
    local targetDuration = net.ReadFloat()
    if IsValid(ply) then
        StartAnim(ply, seq, speed, loop, generation, targetDuration)
    end
end)

net.Receive("SHIBI::Anim::Stop", function()
    local ply = net.ReadEntity()
    local generation = net.ReadUInt(32)
    if IsValid(ply) then
        local current = Active[ply]
        if not current or generation >= current.generation then
            StopAnim(ply)
        end
    end
end)

hook.Add("Think", "SHIBI::Anim::Think", function()
    local now = CurTime()
    for ply, st in pairs(Active) do
        if not IsValid(ply) then
            Active[ply] = nil
            continue
        end

        if now >= st.endTime then
            if st.loop then
                st.lastCycle = st.lastCycle + 1
                ply:AnimResetGestureSlot(SHIBI.Anim.Slot)
                ply:AddVCDSequenceToGestureSlot(SHIBI.Anim.Slot, st.seqId, 0, false)
                ply:AnimSetGestureWeight(SHIBI.Anim.Slot, SHIBI.Anim.Weight)
                if isfunction(ply.SetLayerPlaybackRate) then
                    ply:SetLayerPlaybackRate(SHIBI.Anim.Slot, st.speed)
                end
                st.endTime = now + st.dur
            else
                StopAnim(ply)
            end
        end
    end
end)

hook.Add("ShutDown", "SHIBI::Anim::Shutdown", function()
    table.Empty(Active)
end)

SHIBI.Log("[Anim] cl_anim.lua загружен")

if not CLIENT then return end

SHIBI.Character = SHIBI.Character or {}
SHIBI.Character.Preview = SHIBI.Character.Preview or {}

local function ColorToPlayerVector(value)
    value = value or color_white
    return Vector(
        math.Clamp((value.r or 255) / 255, 0, 1),
        math.Clamp((value.g or 255) / 255, 0, 1),
        math.Clamp((value.b or 255) / 255, 0, 1)
    )
end

local function GetBodygroupByName(ent, name)
    for i = 0, (ent:GetNumBodyGroups() or 0) - 1 do
        if string.lower(ent:GetBodygroupName(i)) == string.lower(name) then
            return i, ent:GetBodygroup(i), ent:GetBodygroupCount(i)
        end
    end
    return nil
end

function SHIBI.Character.Preview.Create(parent, w, h)
    local pnl = vgui.Create("DModelPanel", parent)
    pnl:SetSize(w, h)
    pnl:SetMouseInputEnabled(true)

    pnl.headEnt = nil
    pnl.gender = "male"
    pnl.faction = "shinigami"
    pnl.clothesIndex = 1
    pnl.faceIndex = 1
    pnl.height = 1.8
    pnl.animationIndex = 1
    pnl.animationSequence = nil
    pnl.hairStyle = 0
    pnl.hairColor = Color(255, 255, 255)
    pnl.eyeStyle = 0
    pnl.flexValues = {}

    pnl.rotate = 0
    pnl.dragging = false
    pnl.lastMouseX = 0

    pnl.OnMousePressed = function() end
    pnl.OnMouseReleased = function() end
    pnl.Think = function() end

    pnl.LayoutEntity = function(self, ent)
        if not IsValid(ent) then return end
        ent:SetAngles(Angle(0, 0, 0))
        ent:FrameAdvance(FrameTime())
        if self.animationSequence then
            local animationId = ent:LookupSequence(self.animationSequence)
            if animationId and animationId >= 0 and ent:GetSequence() ~= animationId then
                ent:ResetSequence(animationId)
            end
        end
        local duration = ent:SequenceDuration()
        if duration and duration > 0 then
            ent:SetCycle((CurTime() % duration) / duration)
        end
        ent:SetupBones()
        self:RunAnimation()
    end

    pnl.PostDrawModel = function(self, ent)
        if not IsValid(ent) then return end
        if IsValid(self.headEnt) then
            self.headEnt:SetupBones()
            self.headEnt:DrawModel()
        end
    end

    pnl.OnMousePressed = function() end
    pnl.OnMouseReleased = function() end
    pnl.Think = function() end

    pnl.LayoutEntity = function(self, ent)
        if not IsValid(ent) then return end
        ent:SetAngles(Angle(0, 0, 0))
        ent:FrameAdvance(FrameTime())
        if self.animationSequence then
            local animationId = ent:LookupSequence(self.animationSequence)
            if animationId and animationId >= 0 and ent:GetSequence() ~= animationId then
                ent:ResetSequence(animationId)
            end
        end
        local duration = ent:SequenceDuration()
        if duration and duration > 0 then
            ent:SetCycle((CurTime() % duration) / duration)
        end
        ent:SetupBones()
        self:RunAnimation()
    end

    pnl.PostDrawModel = function(self, ent)
        if not IsValid(ent) then return end
        if IsValid(self.headEnt) then
            self.headEnt:SetupBones()
            self.headEnt:DrawModel()
        end
    end

    function pnl:SetGender(gender)
        local nextGender = string.lower(gender or "male")
        if self.gender == nextGender then return end
        self.gender = nextGender
        self.clothesIndex = 1
        self.faceIndex = 1
        self.hairStyle = 0
        self.eyeStyle = 0
        self.flexValues = {}
        self:Rebuild()
    end

    function pnl:SetFaction(faction)
        faction = faction == "espada" and "espada" or "shinigami"
        if self.faction == faction then return end
        self.faction = faction
        self.clothesIndex = 1
        self:Rebuild()
    end

    function pnl:SetAnimation(index)
        self.animationIndex = math.max(math.floor(tonumber(index) or 1), 1)
        self.animationSequence = nil
        local ent = self:GetEntity()
        local item = (SHIBI.Character.PreviewAnimations or {})[self.animationIndex]
        if IsValid(ent) and item then
            for _, sequence in ipairs(item.sequences or {}) do
                local id = ent:LookupSequence(sequence)
                if id and id >= 0 then
                    self.animationSequence = sequence
                    ent:ResetSequence(id)
                    ent:SetCycle(0)
                    break
                end
            end
        end
        self:Rebuild()
    end

    function pnl:SetIdleSequence(sequence)
        self.animationSequence = isstring(sequence) and sequence or nil
        self:Rebuild()
    end

    function pnl:Configure(data)
        if not istable(data) then return end
        self.gender = data.gender == "female" and "female" or "male"
        self.faction = data.faction == "espada" and "espada" or "shinigami"
        self.clothesIndex = math.max(math.floor(tonumber(data.clothes) or 1), 1)
        self.faceIndex = math.max(math.floor(tonumber(data.face) or 1), 1)
        self.hairStyle = math.max(math.floor(tonumber(data.hair) or 0), 0)
        self.eyeStyle = math.max(math.floor(tonumber(data.eyes) or 0), 0)
        self.height = math.Clamp(tonumber(data.height) or 1.8, 1.5, 2.1)
        local color = data.hairColor
        if istable(color) then
            self.hairColor = Color(tonumber(color[1] or color.r) or 255, tonumber(color[2] or color.g) or 255, tonumber(color[3] or color.b) or 255)
        end
        self.flexValues = istable(data.flexes) and data.flexes or {}
        self.animationSequence = self.faction == "espada" and "lanran1_0_battle_idle_base" or "lanran1_0_battle_idle_base"
        self:Rebuild()
    end

    function pnl:SetClothes(index)
        self.clothesIndex = index or 1
        self:Rebuild()
    end

    function pnl:SetFace(index)
        self.faceIndex = math.max(math.floor(tonumber(index) or 1), 1)
        self:Rebuild()
    end

    function pnl:SetHeight(height)
        self.height = math.Clamp(tonumber(height) or 1.8, 1.5, 2.1)
        local scale = self.height / 1.8
        local ent = self:GetEntity()
        if IsValid(ent) then ent:SetModelScale(scale, 0) end
        self:ApplyAppearance()
    end

    function pnl:SetHair(style, color)
        self.hairStyle = math.max(tonumber(style) or 0, 0)
        if IsColor(color) then self.hairColor = Color(color.r, color.g, color.b, 255) end
        self:ApplyAppearance()
    end

    function pnl:SetPlayerColor(color)
        if IsColor(color) then self.hairColor = Color(color.r, color.g, color.b, 255) end
        self:ApplyAppearance()
    end

    function pnl:SetEye(style)
        self.eyeStyle = style or 0
        self:ApplyAppearance()
    end

    function pnl:SetFlex(name, value)
        self.flexValues[name] = value
        self:ApplyAppearance()
    end

    function pnl:ApplyAppearance()
        local ent = self:GetEntity()
        if not IsValid(ent) then return end
        SHIBI.Character.ApplyHairColor(ent, self.hairColor)

        local bgIdx, _, bgCount = GetBodygroupByName(ent, "Hair")
        if bgIdx then
            ent:SetBodygroup(bgIdx, math.Clamp(self.hairStyle, 0, bgCount - 1))
        end

        if IsValid(self.headEnt) then
            if self.faction == "espada" and self.gender == "male" then
                local torso = GetBodygroupByName(self.headEnt, "Torse")
                if torso then self.headEnt:SetBodygroup(torso, 1) end
            end
            SHIBI.Character.ApplyHairColor(self.headEnt, self.hairColor)
            local headBgIdx, _, headBgCount = GetBodygroupByName(self.headEnt, "Hair")
            if headBgIdx then
                self.headEnt:SetBodygroup(headBgIdx, math.Clamp(self.hairStyle, 0, headBgCount - 1))
            end
            if self.eyeStyle and self.eyeStyle > 0 then
                local headSkinCount = self.headEnt:SkinCount() or 1
                self.headEnt:SetSkin(math.Clamp(self.eyeStyle, 0, headSkinCount - 1))
            end

        end

        for flexName, flexValue in pairs(self.flexValues or {}) do
            local id = ent:GetFlexIDByName(flexName)
            if id then ent:SetFlexWeight(id, flexValue) end
            if self.headEnt and IsValid(self.headEnt) then
                local hid = self.headEnt:GetFlexIDByName(flexName)
                if hid then self.headEnt:SetFlexWeight(hid, flexValue) end
            end
        end
    end

    function pnl:FitCameraToModel()
        local ent = self:GetEntity()
        if not IsValid(ent) then return end

        ent:SetupBones()

        local mins, maxs = ent:GetRenderBounds()
        if not mins or not maxs then
            mins, maxs = ent:OBBMins(), ent:OBBMaxs()
        end

        local size = maxs - mins
        local height = size.z

        local centerZ = mins.z + height * 0.78

        local topFocus = mins.z + height * 0.95
        local bottomFocus = mins.z + height * 0.35
        local visibleHeight = topFocus - bottomFocus
        local fitHeight = visibleHeight * 0.5

        local fov = 35
        self:SetFOV(fov)

        local fovRad = math.rad(fov * 0.5)

        local distance = fitHeight / math.tan(fovRad) * 0.85
        distance = math.max(distance, 30)

        self:SetCamPos(Vector(distance, 0, centerZ))
        self:SetLookAt(Vector(0, 0, centerZ))
    end

    function pnl:Rebuild()
        local parts = SHIBI.Character.GetParts(self.gender)
        if not parts then return end

        local bodyModel = parts.Body
        local genderKey = self.gender == "female" and "Female" or "Male"
        local clothes = SHIBI.Character.Clothes[genderKey]
        local available = {}
        for originalIndex, item in ipairs(clothes or {}) do
            if not item.faction or item.faction == self.faction then
                available[#available + 1] = {index = originalIndex, data = item}
            end
        end
        if available[self.clothesIndex] then
            bodyModel = available[self.clothesIndex].data.model
        end

        self:SetModel(bodyModel)
        local ent = self:GetEntity()
        if IsValid(ent) then
            local seqId = ent:LookupSequence(self.animationSequence or parts.PreviewAnim)
            if seqId and seqId >= 0 then
                ent:ResetSequence(seqId)
                ent:SetCycle(0)
            end
        end

        if IsValid(self.headEnt) then
            self.headEnt:Remove()
            self.headEnt = nil
        end

        local headModel = SHIBI.Character.GetHeadModel(self.gender, self.faceIndex)
        local head = ClientsideModel(headModel or parts.Head, RENDERGROUP_OPAQUE)
        if IsValid(head) then
            head:SetNoDraw(true)
            head:SetMoveType(MOVETYPE_NONE)
            head:SetSolid(SOLID_NONE)
            head:SetPos(ent:GetPos())
            head:SetAngles(ent:GetAngles())

            local headBone = ent:LookupBone("ValveBiped.Bip01_Head1")
            if headBone then
                head:SetParent(ent, headBone)
                head:AddEffects(EF_BONEMERGE)
                head:AddEffects(EF_FOLLOWBONE)
            else
                head:SetParent(ent)
                head:AddEffects(EF_BONEMERGE)
            end

            self.headEnt = head
            head:SetModelScale(self.height / 1.8, 0)
        end

        if IsValid(ent) then
            ent:SetModelScale(self.height / 1.8, 0)
        end

        self:FitCameraToModel()

        self:ApplyAppearance()
    end

    function pnl:Cleanup()
        if IsValid(self.headEnt) then
            self.headEnt:Remove()
            self.headEnt = nil
        end
    end

    pnl.OnRemove = function(self)
        self:Cleanup()
    end

    pnl:Rebuild()
    return pnl
end

function SHIBI.Character.Preview.GetHeadBodygroups(gender)
    local parts = SHIBI.Character.GetParts(gender)
    if not parts then return {} end
    local temp = ClientsideModel(parts.Head, RENDERGROUP_OPAQUE)
    if not IsValid(temp) then return {} end

    local result = {}
    for i = 0, (temp:GetNumBodyGroups() or 0) - 1 do
        result[#result + 1] = {
            index = i,
            name = temp:GetBodygroupName(i),
            count = temp:GetBodygroupCount(i),
        }
    end
    temp:Remove()
    return result
end

function SHIBI.Character.Preview.GetHeadSkins(gender)
    local parts = SHIBI.Character.GetParts(gender)
    if not parts then return 0 end
    local temp = ClientsideModel(parts.Head, RENDERGROUP_OPAQUE)
    if not IsValid(temp) then return 0 end
    local count = temp:SkinCount() or 1
    temp:Remove()
    return count
end

function SHIBI.Character.Preview.GetHeadFlexes(gender)
    local parts = SHIBI.Character.GetParts(gender)
    if not parts then return {} end

    local temp = ClientsideModel(parts.Head, RENDERGROUP_OPAQUE)
    if not IsValid(temp) then return {} end

    temp:SetPos(Vector(0, 0, 0))
    temp:SetAngles(Angle(0, 0, 0))
    temp:SetupBones()

    local result = {}

    if temp.GetFlexes then
        local flexes = temp:GetFlexes()
        if istable(flexes) then
            for i, name in ipairs(flexes) do
                if isstring(name) and name ~= "" then
                    result[#result + 1] = {
                        index = i - 1,
                        name = name,
                        min = 0,
                        max = 1,
                    }
                end
            end
        end
    end

    if #result == 0 and temp.GetFlexCount then
        local count = temp:GetFlexCount() or 0
        for i = 0, count - 1 do
            local name = temp:GetFlexName(i)
            if isstring(name) and name ~= "" then
                result[#result + 1] = {
                    index = i,
                    name = name,
                    min = 0,
                    max = 1,
                }
            end
        end
    end

    temp:Remove()
    return result
end

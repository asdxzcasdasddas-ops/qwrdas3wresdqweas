if SERVER then return end

local materials = {
    background = Material("shibi_core/character_creator/background.png", "smooth"),
    logo = Material("shibi_core/character_creator/logo_onepage.png", "smooth"),
    open = Material("shibi_core/character_creator/open_slot.png", "smooth"),
    locked = Material("shibi_core/character_creator/locked_slot.png", "smooth"),
    divider = Material("shibi_core/character_creator/otdelenie.png", "smooth"),
    returnIcon = Material("shibi_core/character_creator/return.png", "smooth"),
    espada = Material("shibi_core/character_creator/no_selected_fraction_espada.png", "smooth"),
    espadaSelected = Material("shibi_core/character_creator/selection_fraction_espada.png", "smooth"),
    shinigami = Material("shibi_core/character_creator/no_selected_fraction_shinigami.png", "smooth"),
    shinigamiSelected = Material("shibi_core/character_creator/selected_fraction_shinigami.png", "smooth"),
}

local accent = Color(215, 68, 49)
local white = Color(242, 239, 238)
local fontCache = {}
local function drawMaterial(material, x, y, w, h, color)
    if not material then return end
    surface.SetMaterial(material)
    surface.SetDrawColor(color or white)
    surface.DrawTexturedRect(x, y, w, h)
end

local function font(size, weight, italic)
    local name = "ShibiSlot" .. size .. weight .. (italic and "I" or "")
    if fontCache[name] then return name end
    surface.CreateFont(name, {font = "Inter", size = size, weight = weight, italic = italic, extended = true})
    fontCache[name] = true
    return name
end

local function KeyHint(parent, key, text, x, y)
    local panel = vgui.Create("DPanel", parent)
    panel:SetPos(x, y)
    panel:SetSize(240, 30)
    panel.alpha = 0
    panel.scale = 0.85
    panel.Think = function(self)
        self.alpha = Lerp(FrameTime() * 10, self.alpha, self:IsVisible() and 1 or 0)
        self.scale = Lerp(FrameTime() * 12, self.scale, self:IsVisible() and 1 or 0)
    end
    panel.Paint = function(self, w, h)
        local radius = h * self.scale / 2
        local cx = radius
        local cy = h / 2
        draw.RoundedBox(radius, cx - radius, cy - radius, radius * 2, radius * 2, Color(255, 255, 255, 255 * self.alpha))
        draw.SimpleText(key, font(14, 800), cx, cy, Color(25, 25, 25, 255 * self.alpha), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        draw.SimpleText(text, font(14, 500), h + 8, cy, Color(242, 239, 238, 255 * self.alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
    end
    return panel
end

local function EnterMotion(panel, dx, dy, delay, lift)
    local bx, by = panel:GetPos()
    local spawn = CurTime() + delay
    local hover = 0
    panel:SetAlpha(0)
    panel.Think = function(self)
        local p = math.Clamp((CurTime() - spawn) / 0.4, 0, 1)
        local e = 1 - (1 - p) ^ 3
        hover = Lerp(math.min(FrameTime() * 16, 1), hover, (lift and self:IsHovered()) and 1 or 0)
        self:SetPos(bx + dx * (1 - e), by + dy * (1 - e) - hover * (lift or 0))
        self:SetAlpha(math.floor(255 * e))
    end
end

local function OpenFactionPage(slot)
    local frame = vgui.Create("DFrame")
    frame:SetSize(ScrW(), ScrH())
    frame:SetPos(0, 0)
    frame:SetTitle("")
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)
    frame:MakePopup()
    frame:SetAlpha(0)
    frame:AlphaTo(255, .25, 0)
    frame.Paint = function(self, w, h)
        surface.SetMaterial(materials.background)
        surface.SetDrawColor(white)
        surface.DrawTexturedRect(0, 0, w, h)
    end
    local choice = "shinigami"
    local keyReady = false
    local back = vgui.Create("DButton", frame)
    back:SetText("")
    back:SetMaterial(materials.returnIcon)
    back:SetPos(30, 29)
    back:SetSize(60, 60)
    back:SetZPos(100)
    back.DoClick = function()
        frame:Remove()
        timer.Simple(0, function()
            net.Start("SHIBI::Character::RequestSlots")
            net.SendToServer()
        end)
    end
    back.Paint = function(self, w, h)
        local a = self:IsHovered() and 255 or 150
        surface.SetDrawColor(5, 4, 4, 90)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(accent.r, accent.g, accent.b, a)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
        drawMaterial(materials.returnIcon, 17, 17, 26, 26, Color(255, 255, 255, a))
    end
    local espada = vgui.Create("DButton", frame)
    local shinigami = vgui.Create("DButton", frame)
    for _, b in ipairs({espada, shinigami}) do b:SetText(""); b:SetCursor("hand") end
    espada:SetPos(145, (ScrH() - 688) / 2); espada:SetSize(802, 688)
    shinigami:SetPos(145 + 802 + 28, (ScrH() - 688) / 2); shinigami:SetSize(802, 688)
    local refresh = function()
        espada.Paint = function(_, w, h)
            espada.flash = math.max(0, espada.flash - FrameTime() * 4)
            espada.press = math.max(0, espada.press - FrameTime() * 8)
            surface.SetMaterial(choice == "espada" and materials.espadaSelected or materials.espada)
            surface.SetDrawColor(white)
            surface.DrawTexturedRect(espada.press * 2, espada.press * 2, w - espada.press * 4, h - espada.press * 4)
            if espada.flash > 0 then
                surface.SetDrawColor(99, 49, 215, espada.flash * 24)
                surface.DrawOutlinedRect(3, 3, w - 6, h - 6, 1)
            end
        end
        shinigami.Paint = function(_, w, h)
            shinigami.flash = math.max(0, shinigami.flash - FrameTime() * 4)
            shinigami.press = math.max(0, shinigami.press - FrameTime() * 8)
            surface.SetMaterial(choice == "shinigami" and materials.shinigamiSelected or materials.shinigami)
            surface.SetDrawColor(white)
            surface.DrawTexturedRect(shinigami.press * 2, shinigami.press * 2, w - shinigami.press * 4, h - shinigami.press * 4)
            if shinigami.flash > 0 then
                surface.SetDrawColor(215, 68, 49, shinigami.flash * 24)
                surface.DrawOutlinedRect(3, 3, w - 6, h - 6, 1)
            end
        end
    end
    local function animateFaction(button)
        button.flash = 1
        button.press = 1
    end
    espada.flash, espada.press = 0, 0
    shinigami.flash, shinigami.press = 0, 0
    local function factionPaint(button, material)
        button.Paint = function(self, w, h)
            self.flash = math.max(0, self.flash - FrameTime() * 4)
            self.press = math.max(0, self.press - FrameTime() * 8)
            surface.SetMaterial(material)
            surface.SetDrawColor(255, 255, 255, 255)
            surface.DrawTexturedRect(self.press > 0 and self.press * 2 or 0, self.press > 0 and self.press * 2 or 0, w - self.press * 4, h - self.press * 4)
            if self.flash > 0 then
                surface.SetDrawColor(215, 68, 49, self.flash * 24)
                surface.DrawOutlinedRect(3, 3, w - 6, h - 6, 1)
            end
        end
    end
    espada.DoClick = function() choice = "espada"; animateFaction(espada); refresh() end
    shinigami.DoClick = function() choice = "shinigami"; animateFaction(shinigami); refresh() end
    refresh()
    local espadaLabel = vgui.Create("DLabel", frame)
    espadaLabel:SetMouseInputEnabled(false)
    espadaLabel:SetText("ESPADA")
    espadaLabel:SetFont(font(47, 800, true))
    espadaLabel:SetTextColor(Color(99, 49, 215))
    espadaLabel:SetContentAlignment(5)
    espadaLabel:SetPos(-111, ScrH() - 520)
    espadaLabel:SetSize(802, 60)
    local espadaDescription = vgui.Create("DLabel", frame)
    espadaDescription:SetMouseInputEnabled(false)
    espadaDescription:SetText("The fraction espada its a true strength with powers arrancars")
    espadaDescription:SetFont(font(18, 500, true))
    espadaDescription:SetTextColor(Color(99, 49, 215))
    espadaDescription:SetContentAlignment(5)
    espadaDescription:SetPos(26, ScrH() - 455)
    espadaDescription:SetSize(802, 32)
    local shinigamiLabel = vgui.Create("DLabel", frame)
    shinigamiLabel:SetMouseInputEnabled(false)
    shinigamiLabel:SetText("SHINIGAMI")
    shinigamiLabel:SetFont(font(47, 800, true))
    shinigamiLabel:SetTextColor(accent)
    shinigamiLabel:SetContentAlignment(5)
    shinigamiLabel:SetPos(745, ScrH() - 520)
    shinigamiLabel:SetSize(802, 60)
    local shinigamiDescription = vgui.Create("DLabel", frame)
    shinigamiDescription:SetMouseInputEnabled(false)
    shinigamiDescription:SetText("The fraction shinigami its a true strength with another powers")
    shinigamiDescription:SetFont(font(18, 500, true))
    shinigamiDescription:SetTextColor(accent)
    shinigamiDescription:SetContentAlignment(5)
    shinigamiDescription:SetPos(860, ScrH() - 455)
    shinigamiDescription:SetSize(802, 32)
    KeyHint(frame, "E", "Select", ScrW() / 2 - 65, ScrH() - 100)

    EnterMotion(espada, -220, 0, 0, 12)
    EnterMotion(shinigami, 220, 0, 0.08, 12)
    EnterMotion(espadaLabel, 0, 30, 0.25)
    EnterMotion(espadaDescription, 0, 20, 0.32)
    EnterMotion(shinigamiLabel, 0, 30, 0.33)
    EnterMotion(shinigamiDescription, 0, 20, 0.4)

    local wasE = false
    frame.Think = function(self)
        local pressed = input.IsKeyDown(KEY_E)
        if not pressed then keyReady = true end
        if keyReady and pressed and not wasE then
            SHIBI.Character.CreatorFaction = choice
            SHIBI.Character.PendingSlot = slot
            if SHIBI.Character.OpenCreator then
                SHIBI.Character.OpenCreator()
                self:Remove()
            end
        end
        wasE = pressed
    end
    return frame
end

SHIBI.Character.OpenFactionPage = OpenFactionPage

local SELECT_COLOR = Color(0xD7, 0x44, 0x31)
local RING = { w = 425, h = 721, r = 14, t = 2, seg = 8 }

local function RoundedRectPoints(x, y, w, h, r, seg)
    local pts = {}
    local corners = {
        { x + w - r, y + r,     270 },
        { x + w - r, y + h - r,   0 },
        { x + r,     y + h - r,  90 },
        { x + r,     y + r,     180 },
    }
    for _, c in ipairs(corners) do
        for i = 0, seg do
            local a = math.rad(c[3] + 90 * i / seg)
            pts[#pts + 1] = { x = c[1] + math.cos(a) * r, y = c[2] + math.sin(a) * r }
        end
    end
    return pts
end

local function DrawRoundedRing(x, y, w, h, r, t, col)
    local outer = RoundedRectPoints(x, y, w, h, r, RING.seg)
    local inner = RoundedRectPoints(x + t, y + t, w - 2 * t, h - 2 * t, r - t, RING.seg)
    local n = #outer

    draw.NoTexture()
    surface.SetDrawColor(col.r, col.g, col.b, col.a)
    for i = 1, n do
        local j = i % n + 1
        surface.DrawPoly({ outer[i], outer[j], inner[j] })
        surface.DrawPoly({ outer[i], inner[j], inner[i] })
    end
end

local function OpenSlots(slots)
    if IsValid(SHIBI.Character.SlotFrame) then SHIBI.Character.SlotFrame:Remove() end
    local frame = vgui.Create("DFrame")
    SHIBI.Character.SlotFrame = frame
    frame:SetSize(ScrW(), ScrH()); frame:SetPos(0, 0); frame:SetTitle(""); frame:ShowCloseButton(false); frame:SetDraggable(false); frame:MakePopup()
    frame:SetAlpha(0)
    frame:AlphaTo(255, 0.25, 0)
    local selected = 1
    local cards = {}
    local ring = { a = 0, x = 0, y = 0 }

    frame.Paint = function(self, w, h)
        surface.SetMaterial(materials.background); surface.SetDrawColor(white); surface.DrawTexturedRect(0, 0, w, h)
        surface.SetMaterial(materials.logo); surface.DrawTexturedRect(63, 39, 1794, 66)

        local target = cards[selected]
        if IsValid(target) then
            local tx, ty = target:GetPos()
            if ring.a == 0 then ring.x, ring.y = tx, ty end

            local k = FrameTime() * 26
            ring.a = Lerp(FrameTime() * 14, ring.a, 1)
            ring.x = Lerp(k, ring.x, tx)
            ring.y = Lerp(k, ring.y, ty)

            DrawRoundedRing(ring.x - 6, ring.y - 6, RING.w, RING.h, RING.r, RING.t,
                Color(SELECT_COLOR.r, SELECT_COLOR.g, SELECT_COLOR.b, 255 * ring.a))
        end
    end
    local previews = {}
    local UpdateHints
    for i = 1, 3 do
        local card = vgui.Create("DButton", frame)
        cards[i] = card
        card:SetText(""); card:SetCursor("hand"); card:SetSize(412, 709)
        card:SetPos((ScrW() - (412 * 3 + 35 * 2)) / 2 + (i - 1) * 447, (ScrH() - 709) / 2 + 30)
        card.baseX, card.baseY = card:GetPos()
        card.spawn = CurTime() + (i - 1) * 0.06
        card.lift = 0
        card.kick = 0
        card.Think = function(self)
            local dt = FrameTime()
            local p = math.Clamp((CurTime() - self.spawn) / 0.35, 0, 1)
            local ease = 1 - (1 - p) ^ 3
            self.lift = Lerp(math.min(dt * 20, 1), self.lift, self:IsHovered() and 1 or 0)
            self.kick = math.max(0, self.kick - dt * 8)
            self:SetPos(self.baseX, self.baseY + (1 - ease) * 80 - self.lift * 8 - self.kick * 10)
            self:SetAlpha(math.floor(255 * ease))
        end
        card.hoverAmount = 0
        card.press = 0
        card.Paint = function(self, w, h)
            local info = slots[i] or {}
            self.hoverAmount = Lerp(FrameTime() * 12, self.hoverAmount, self:IsHovered() and 1 or 0)
            self.press = math.max(0, self.press - FrameTime() * 8)
            draw.RoundedBox(7, 0, 0, w, h, Color(25, 25, 25))
            if not info.data then
                surface.SetMaterial(info.locked and materials.locked or materials.open)
                surface.SetDrawColor(white); surface.DrawTexturedRect(95, 163, info.locked and 231 or 227, info.locked and 272 or 267)
            end
        end

        card.PaintOver = function(self, w, h)
            local info = slots[i] or {}
            if selected ~= i and self.hoverAmount > 0 then
                surface.SetDrawColor(accent.r, accent.g, accent.b, 90 * self.hoverAmount)
                surface.DrawOutlinedRect(-3, -3, 418, 715, 1)
            end
            if self.press > 0 then
                surface.SetDrawColor(accent.r, accent.g, accent.b, self.press * 24)
                surface.DrawOutlinedRect(2, 2, w - 4, h - 4, 1)
            end
            local title = info.locked and "LOCKED SLOT" or (info.data and (info.data.firstName .. " " .. info.data.lastName) or "NEW CHARACTER")
            local sub = info.locked and "Buy a pass for slot" or (info.data and info.data.faction or "Create new character")
            draw.SimpleText(title, font(22, 500), w / 2, h - 152, accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
            surface.SetMaterial(materials.divider); surface.SetDrawColor(white); surface.DrawTexturedRect((w - 217) / 2, h - 133, 217, 10)
            draw.SimpleText(sub, font(14, 500), w / 2, h - 108, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
        end
        card.DoClick = function()
            selected = i
            card.press = 1
            card.kick = 1
            UpdateHints()
        end
        local info = slots[i] or {}
        if info.data and SHIBI.Character.Preview and SHIBI.Character.Preview.Create then
            local preview = SHIBI.Character.Preview.Create(card, 380, 500)
            previews[i] = preview
            preview:SetPos(15, 75)
            preview:SetZPos(0)
            preview:SetMouseInputEnabled(false)
            preview:Configure(info.data)
        end
    end
    local selectHint = KeyHint(frame, "E", "Select", 0, 0)
    local deleteHint = KeyHint(frame, "R", "Delete Character", 0, 0)
    UpdateHints = function()
        local card = cards[selected]
        if not IsValid(card) then return end
        local x, y = card.baseX, card.baseY
        local hintY = y + card:GetTall() + 14
        selectHint:SetPos(x + card:GetWide() / 2 - 48, hintY)
        deleteHint:SetPos(x + card:GetWide() / 2 - 48, hintY + 36)
        deleteHint:SetVisible((slots[selected] or {}).data ~= nil)
    end
    UpdateHints()
    local wasE, wasR = false, false
    local keyReady = false
    frame.Think = function(self)
        local pressedE = input.IsKeyDown(KEY_E)
        local pressedR = input.IsKeyDown(KEY_R)
        if not pressedE and not pressedR then keyReady = true end
        if keyReady and pressedE and not wasE then
            local info = slots[selected] or {}
            if not info.locked then
                if info.data then
                    net.Start("SHIBI::Character::SelectSlot")
                        net.WriteUInt(selected, 2)
                    net.SendToServer()
                    self:Remove()
                else
                    OpenFactionPage(selected)
                    self:Remove()
                end
            end
            keyReady = false
        end
        if keyReady and pressedR and not wasR and slots[selected] and slots[selected].data then
            net.Start("SHIBI::Character::DeleteSlot"); net.WriteUInt(selected, 2); net.SendToServer()
            slots[selected].data = nil
            UpdateHints()
            keyReady = false
        end
        wasE, wasR = pressedE, pressedR
    end
    frame.PerformLayout = function()
        UpdateHints()
    end
end

net.Receive("SHIBI::Character::Slots", function()
    local count = net.ReadUInt(2)
    local slots = {}
    for i = 1, count do
        local locked = net.ReadBool()
        local exists = net.ReadBool()
        slots[i] = {locked = locked}
        if exists then
            slots[i].data = util.JSONToTable(net.ReadString()) or {}
        end
    end
    OpenSlots(slots)
end)

net.Receive("SHIBI::Character::OpenCreator", function()
    local slot = net.ReadUInt(2)
    SHIBI.Character.PendingSlot = slot
    OpenFactionPage(slot)
end)

hook.Add("InitPostEntity", "SHIBI::Character::RequestSlots", function()
    timer.Simple(1, function()
        if not IsValid(LocalPlayer()) then return end
        net.Start("SHIBI::Character::RequestSlots")
        net.SendToServer()
    end)
end)

local fadeAlpha = 0
net.Receive("SHIBI::Character::FadeIn", function()
    fadeAlpha = 255
end)

net.Receive("SHIBI::Character::Activated", function()
    fadeAlpha = 255
    if IsValid(SHIBI.Character.SlotFrame) then
        SHIBI.Character.SlotFrame:Remove()
    end
    if IsValid(ShibiCharacterCreator) then
        ShibiCharacterCreator:Remove()
    end
end)

hook.Add("HUDPaint", "SHIBI::Character::FadeIn", function()
    if fadeAlpha <= 0 then return end
    surface.SetDrawColor(8, 7, 10, math.floor(fadeAlpha))
    surface.DrawRect(0, 0, ScrW(), ScrH())
    fadeAlpha = math.max(0, fadeAlpha - FrameTime() * 420)
end)

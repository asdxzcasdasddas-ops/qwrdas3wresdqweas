if SERVER then return end

local accent = Color(215, 68, 49)
local panelBlack = Color(5, 4, 4, 66)
local inputBlack = Color(25, 25, 25, 189)
local white = Color(242, 239, 238)
local fontCache = {}
local materials = {
    background = Material("shibi_core/character_creator/Background_rectangle.png", "smooth"),
    logo = Material("shibi_core/character_creator/logo_characters.png", "smooth"),
    logoTwo = Material("shibi_core/character_creator/logo_characters_two.png", "smooth"),
    returnIcon = Material("shibi_core/character_creator/return.png", "smooth"),
    settings = Material("shibi_core/character_creator/settings.png", "smooth"),
    selected = Material("shibi_core/character_creator/selected.png", "smooth"),
    selectedSquare = Material("shibi_core/character_creator/selected_kvadrat.png", "smooth"),
    male = Material("shibi_core/character_creator/male_icon.png", "smooth"),
    female = Material("shibi_core/character_creator/female_icon.png", "smooth"),
    slider = Material("shibi_core/character_creator/background_polzunok.png", "smooth"),
    sliderKnob = Material("shibi_core/character_creator/eclipse_polzunok.png", "smooth"),
    continueButton = Material("shibi_core/character_creator/continue_button.png", "smooth"),
    continueIcon = Material("shibi_core/character_creator/continue.png", "smooth")
}

local function fontName(size)
    return "ShibiCharacter" .. size
end

local function AnimateIn(panel, fromX, duration)
    if not IsValid(panel) then return end
    local x, y = panel:GetPos()
    panel:SetPos(x + fromX, y)
    panel:SetAlpha(0)
    panel:AlphaTo(255, duration or 0.24, 0)
    local targetX = x
    panel.Think = function(self)
        if not IsValid(self) then return end
        local currentX = self:GetX()
        if math.abs(currentX - targetX) > 0.5 then
            self:SetX(Lerp(FrameTime() * 12, currentX, targetX))
        else
            self:SetX(targetX)
        end
    end
end

local function createFonts(scale)
    local sizes = {12, 15, 24, 27}
    for _, size in ipairs(sizes) do
        surface.CreateFont(fontName(size), {
            font = "Inter",
            size = math.max(8, math.floor(size * scale + 0.5)),
            weight = 700,
            italic = true,
            antialias = true,
            extended = true
        })
    end
end

local function drawMaterial(material, x, y, w, h, color)
    surface.SetMaterial(material)
    surface.SetDrawColor(color or white)
    surface.DrawTexturedRect(x, y, w, h)
end

local function makeIconButton(parent, icon, onClick)
    local button = vgui.Create("DButton", parent)
    button:SetText("")
    button.hoverAmount = 0
    button.pressAmount = 0
    button.selected = false
    local click = onClick or function() end
    button.DoClick = function(self)
        self.pressAmount = 1
        click(self)
    end
    button.Paint = function(self, w, h)
        local target = (self:IsHovered() or self.selected) and 1 or 0
        self.hoverAmount = Lerp(math.min(FrameTime() * 12, 1), self.hoverAmount, target)
        self.pressAmount = math.max(0, self.pressAmount - FrameTime() * 7)
        local alpha = math.floor(Lerp(self.hoverAmount, 128, 255))
        surface.SetDrawColor(panelBlack)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(accent.r, accent.g, accent.b, alpha)
        surface.DrawOutlinedRect(0, 0, w, h, math.max(1, math.floor(parent:S(1))))
        local iconSize = parent:S(26)
        drawMaterial(icon, (w - iconSize) * 0.5, (h - iconSize) * 0.5, iconSize, iconSize, Color(255, 255, 255, alpha))
        if self.pressAmount > 0 then
            surface.SetDrawColor(accent.r, accent.g, accent.b, self.pressAmount * 80)
            surface.DrawOutlinedRect(2, 2, w - 4, h - 4, math.max(1, parent:S(2)))
        end
    end
    return button
end

local function makeLabel(parent, text)
    local label = vgui.Create("DLabel", parent)
    label:SetText(text)
    label:SetFont(fontName(12))
    label:SetTextColor(white)
    label:SetContentAlignment(4)
    return label
end

local function makeInput(parent, placeholder)
    local input = vgui.Create("DTextEntry", parent)
    input:SetFont(fontName(15))
    input:SetTextColor(accent)
    input:SetCursorColor(accent)
    input:SetHighlightColor(Color(215, 68, 49, 90))
    input:SetPlaceholderText(placeholder)
    input:SetPlaceholderColor(Color(215, 68, 49, 128))
    input:SetContentAlignment(5)
    input:SetPaintBackground(false)
    input._sanitizing = false
    input.OnKeyCodeTyped = function(self, key)
        if key >= KEY_0 and key <= KEY_9 then
            return true
        end
    end
    input.OnTextChanged = function(self)
        if self._sanitizing then return end
        local source = self:GetText()

        local sanitized = source:gsub("[%d_]", "")
        if sanitized ~= source then
            self._sanitizing = true
            local caret = self:GetCaretPos()
            local removedBeforeCaret = source:sub(1, caret):gsub("[%d_]", "")
            self:SetText(sanitized)
            self:SetCaretPos(#removedBeforeCaret)
            self._sanitizing = false
        end
    end
    input.Paint = function(self, w, h)
        surface.SetDrawColor(inputBlack)
        surface.DrawRect(0, 0, w, h)
        self:DrawTextEntryText(self:GetTextColor(), self:GetHighlightColor(), self:GetCursorColor())
    end
    return input
end

local function scaleFromParent(panel, value)
    local current = panel
    while IsValid(current) do
        if current.S and current.scale then
            return current:S(value)
        end
        current = current:GetParent()
    end
    return value
end

local function makeSecondTile(parent, title, onClick)
    local tile = vgui.Create("DButton", parent)
    tile:SetText("")
    tile:SetCursor("hand")
    tile.title = title
    tile.selected = false
    tile.clickPulse = 0
    tile.hoverGlow = 0
    tile.DoClick = onClick or function() end
    tile.Paint = function(self, w, h)
        local hovered = self:IsHovered()
        self.clickPulse = math.max(0, self.clickPulse - FrameTime() * 4)
        self.hoverGlow = Lerp(FrameTime() * 14, self.hoverGlow, hovered and 1 or 0)
        surface.SetDrawColor(25, 25, 25, 179)
        surface.DrawRect(0, 0, w, h)
        if self.selected or hovered then
            surface.SetDrawColor(accent.r, accent.g, accent.b, self.selected and 255 or 160)
            surface.DrawOutlinedRect(0, 0, w, h, math.max(1, scaleFromParent(parent, self.selected and 3 or 1)))
        end
        if self.selected then
            drawMaterial(materials.selectedSquare, 0, 0, w, h, white)
        end
        if self.clickPulse > 0 then
            surface.SetDrawColor(accent.r, accent.g, accent.b, self.clickPulse * 90)
            surface.DrawRect(0, 0, w, h)
        end
        if self.hoverGlow > 0 then
            surface.SetDrawColor(accent.r, accent.g, accent.b, self.hoverGlow * 28)
            surface.DrawRect(0, 0, w, h)
        end
        draw.SimpleText(self.title, fontName(12), scaleFromParent(parent, 10), h - scaleFromParent(parent, 10), white, TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)
    end
    return tile
end

local function makeSecondSlider(parent, y, title)
    local row = vgui.Create("DPanel", parent)
    row:SetMouseInputEnabled(true)
    row.value = 0.5
    row.dragging = false
    row:SetCursor("hand")
    row.OnMousePressed = function(self, code)
        if code ~= MOUSE_LEFT then return end
        self.dragging = true
        self:MouseCapture(true)
        self:UpdateValueFromMouse()
    end
    row.OnMouseReleased = function(self, code)
        if code ~= MOUSE_LEFT then return end
        self.dragging = false
        self:MouseCapture(false)
    end
    row.UpdateValueFromMouse = function(self)
        local x = self:ScreenToLocal(gui.MouseX(), gui.MouseY())
        self.value = math.Clamp(x / self:GetWide(), 0, 1)
        if self.OnValueChanged then
            self:OnValueChanged(self.value)
        end
    end
    row.Think = function(self)
        if self.dragging then self:UpdateValueFromMouse() end
    end
    row.Paint = function(self, w, h)
        draw.SimpleText(title, fontName(12), 0, 0, white, TEXT_ALIGN_LEFT, TEXT_ALIGN_TOP)
        local barY = scaleFromParent(parent, 30)
        local barH = scaleFromParent(parent, 7)
        local knobW = scaleFromParent(parent, 22)
        local knobH = scaleFromParent(parent, 26)
        drawMaterial(materials.slider, 0, barY, w, barH, white)
        local knobX = math.Clamp(self.value * w - knobW * 0.5, 0, w - knobW)
        drawMaterial(materials.sliderKnob, knobX, barY + (barH - knobH) * 0.5, knobW, knobH, white)
    end
    row.designY = y
    return row
end

local function openCharacterCreator()
    if IsValid(ShibiCharacterCreator) then
        ShibiCharacterCreator:Remove()
    end

    local frame = vgui.Create("DFrame")
    ShibiCharacterCreator = frame
    frame:SetSize(ScrW(), ScrH())
    frame:SetPos(-2, 0)
    frame:SetTitle("")
    frame:SetDraggable(false)
    frame:ShowCloseButton(false)
    frame:MakePopup()
    frame:SetAlpha(0)
    frame:AlphaTo(255, 0.28, 0)
    frame:SetKeyboardInputEnabled(true)
    frame:SetMouseInputEnabled(true)
    frame.designW = 1046
    frame.designH = 1083
    frame.scale = math.min(ScrW() / frame.designW, ScrH() / frame.designH)
    frame.S = function(self, value)
        return math.floor(value * self.scale + 0.5)
    end
    createFonts(frame.scale)

    frame.Paint = function(self)
        surface.SetMaterial(materials.background)
        surface.SetDrawColor(white)
        surface.DrawTexturedRectUV(0, 0, self:S(642), self:S(1083), 0, 4 / 1083, 1, 1)
    end

    local logo, male, female, nameLabel, nameInput, surnameLabel, surnameInput
    local heightLabel, heightValue, slider, continueButton
    local back = makeIconButton(frame, materials.returnIcon, function()
        if frame.page == 2 then
            frame.page = 1
            logo:SetAlpha(0)
            male:SetAlpha(0)
            female:SetAlpha(0)
            nameLabel:SetAlpha(0)
            nameInput:SetAlpha(0)
            surnameLabel:SetAlpha(0)
            surnameInput:SetAlpha(0)
            heightLabel:SetAlpha(0)
            heightValue:SetAlpha(0)
            slider:SetAlpha(0)
            continueButton:SetAlpha(0)
            frame:InvalidateLayout(true)
            timer.Simple(0, function()
                if not IsValid(frame) then return end
                AnimateIn(logo, -24, 0.22)
                AnimateIn(nameLabel, -18, 0.18)
                AnimateIn(nameInput, -18, 0.18)
                AnimateIn(surnameLabel, -18, 0.18)
                AnimateIn(surnameInput, -18, 0.18)
                AnimateIn(heightLabel, -18, 0.18)
                AnimateIn(heightValue, -18, 0.18)
                AnimateIn(slider, -18, 0.18)
                AnimateIn(continueButton, -18, 0.2)
                timer.Simple(0.04, function()
                    if IsValid(male) then male:AlphaTo(255, 0.16, 0) end
                    if IsValid(female) then female:AlphaTo(255, 0.16, 0) end
                end)
            end)
        elseif SHIBI.Character.OpenFactionPage and SHIBI.Character.PendingSlot then
            frame:Close()
            timer.Simple(0, function()
                if SHIBI.Character.OpenFactionPage then
                    SHIBI.Character.OpenFactionPage(SHIBI.Character.PendingSlot)
                end
            end)
        else
            frame:Close()
        end
    end)

    logo = vgui.Create("DPanel", frame)
    logo:SetMouseInputEnabled(false)
    logo.Paint = function(self, w, h)
        drawMaterial(materials.logo, 0, 0, w, h, white)
    end

    male = makeIconButton(frame, materials.male)
    female = makeIconButton(frame, materials.female)
    male.selected = true
    frame.gender = "male"
    frame.faction = SHIBI.Character.CreatorFaction or "shinigami"

    nameLabel = makeLabel(frame, "Введите имя")
    nameInput = makeInput(frame, "Введите свое имя")
    surnameLabel = makeLabel(frame, "Введите фамилию")
    surnameInput = makeInput(frame, "Введите свою фамилию")
    heightLabel = makeLabel(frame, "Выберите ваш рост")
    heightValue = makeLabel(frame, "1,80m")
    heightValue:SetTextColor(accent)
    heightValue:SetContentAlignment(6)
    local previewPanel

    slider = vgui.Create("DPanel", frame)
    slider.value = 0.5
    slider.dragging = false
    slider:SetCursor("hand")
    slider.UpdateValue = function(self)
        local localX = self:ScreenToLocal(gui.MouseX(), gui.MouseY())
        self.value = math.Clamp(localX / self:GetWide(), 0, 1)
        local height = 1.5 + self.value * 0.6
        heightValue:SetText(string.Replace(string.format("%.2fm", height), ".", ","))
        if IsValid(previewPanel) then previewPanel:SetHeight(height) end
    end
    slider.OnMousePressed = function(self, code)
        if code ~= MOUSE_LEFT then return end
        self.dragging = true
        self:MouseCapture(true)
        self:UpdateValue()
    end
    slider.OnMouseReleased = function(self, code)
        if code ~= MOUSE_LEFT then return end
        self.dragging = false
        self:MouseCapture(false)
    end
    slider.Think = function(self)
        if self.dragging then self:UpdateValue() end
    end
    slider.Paint = function(self, w, h)
        local barH = frame:S(7)
        local barY = math.floor((h - barH) * 0.5)
        drawMaterial(materials.slider, 0, barY, w, barH, white)
        local knobW, knobH = frame:S(22), frame:S(26)
        local knobX = math.Clamp(self.value * w - knobW * 0.5, 0, w - knobW)
        drawMaterial(materials.sliderKnob, knobX, (h - knobH) * 0.5, knobW, knobH, white)
    end

    continueButton = vgui.Create("DButton", frame)
    continueButton:SetText("")
    continueButton.hoverAmount = 0
    continueButton.pressAmount = 0
    continueButton.Paint = function(self, w, h)
        self.hoverAmount = Lerp(math.min(FrameTime() * 12, 1), self.hoverAmount, self:IsHovered() and 1 or 0)
        self.pressAmount = math.max(0, self.pressAmount - FrameTime() * 8)
        drawMaterial(materials.continueButton, 0, 0, w, h, white)
        local alpha = math.floor(Lerp(self.hoverAmount, 150, 255))
        draw.SimpleText("ПРОДОЛЖИТЬ", fontName(27), frame:S(28), h * 0.5, Color(accent.r, accent.g, accent.b, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        local iconW, iconH = frame:S(32), frame:S(31)
        drawMaterial(materials.continueIcon, frame:S(494), (h - iconH) * 0.5, iconW, iconH, Color(255, 255, 255, alpha))
        if self.pressAmount > 0 then
            surface.SetDrawColor(accent.r, accent.g, accent.b, self.pressAmount * 24)
            surface.DrawOutlinedRect(2, 2, w - 4, h - 4, 1)
        end
    end
                                                                              
    local categoryPanel
    local selectionPanel
    local logoTwo
    continueButton.DoClick = function()
        continueButton.pressAmount = 1
        frame.page = 2
        categoryPanel:SetAlpha(0)
        selectionPanel:SetAlpha(0)
        logoTwo:SetAlpha(0)
        frame:InvalidateLayout(true)
        timer.Simple(0, function()
            if not IsValid(frame) then return end
            AnimateIn(categoryPanel, -28, 0.24)
            AnimateIn(selectionPanel, 36, 0.3)
            AnimateIn(logoTwo, 0, 0.2)
        end)
    end

    local createCharacterButton = vgui.Create("DButton", frame)
    createCharacterButton:SetText("")
    createCharacterButton.hoverAmount = 0
    createCharacterButton.pressAmount = 0
    createCharacterButton.Paint = function(self, w, h)
        self.hoverAmount = Lerp(math.min(FrameTime() * 12, 1), self.hoverAmount, self:IsHovered() and 1 or 0)
        self.pressAmount = math.max(0, self.pressAmount - FrameTime() * 8)
        drawMaterial(materials.continueButton, 0, 0, w, h, white)
        local alpha = math.floor(Lerp(self.hoverAmount, 150, 255))
        draw.SimpleText("СОЗДАТЬ ПЕРСОНАЖА", fontName(27), frame:S(28), h * 0.5, Color(accent.r, accent.g, accent.b, alpha), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        if self.pressAmount > 0 then
            surface.SetDrawColor(accent.r, accent.g, accent.b, self.pressAmount * 24)
            surface.DrawOutlinedRect(2, 2, w - 4, h - 4, 1)
        end
    end

    logoTwo = vgui.Create("DPanel", frame)
    logoTwo:SetMouseInputEnabled(false)
    logoTwo.Paint = function(self, w, h)
        drawMaterial(materials.logoTwo, 0, 0, w, h, white)
    end

    local categoryNames = {"Прическа", "Глаза", "Лицо", "Одежда"}
    local categories = {}
    categoryPanel = vgui.Create("DPanel", frame)
    categoryPanel.Paint = nil
    selectionPanel = vgui.Create("DPanel", frame)
    selectionPanel.Paint = function(self, w, h)
        surface.SetDrawColor(25, 25, 25, 173)
        surface.DrawRect(0, 0, w, h)
        local pulse = math.sin(CurTime() * 2.2) * 0.5 + 0.5
        surface.SetDrawColor(accent.r, accent.g, accent.b, 5 + pulse * 8)
        surface.DrawOutlinedRect(0, 0, w, h, 1)
    end
    local categoryTitle = vgui.Create("DLabel", selectionPanel)
    categoryTitle:SetFont(fontName(24))
    categoryTitle:SetTextColor(white)
    categoryTitle:SetText("Выберите прическу")
    categoryTitle:SetContentAlignment(4)
    local settings = vgui.Create("DButton", selectionPanel)
    settings:SetText("")
    settings:SetCursor("hand")
    settings.Paint = function(self, w, h)
        local a = self:IsHovered() and 255 or 145
        surface.SetDrawColor(5, 4, 4, 66)
        surface.DrawRect(0, 0, w, h)
        surface.SetDrawColor(accent.r, accent.g, accent.b, a)
        surface.DrawOutlinedRect(0, 0, w, h, math.max(1, frame:S(1)))
        drawMaterial(materials.settings, (w - frame:S(26)) * 0.5, (h - frame:S(26)) * 0.5, frame:S(26), frame:S(26), Color(255, 255, 255, a))
    end

    local tileScroll = vgui.Create("DScrollPanel", selectionPanel)
    tileScroll.Paint = nil
    tileScroll.VBar:SetWide(frame:S(5))
    tileScroll.VBar.Paint = function(self, w, h)
        surface.SetDrawColor(25, 25, 25, 120)
        surface.DrawRect(0, 0, w, h)
    end
    tileScroll.VBar.btnGrip.Paint = function(self, w, h)
        surface.SetDrawColor(accent.r, accent.g, accent.b, 210)
        draw.RoundedBox(frame:S(3), 0, 0, w, h, Color(accent.r, accent.g, accent.b, 210))
    end
    tileScroll.VBar.btnUp.Paint = nil
    tileScroll.VBar.btnDown.Paint = nil
    local tileContainer = vgui.Create("DPanel", tileScroll:GetCanvas())
    tileContainer.Paint = nil
    local tiles = {}
    local faceSliders = {}

    previewPanel = SHIBI.Character.Preview.Create(frame, frame:S(404), frame:S(600))
    previewPanel:SetPos(frame:S(560), frame:S(100))
    previewPanel:SetZPos(-100)
    previewPanel:SetFaction(frame.faction)
    previewPanel:SetGender("male")

    local function RebuildTiles()
        for _, t in ipairs(tiles) do
            if IsValid(t) then t:Remove() end
        end
        tiles = {}
        tileContainer:Clear()

        local category = frame.category or 1
        local gender = frame.gender or "male"
        local genderKey = (gender == "female") and "Female" or "Male"

        local list = {}
        if category == 1 then
            list = SHIBI.Character.HairNames[genderKey] or {}
        elseif category == 2 then
            list = SHIBI.Character.EyeNames[genderKey] or {}
        elseif category == 3 then
            list = SHIBI.Character.HeadNames[genderKey] or {}
        elseif category == 4 then
            local clothes = SHIBI.Character.Clothes[genderKey] or {}
            for _, c in ipairs(clothes) do
                if not c.faction or c.faction == frame.faction then
                    list[#list + 1] = c.name
                end
            end
        end

        for i = 1, #list do
            local name = list[i]
            if name ~= "" then
                local tile = makeSecondTile(tileContainer, name)
                tile.index = i
                tile:SetAlpha(0)
                tile:AlphaTo(255, 0.18, (i - 1) * 0.025)
                local selectedIndex = i
                if category == 1 then
                    selectedIndex = (previewPanel.hairStyle or 0) + 1
                elseif category == 2 then
                    selectedIndex = (previewPanel.eyeStyle or 0) + 1
                elseif category == 3 then
                    selectedIndex = previewPanel.faceIndex or 1
                elseif category == 4 then
                    selectedIndex = previewPanel.clothesIndex or 1
                end
                tile.selected = i == selectedIndex
                tile.DoClick = function(self)
                    for _, other in ipairs(tiles) do other.selected = false end
                    self.selected = true

                    if category == 1 then
                        previewPanel:SetHair(i - 1)
                    elseif category == 2 then
                        previewPanel:SetEye(i - 1)
                    elseif category == 3 then
                        previewPanel:SetFace(i)
                    elseif category == 4 then
                        previewPanel:SetClothes(i)
                    end
                    self.clickPulse = 1
                end
                tiles[#tiles + 1] = tile
            end
        end

        local rows = math.max(1, math.ceil(#tiles / 2))
        tileContainer:SetSize(frame:S(342), rows * frame:S(179))

        for i, tile in ipairs(tiles) do
            local col = (i - 1) % 2
            local row = math.floor((i - 1) / 2)
            tile:SetPos(frame:S(col * 177), frame:S(row * 179))
            tile:SetSize(frame:S(154), frame:S(154))
        end
    end

    local function RebuildFaceSliders()
        for _, s in ipairs(faceSliders) do
            if IsValid(s) then s:Remove() end
        end
        faceSliders = {}

        local gender = frame.gender or "male"
        local flexes = SHIBI.Character.Preview.GetHeadFlexes(gender)

        for i, flex in ipairs(flexes) do
            local sliderPanel = makeSecondSlider(selectionPanel, i, flex.name)
            sliderPanel.flexName = flex.name
            sliderPanel.value = 0.5
            sliderPanel.OnValueChanged = function(self, val)
                previewPanel:SetFlex(flex.name, val)
            end
            faceSliders[#faceSliders + 1] = sliderPanel
        end
    end

    local function UpdateGender()
        previewPanel:SetFaction(frame.faction)
        previewPanel:SetGender(frame.gender)
        RebuildTiles()
        RebuildFaceSliders()
    end

    male.DoClick = function()
        if frame.gender == "male" then return end
        male.selected = true
        female.selected = false
        frame.gender = "male"
        UpdateGender()
    end

    female.DoClick = function()
        if frame.gender == "female" then return end
        male.selected = false
        female.selected = true
        frame.gender = "female"
        UpdateGender()
    end

    local function setCategory(index)
        if frame.category == index and frame.categoryInitialized then return end
        frame.category = index
        local titles = {"Выберите прическу", "Выберите зрачки", "Выберите лицо", "Выберите одежду"}
        categoryTitle:SetText(titles[index])
        settings:SetVisible(index == 1)
        tileScroll:SetVisible(true)
        for _, sliderPanel in ipairs(faceSliders) do sliderPanel:SetVisible(false) end
        for i, button in ipairs(categories) do button.selected = i == index end
        RebuildTiles()
        RebuildFaceSliders()
        frame.categoryInitialized = true
    end

    for i, title in ipairs(categoryNames) do
        local button = vgui.Create("DButton", categoryPanel)
        button:SetText("")
        button:SetCursor("hand")
        button.categoryIndex = i
        button.selected = i == 1
        button.hoverAmount = 0
        button.flash = 0
        button.Paint = function(self, w, h)
            self.hoverAmount = Lerp(FrameTime() * 12, self.hoverAmount, self:IsHovered() and 1 or 0)
            self.flash = math.max(0, self.flash - FrameTime() * 5)
            if self.hoverAmount > 0 then
                surface.SetDrawColor(accent.r, accent.g, accent.b, self.hoverAmount * 18)
                surface.DrawRect(0, 0, w, h)
            end
            if self.selected then
                drawMaterial(materials.selected, 0, 0, w, h, white)
            end
            if self.flash > 0 then
                surface.SetDrawColor(accent.r, accent.g, accent.b, self.flash * 70)
                surface.DrawRect(0, 0, w, h)
            end
            draw.SimpleText(title, fontName(24), w * 0.5, h * 0.5, white, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
        end
        button.DoClick = function()
            button.flash = 1
            setCategory(button.categoryIndex)
        end
        categories[i] = button
    end

    local picker
    local function closePicker()
        if IsValid(picker) then
            picker:Remove()
            picker = nil
        end
    end

    local PICKER = {
        x = 642, y = 380, w = 350, h = 430,
        square = { x = 20, y = 62, w = 260, h = 260 },
        hue    = { x = 294, y = 62, w = 26, h = 260 },
        preview = { x = 20, y = 338, w = 60, h = 36 },
        cancel = { x = 20, y = 388, w = 150, h = 32 },
        done   = { x = 180, y = 388, w = 150, h = 32 },
    }
    local BG = Color(12, 10, 10, 245)

    local function openPicker()
        closePicker()

        local function S(v) return frame:S(v) end
        local function Inside(x, y, r)
            return x >= r.x and x <= r.x + r.w and y >= r.y and y <= r.y + r.h
        end

        local startColor = previewPanel.hairColor or Color(255, 255, 255)
        startColor = Color(startColor.r, startColor.g, startColor.b)
        local hue, saturation, value = ColorToHSV(startColor)

        picker = vgui.Create("DPanel", frame)
        picker:SetPos(S(PICKER.x), S(PICKER.y))
        picker:SetSize(S(PICKER.w), S(PICKER.h))
        picker:SetAlpha(0)
        picker:AlphaTo(255, 0.18, 0)
        picker:SetMouseInputEnabled(true)
        picker.hue = (hue or 0) / 360
        picker.saturation = saturation or 1
        picker.value = value or 1
        picker.dragMode = nil

        local function ApplyColor(self)
            local color = HSVToColor(self.hue * 360, self.saturation, self.value)
            frame.hairColor = color
            previewPanel:SetPlayerColor(color)
        end

        local function Cursor(self)
            local x, y = self:ScreenToLocal(gui.MouseX(), gui.MouseY())
            return x / frame.scale, y / frame.scale
        end

        local function UpdateSquare(self)
            local x, y = Cursor(self)
            local sq = PICKER.square
            self.saturation = math.Clamp((x - sq.x) / sq.w, 0, 1)
            self.value = 1 - math.Clamp((y - sq.y) / sq.h, 0, 1)
            ApplyColor(self)
        end

        local function UpdateHue(self)
            local _, y = Cursor(self)
            local hb = PICKER.hue
            self.hue = math.Clamp((y - hb.y) / hb.h, 0, 1)
            ApplyColor(self)
        end

        picker.OnMousePressed = function(self, code)
            if code ~= MOUSE_LEFT then return end
            local x, y = Cursor(self)
            if Inside(x, y, PICKER.square) then
                self.dragMode = "square"
                UpdateSquare(self)
            elseif Inside(x, y, PICKER.hue) then
                self.dragMode = "hue"
                UpdateHue(self)
            end
            self:MouseCapture(true)
        end

        picker.OnMouseReleased = function(self, code)
            if code == MOUSE_LEFT then
                self.dragMode = nil
                self:MouseCapture(false)
            end
        end

        picker.Think = function(self)
            if self.dragMode == "square" then UpdateSquare(self) end
            if self.dragMode == "hue" then UpdateHue(self) end
        end

        picker.Paint = function(self, w, h)
            surface.SetDrawColor(BG.r, BG.g, BG.b, BG.a)
            surface.DrawRect(0, 0, w, h)
            surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
            surface.DrawOutlinedRect(0, 0, w, h, S(1))

            draw.SimpleText("ЦВЕТ ВОЛОС", fontName(15), S(20), S(18), white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
            surface.DrawRect(S(20), S(46), S(PICKER.w - 40), S(1))

            local sq = PICKER.square
            local sx, sy, sw, sh = S(sq.x), S(sq.y), S(sq.w), S(sq.h)
            local hueColor = HSVToColor(self.hue * 360, 1, 1)
            surface.SetDrawColor(hueColor.r, hueColor.g, hueColor.b, 255)
            surface.DrawRect(sx, sy, sw, sh)

            local N = 64
            local stripW = math.ceil(sw / N) + 1
            for i = 0, N - 1 do
                local t = i / N
                surface.SetDrawColor(255, 255, 255, 255 * (1 - t))
                surface.DrawRect(sx + sw * t, sy, stripW, sh)
            end
            for i = 0, N - 1 do
                local t = i / N
                surface.SetDrawColor(0, 0, 0, 255 * t)
                surface.DrawRect(sx, sy + sh * t, sw, math.ceil(sh / N) + 1)
            end

            surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
            surface.DrawOutlinedRect(sx - S(1), sy - S(1), sw + S(2), sh + S(2), S(1))

            local markerX = sx + sw * self.saturation
            local markerY = sy + sh * (1 - self.value)
            surface.SetDrawColor(0, 0, 0, 255)
            surface.DrawOutlinedRect(markerX - S(7), markerY - S(7), S(14), S(14), S(2))
            surface.SetDrawColor(255, 255, 255, 255)
            surface.DrawOutlinedRect(markerX - S(6), markerY - S(6), S(12), S(12), S(2))

            local hb = PICKER.hue
            local hx, hy, hw, hh = S(hb.x), S(hb.y), S(hb.w), S(hb.h)
            local HN = 72
            for i = 0, HN - 1 do
                local c = HSVToColor(i / HN * 360, 1, 1)
                surface.SetDrawColor(c.r, c.g, c.b, 255)
                surface.DrawRect(hx, hy + hh * i / HN, hw, math.ceil(hh / HN) + 1)
            end
            surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
            surface.DrawOutlinedRect(hx - S(1), hy - S(1), hw + S(2), hh + S(2), S(1))

            local markerHue = hy + hh * self.hue
            surface.SetDrawColor(0, 0, 0, 255)
            surface.DrawRect(hx - S(5), markerHue - S(2), hw + S(10), S(4))
            surface.SetDrawColor(255, 255, 255, 255)
            surface.DrawRect(hx - S(4), markerHue - S(1), hw + S(8), S(2))

            local color = HSVToColor(self.hue * 360, self.saturation, self.value)
            local pv = PICKER.preview
            surface.SetDrawColor(color.r, color.g, color.b, 255)
            surface.DrawRect(S(pv.x), S(pv.y), S(pv.w), S(pv.h))
            surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
            surface.DrawOutlinedRect(S(pv.x), S(pv.y), S(pv.w), S(pv.h), S(1))

            draw.SimpleText(string.format("#%02X%02X%02X", color.r, color.g, color.b), fontName(15),
                S(92), S(pv.y + 10), white, TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
            draw.SimpleText(string.format("R %d   G %d   B %d", color.r, color.g, color.b), fontName(12),
                S(92), S(pv.y + 28), Color(200, 200, 200, 170), TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
        end

        local function Revert()
            frame.hairColor = startColor
            previewPanel:SetPlayerColor(startColor)
        end

        local function PickerButton(rect, label, onClick)
            local b = vgui.Create("DButton", picker)
            b:SetText("")
            b:SetCursor("hand")
            b:SetPos(S(rect.x), S(rect.y))
            b:SetSize(S(rect.w), S(rect.h))
            b.Paint = function(self, bw, bh)
                local hovered = self:IsHovered()
                if hovered then
                    surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
                else
                    surface.SetDrawColor(5, 4, 4, 200)
                end
                surface.DrawRect(0, 0, bw, bh)
                surface.SetDrawColor(accent.r, accent.g, accent.b, 255)
                surface.DrawOutlinedRect(0, 0, bw, bh, S(1))
                draw.SimpleText(label, fontName(12), bw * 0.5, bh * 0.5,
                    hovered and Color(10, 10, 10) or accent, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
            end
            b.DoClick = onClick
            return b
        end

        PickerButton(PICKER.cancel, "ОТМЕНА", function()
            Revert()
            closePicker()
        end)
        PickerButton(PICKER.done, "ГОТОВО", closePicker)
    end
    settings.DoClick = openPicker

    createCharacterButton.DoClick = function()
        createCharacterButton.pressAmount = 1
        local function ValidName(value)
            local length = utf8.len(value) or 0
            if length < 5 or length > 24 or value:find("_", 1, true) then return false end
            local capitals = 0
            for _, codepoint in utf8.codes(value) do
                local latin = (codepoint >= 65 and codepoint <= 90) or (codepoint >= 97 and codepoint <= 122)
                local cyrillic = (codepoint >= 0x410 and codepoint <= 0x44F) or codepoint == 0x401 or codepoint == 0x451
                if codepoint ~= 45 and not latin and not cyrillic then return false end
                if (codepoint >= 65 and codepoint <= 90) or (codepoint >= 0x410 and codepoint <= 0x42F) or codepoint == 0x401 then
                    capitals = capitals + 1
                end
            end
            return capitals <= 2
        end
        if not ValidName(nameInput:GetValue()) or not ValidName(surnameInput:GetValue()) then return end
        net.Start("SHIBI::Character::Assemble")
            net.WriteString(frame.gender or "male")
            net.WriteString(frame.faction or "shinigami")
            net.WriteUInt(SHIBI.Character.PendingSlot or 1, 2)
            net.WriteString(nameInput:GetValue())
            net.WriteString(surnameInput:GetValue())
            net.WriteUInt(previewPanel.clothesIndex or 1, 8)
            net.WriteUInt(previewPanel.faceIndex or 1, 8)
            net.WriteUInt(previewPanel.hairStyle or 0, 8)
            net.WriteColor(previewPanel.hairColor or Color(60, 40, 30))
            net.WriteUInt(previewPanel.eyeStyle or 0, 8)
            net.WriteFloat(1.5 + slider.value * 0.6)
            local flexes = previewPanel.flexValues or {}
            local keys = table.GetKeys(flexes)
            table.sort(keys)
            while #keys > 32 do
                table.remove(keys)
            end
            net.WriteUInt(#keys, 8)
            for _, k in ipairs(keys) do
                net.WriteString(k)
                net.WriteFloat(flexes[k])
            end
        net.SendToServer()

        hook.Run("ShibiCharacterCreate", {
            firstName = nameInput:GetValue(),
            lastName = surnameInput:GetValue(),
            gender = frame.gender,
            height = 1.5 + slider.value * 0.6,
            hairStyle = previewPanel.hairStyle,
            hairColor = previewPanel.hairColor,
            eyeStyle = previewPanel.eyeStyle,
            clothes = previewPanel.clothesIndex,
            face = previewPanel.faceIndex,
            height = 1.5 + slider.value * 0.6,
            flexes = previewPanel.flexValues
        })

        frame:Close()
    end

    frame.page = 1
    frame.category = 1

    frame.PerformLayout = function(self)
        local S = function(value) return self:S(value) end
        back:SetPos(S(30), S(29))
        back:SetSize(S(60), S(60))
        logo:SetPos(S(28), S(126))
        logo:SetSize(S(520), S(121))
        male:SetPos(S(31), S(291))
        male:SetSize(S(60), S(60))
        female:SetPos(S(103), S(291))
        female:SetSize(S(60), S(60))
        nameLabel:SetPos(S(31), S(370))
        nameLabel:SetSize(S(577), S(12))
        nameInput:SetPos(S(31), S(392))
        nameInput:SetSize(S(577), S(76))
        surnameLabel:SetPos(S(31), S(494))
        surnameLabel:SetSize(S(577), S(12))
        surnameInput:SetPos(S(31), S(516))
        surnameInput:SetSize(S(577), S(76))
        heightLabel:SetPos(S(31), S(643))
        heightLabel:SetSize(S(440), S(12))
        heightValue:SetPos(S(443), S(643))
        heightValue:SetSize(S(165), S(12))
        slider:SetPos(S(31), S(655))
        slider:SetSize(S(577), S(26))
        continueButton:SetPos(S(31), S(949))
        continueButton:SetSize(S(577), S(76))
        createCharacterButton:SetPos(S(31), S(949))
        createCharacterButton:SetSize(S(577), S(76))
        logoTwo:SetPos(S(28), S(126))
        logoTwo:SetSize(S(546), S(115))
        categoryPanel:SetPos(S(31), S(336))
        categoryPanel:SetSize(S(577), S(200))
        for i, button in ipairs(categories) do
            button:SetPos(0, S((i - 1) * 50))
            button:SetSize(S(210), S(42))
        end
        selectionPanel:SetPos(S(642), 0)
        selectionPanel:SetSize(S(404), S(1083))
        categoryTitle:SetPos(S(31), S(76))
        categoryTitle:SetSize(S(300), S(35))
        settings:SetPos(S(302), S(47))
        settings:SetSize(S(60), S(60))
        tileScroll:SetPos(S(31), S(122))
        tileScroll:SetSize(S(342), S(930))
        for i, sliderPanel in ipairs(faceSliders) do
            sliderPanel:SetPos(S(31), S(140 + (i - 1) * 74))
            sliderPanel:SetSize(S(342), S(55))
        end
        if IsValid(previewPanel) then
            previewPanel:SetPos(S(930), S(90))
            previewPanel:SetSize(S(770), S(1010))
        end
        local pageTwo = self.page == 2
        logo:SetVisible(not pageTwo)
        male:SetVisible(not pageTwo)
        female:SetVisible(not pageTwo)
        nameLabel:SetVisible(not pageTwo)
        nameInput:SetVisible(not pageTwo)
        surnameLabel:SetVisible(not pageTwo)
        surnameInput:SetVisible(not pageTwo)
        heightLabel:SetVisible(not pageTwo)
        heightValue:SetVisible(not pageTwo)
        slider:SetVisible(not pageTwo)
        continueButton:SetVisible(not pageTwo)
        createCharacterButton:SetVisible(pageTwo)
        logoTwo:SetVisible(pageTwo)
        categoryPanel:SetVisible(pageTwo)
        selectionPanel:SetVisible(pageTwo)
        setCategory(self.category or 1)
    end

    frame:InvalidateLayout(true)
end

SHIBI.Character.OpenCreator = openCharacterCreator
hook.Add("OnScreenSizeChanged", "ShibiCharacterCreatorResize", function()
    if IsValid(ShibiCharacterCreator) then
        timer.Simple(0, openCharacterCreator)
    end
end)

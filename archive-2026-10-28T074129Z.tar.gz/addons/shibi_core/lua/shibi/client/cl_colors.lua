SHIBI.ClientColors = SHIBI.ClientColors or {}

function SHIBI.ClientColors.ApplyColorModulation(color)
    render.SetColorModulation(color.r / 255, color.g / 255, color.b / 255)
end

function SHIBI.ClientColors.ResetColorModulation()
    render.SetColorModulation(1, 1, 1)
end

local CreateClientConVar = CreateClientConVar
CreateClientConVar("shibi_cross_type", "1", true, true, "Изменение стиля прицела", 1, 15)
CreateClientConVar("shibi_cross_size", "18", true, true, "Изменение размера прицела", 18, 48)
CreateClientConVar("shibi_cross_colorR", "255", true, true, "Изменение цвета прицела", 0, 255)
CreateClientConVar("shibi_cross_colorG", "255", true, true, "Изменение цвета прицела", 0, 255)
CreateClientConVar("shibi_cross_colorB", "255", true, true, "Изменение цвета прицела", 0, 255)

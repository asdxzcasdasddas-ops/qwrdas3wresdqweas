local C = SHIBI.Cutscene

local cvDebug = CreateClientConVar("shibi_cutscene_debug", "0", false, false)
local function Debug(msg)
    if cvDebug:GetBool() then print("[Cutscene] " .. msg) end
end

local BLEND_IN     = 0.5
local BLEND_OUT    = 0.6
local BAR_TIME     = 0.5
local BAR_SIZE     = 0.12
local HULL         = Vector(6, 6, 6)
local FOV_MIN, FOV_MAX = 30, 110
local POS_OMEGA  = 7
local LOOK_OMEGA = 9
local BODY_MARGIN = 40
local FADE_OUT   = 0.6
local FADE_HOLD  = 0.3

local current

function C.IsActive()
    return current ~= nil
end

local function Smooth(x)
    x = math.Clamp(x, 0, 1)
    return x * x * (3 - 2 * x)
end

local function BasePos(cur)
    if IsValid(cur.focus) then
        if not cur.base then
            cur.base = cur.point + Vector(0, 0, cur.focus:OBBMaxs().z * 0.72)
        end
        return cur.base
    end
    if cur.index ~= 0 then return cur.anchor:GetPos() end
    return cur.point
end

local function BaseYaw(cur)
    if cur.index ~= 0 and IsValid(cur.anchor) then
        local ent = cur.anchor
        if ent:IsPlayer() then return ent:EyeAngles().y end
        return ent:GetAngles().y
    end
    return cur.pointYaw
end

local function BaseReady(cur)
    if cur.focusIndex ~= 0 then return IsValid(cur.focus) end
    if cur.index ~= 0 then return IsValid(cur.anchor) end
    return true
end

local function Alive(cur)
    if cur.index == 0 then return true end
    local ent = cur.anchor
    if not IsValid(ent) then return false end
    if ent:IsPlayer() then return ent:Alive() end
    return true
end

local function Phase()
    local cur = current
    if not cur then return end

    if cur.index ~= 0 and not IsValid(cur.anchor) then
        cur.anchor = Entity(cur.index)
    end
    if cur.focusIndex ~= 0 and not IsValid(cur.focus) then
        cur.focus = Entity(cur.focusIndex)
    end

    local now = CurTime()
    local grace = now - cur.startTime < 1.0
    if not cur.endAt then
        local lost = not BaseReady(cur) and not grace
        local dead = not Alive(cur)
        local timeUp = now - cur.startTime >= cur.def.duration
        if lost or dead or timeUp then
            cur.endAt = now
            Debug(string.format("конец сцены %s: %s, прошло %.2f с из %.2f",
                cur.id, lost and "база потеряна" or (dead and "якорь мёртв" or "время вышло"),
                now - cur.startTime, cur.def.duration))
        end
    end

    if cur.endAt and now - cur.endAt >= BLEND_OUT + FADE_HOLD then
        current = nil
        return
    end

    return cur
end

local function FadeAlpha(cur)
    local now = CurTime()
    local fadeOut = cur.def.fadeOut or FADE_OUT
    local toBlack = 0
    if cur.endAt then
        toBlack = 1
    else
        toBlack = Smooth((now - cur.startTime - (cur.def.duration - fadeOut)) / fadeOut)
    end

    local reveal = 1
    if cur.endAt then
        reveal = 1 - Smooth((now - cur.endAt - FADE_HOLD) / BLEND_OUT)
    end

    return toBlack * reveal
end

local function Strength(cur)
    local now = CurTime()
    local blendIn = cur.def.blendIn or BLEND_IN
    local intro = blendIn > 0 and Smooth((now - cur.startTime) / blendIn) or 1
    local outro = cur.endAt and Smooth((now - cur.endAt) / BLEND_OUT) or 0
    return intro * (1 - outro)
end

net.Receive(C.NET, function()
    local starting = net.ReadBool()
    local serial   = net.ReadUInt(32)

    if not starting then
        if current and current.serial == serial and not current.endAt then
            current.endAt = CurTime()
        end
        return
    end

    local index      = net.ReadUInt(16)
    local focusIndex = net.ReadUInt(16)
    local id         = net.ReadString()
    local point      = net.ReadVector()
    local yaw        = net.ReadFloat()

    local def = C.Scenes[id]
    if not def then return end

    Debug(string.format("старт сцены %s, длительность %.2f с", id, def.duration))

    current = {
        id         = id,
        serial     = serial,
        index      = index,
        anchor     = index ~= 0 and Entity(index) or nil,
        focusIndex = focusIndex,
        focus      = focusIndex ~= 0 and Entity(focusIndex) or nil,
        point      = point,
        pointYaw   = yaw,
        def        = def,
        startTime  = CurTime(),
        seed       = math.Rand(0, 1000),
        clip       = 1,
    }
end)

local function ImpulseAngle(def, elapsed)
    local pitch, yaw = 0, 0
    for _, imp in ipairs(def.impulses) do
        local dt = elapsed - imp.at
        if dt >= 0 and dt <= imp.dur then
            local env = math.exp(-dt * 7) * math.sin(dt * 30)
            pitch = pitch + (imp.pitch or 0) * env
            yaw   = yaw + (imp.yaw or 0) * env
        end
    end
    return pitch, yaw
end

local function RumbleAngle(def, elapsed)
    local pitch, yaw = 0, 0
    for _, r in ipairs(def.rumbles) do
        local dt = elapsed - r.from
        local len = r.to - r.from
        if dt >= 0 and dt <= len then
            local env = math.sin(math.pi * dt / len)
            local t = elapsed * (r.freq or 40)
            pitch = pitch + (r.pitch or 0) * env * math.sin(t)
            yaw   = yaw + (r.yaw or 0) * env * math.sin(t * 1.37 + 0.6)
        end
    end
    return pitch, yaw
end

local function ClampOutsideBody(cur, pos)
    local ent = cur.focus
    if not IsValid(ent) or not cur.point then return pos end

    local mins, maxs = ent:OBBMins(), ent:OBBMaxs()
    local height = maxs.z - mins.z
    local halfXY = math.max(maxs.x - mins.x, maxs.y - mins.y) * 0.5
    local center = cur.point + Vector(0, 0, (mins.z + maxs.z) * 0.5)
    local modelR = ent:GetModelRadius() or 0
    local minDist = cur.def.minDistance or 200
    local radius = math.max(modelR, height * 0.5, halfXY, minDist) + BODY_MARGIN

    local offset = pos - center
    local dist = offset:Length()
    if dist >= radius then return pos end

    local dir = dist > 0.01 and offset * (1 / dist) or Vector(-1, 0, 0)
    return center + dir * radius
end

local function Spring(pos, vel, target, omega, dt)
    local acc = (target - pos) * (omega * omega) - vel * (2 * omega)
    vel = vel + acc * dt
    pos = pos + vel * dt
    return pos, vel
end

local function ScenePose(cur, elapsed, baseFov)
    local def = cur.def
    local progress = elapsed / def.duration

    local localPos, localLook, localFov = C.Sample(def, progress)

    local yaw  = Angle(0, cur.yaw, 0)
    local base = BasePos(cur)
    local fwd, right, up = yaw:Forward(), yaw:Right(), yaw:Up()

    local focus   = base + fwd * localLook.x + right * localLook.y + up * localLook.z
    local desired = base + fwd * localPos.x + right * localPos.y + up * localPos.z

    local tr = util.TraceHull({
        start  = focus,
        endpos = desired,
        mins   = -HULL,
        maxs   = HULL,
        filter = cur.focus or cur.anchor or LocalPlayer(),
        mask   = MASK_SOLID_BRUSHONLY,
    })

    local dt = math.min(FrameTime(), 0.05)
    local target = math.max(tr.Fraction, 0.15)
    if target < cur.clip then
        cur.clip = math.Approach(cur.clip, target, dt * 18)
    else
        cur.clip = math.Approach(cur.clip, target, dt * 3)
    end

    local rawPos = focus + (desired - focus) * cur.clip

    local t = CurTime() + cur.seed
    local noiseR = math.sin(t * 1.3) * 0.5 + math.sin(t * 2.7) * 0.25
    local noiseU = math.sin(t * 1.7 + 1.1) * 0.4
    rawPos = rawPos + right * noiseR + up * noiseU
    rawPos = ClampOutsideBody(cur, rawPos)

    local prev = cur.prevProgress or progress
    local cut = false
    for _, k in ipairs(def.keys) do
        if k.hard and prev < k.t and k.t <= progress then cut = true end
    end
    cur.prevProgress = progress

    if not cur.camPos or cut then
        cur.camPos, cur.camPosV   = rawPos, Vector(0, 0, 0)
        cur.camLook, cur.camLookV = focus, Vector(0, 0, 0)
    else
        cur.camPos, cur.camPosV   = Spring(cur.camPos, cur.camPosV, rawPos, POS_OMEGA, dt)
        cur.camLook, cur.camLookV = Spring(cur.camLook, cur.camLookV, focus, LOOK_OMEGA, dt)
    end
    cur.camPos = ClampOutsideBody(cur, cur.camPos)

    local ang = (cur.camLook - cur.camPos):Angle()
    local pitch, yawImp = ImpulseAngle(def, elapsed)
    local rPitch, rYaw = RumbleAngle(def, elapsed)
    ang.p = ang.p + pitch + rPitch
    ang.y = ang.y + yawImp + rYaw

    local fov = math.Clamp(localFov or baseFov, FOV_MIN, FOV_MAX)

    return cur.camPos, ang, fov
end

hook.Add("CalcView", "SHIBI::Cutscene::View", function(ply, origin, angles, fov)
    local cur = Phase()
    if not cur then return end

    local now = CurTime()
    local elapsed = math.min(now - cur.startTime, cur.def.duration)
    local ready = BaseReady(cur)

    if not cur.from then
        cur.from = { origin = origin, angles = angles, fov = fov }
    end
    if ready and not cur.yaw then
        cur.yaw = BaseYaw(cur)
    end

    local pos, ang, sceneFov
    if ready and cur.yaw and not cur.endAt then
        pos, ang, sceneFov = ScenePose(cur, elapsed, fov)
        cur.last = { origin = pos, angles = ang, fov = sceneFov }
    else
        cur.last = cur.last or { origin = origin, angles = angles, fov = fov }
        pos, ang, sceneFov = cur.last.origin, cur.last.angles, cur.last.fov
    end

    local blendIn = cur.def.blendIn or BLEND_IN
    local inT = blendIn > 0 and Smooth((now - cur.startTime) / blendIn) or 1
    if inT < 1 then
        pos = LerpVector(inT, cur.from.origin, pos)
        ang = LerpAngle(inT, cur.from.angles, ang)
        sceneFov = Lerp(inT, cur.from.fov, sceneFov)
    end

    if cur.endAt then
        local outT = Smooth((now - cur.endAt) / BLEND_OUT)
        pos = LerpVector(outT, cur.last.origin, origin)
        ang = LerpAngle(outT, cur.last.angles, angles)
        sceneFov = Lerp(outT, cur.last.fov, fov)
    end

    return {
        origin     = pos,
        angles     = ang,
        fov        = sceneFov,
        drawviewer = true,
    }
end)

hook.Add("ShouldDrawLocalPlayer", "SHIBI::Cutscene::Model", function()
    if Phase() then return true end
end)

hook.Add("PreDrawViewModel", "SHIBI::Cutscene::ViewModel", function()
    if Phase() then return true end
end)

hook.Add("HUDShouldDraw", "SHIBI::Cutscene::HUD", function()
    if Phase() then return false end
end)

hook.Add("RenderScreenspaceEffects", "SHIBI::Cutscene::Post", function()
    local cur = Phase()
    if not cur then return end

    local k = Strength(cur)
    if k <= 0.001 then return end

    DrawColorModify({
        ["$pp_colour_addr"]        = 0,
        ["$pp_colour_addg"]        = 0,
        ["$pp_colour_addb"]        = 0,
        ["$pp_colour_brightness"]  = -0.03 * k,
        ["$pp_colour_contrast"]    = 1 + 0.15 * k,
        ["$pp_colour_colour"]      = 1 - 0.25 * k,
        ["$pp_colour_mulr"]        = 0,
        ["$pp_colour_mulg"]        = 0,
        ["$pp_colour_mulb"]        = 0,
    })

    DrawBloom(0.6, 1.1 * k, 8, 8, 2, 1, 1, 1, 1)
end)

hook.Add("PostRenderVGUI", "SHIBI::Cutscene::Overlay", function()
    local cur = Phase()
    if not cur then return end

    local now = CurTime()
    local elapsed = now - cur.startTime

    for _, fl in ipairs(cur.def.flashes) do
        local dt = elapsed - fl.at
        if dt >= 0 and dt <= fl.dur then
            local rise = math.min(1, dt / 0.06)
            local fade = (1 - dt / fl.dur) ^ 2
            local col = fl.color or Color(255, 255, 255)
            surface.SetDrawColor(col.r, col.g, col.b, 255 * fl.alpha * rise * fade)
            surface.DrawRect(0, 0, ScrW(), ScrH())
        end
    end

    local fade = FadeAlpha(cur)
    if fade > 0.001 then
        surface.SetDrawColor(0, 0, 0, 255 * fade)
        surface.DrawRect(0, 0, ScrW(), ScrH())
    end

    local inT = Smooth(elapsed / BAR_TIME)
    local outT = cur.endAt and Smooth((now - cur.endAt) / BAR_TIME) or 0
    local h = math.floor(ScrH() * BAR_SIZE * inT * (1 - outT))
    if h > 0 then
        surface.SetDrawColor(0, 0, 0, 255)
        surface.DrawRect(0, 0, ScrW(), h)
        surface.DrawRect(0, ScrH() - h, ScrW(), h)
    end
end)

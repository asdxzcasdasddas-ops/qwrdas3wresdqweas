if SERVER then return end

local NET_DASH = "SHIBI::Dash::Request"
local nextRequest = 0

local function GetDashConfig()
    local dash = SHIBI and SHIBI.Dash
    return dash and dash.Config
end

local function IsDashWeapon(ply, config)
    local weapon = ply:GetActiveWeapon()
    if not IsValid(weapon) then return false end
    local class = weapon:GetClass()
    local list = config.DashWeaponClasses
    if istable(list) then return list[class] == true end
    return class == config.TestWeaponClass
end

local function GetDashDirectionCode(ply)
    local forward = 0
    local side = 0
    if ply:KeyDown(IN_FORWARD) and not ply:KeyDown(IN_BACK) then
        forward = 1
    elseif ply:KeyDown(IN_BACK) and not ply:KeyDown(IN_FORWARD) then
        forward = -1
    end
    if ply:KeyDown(IN_MOVERIGHT) and not ply:KeyDown(IN_MOVELEFT) then
        side = 1
    elseif ply:KeyDown(IN_MOVELEFT) and not ply:KeyDown(IN_MOVERIGHT) then
        side = -1
    end

    local config = GetDashConfig()
    local codes = config and config.InputCodes
    local code = codes and codes[forward .. ":" .. side]
    return isnumber(code) and code or 0
end

hook.Add("PlayerButtonDown", "SHIBI::Dash::QInput", function(ply, button)
    if button ~= KEY_Q or ply ~= LocalPlayer() then return end
    local config = GetDashConfig()
    if not config then return end
    local settings = config.TestWeapon
    if not istable(settings) or settings.Enabled ~= true then return end
    local security = config.Security or {}
    local guard = math.Clamp(tonumber(security.RequestGuard) or 0.12, 0.12, 1)
    if not IsFirstTimePredicted() or CurTime() < nextRequest then return end

    local weapon = ply:GetActiveWeapon()
    if not IsValid(weapon) or not IsDashWeapon(ply, config) then return end
    if IsValid(vgui.GetKeyboardFocus()) then return end

    nextRequest = CurTime() + guard
    net.Start(NET_DASH)
        net.WriteUInt(GetDashDirectionCode(ply), 3)
    net.SendToServer()
end)

hook.Add("PlayerBindPress", "SHIBI::Dash::ConsumeQBind", function(ply, bind, pressed)
    if not pressed or ply ~= LocalPlayer() then return end
    local config = GetDashConfig()
    if not config then return end
    local weapon = ply:GetActiveWeapon()
    if not IsValid(weapon) or not IsDashWeapon(ply, config) then return end

    local qBinding = input.LookupKeyBinding(KEY_Q)
    if qBinding and string.lower(bind) == string.lower(qBinding) then
        return true
    end
end)

SHIBI.Fonts = SHIBI.Fonts or {}
SHIBI.Fonts.Heights = SHIBI.Fonts.Heights or {}
SHIBI.Fonts.List = SHIBI.Fonts.List or {}
SHIBI.Fonts.Prefix = "SHIBI"
SHIBI.Fonts.Default = "Gilroy"
SHIBI.Fonts.Curname = "Font"

local ResponsiveX = SHIBI.ResponsiveX
local ResponsiveY = SHIBI.ResponsiveY
local Responsive = SHIBI.Responsive

local font_cache = {}
local screenW = ScrW()
local size_offset = (screenW > 1920 and screenW < 3840) and 2 or (screenW >= 3840 and 4 or 0)

function SHIBI.Fonts:CreateNew(file_fontname, fontname, size, weight, italic)
    local adjusted_size = size + size_offset
    local font_id = string.format("%s.%s.%s%s%d", self.Prefix, fontname, weight == 1000 and "Bold." or "", italic and "Italic." or "", size)

    if font_cache[font_id] then return font_id end

    surface.CreateFont(font_id, {
        font = file_fontname,
        size = SHIBI.ResponsiveY(adjusted_size),
        weight = weight or 500,
        italic = italic or false,
        extended = true
    })

    self.List[font_id] = true
    self.Heights[font_id] = draw.GetFontHeight(font_id)
    font_cache[font_id] = true

    return font_id
end

function SHIBI:Font(size, weight, italic)
    return self.Fonts:CreateNew(self.Fonts.Default, self.Fonts.Curname, size, weight, italic)
end

function SHIBI:FontWithName(fontname, size, weight, italic)
    return self.Fonts:CreateNew(fontname, fontname, size, weight, italic)
end

function SHIBI.Fonts:GetAll()
    return self.List
end

function SHIBI:SetFontName(name)
    self.Fonts.Curname = isstring(name) and name or "Font"
end

function SHIBI:SetFont(name)
    self.Fonts.Default = isstring(name) and name or "Gilroy"
end

function SHIBI:ResetFont()
    self.Fonts.Default = "Gilroy"
end

function SHIBI:SetFontPrefix(name)
    self.Fonts.Prefix = isstring(name) and name or "SHIBI"
end

function SHIBI.Fonts:GangOfThree(size, weight, italic)
    local font_id = string.format("SHIBI.GangOfThree.%s%d", weight == 1000 and "Bold." or "", size)

    if font_cache[font_id] then return font_id end

    surface.CreateFont(font_id, {
        font = "Gang of Three",
        size = SHIBI.ResponsiveY(size),
        weight = weight or 500,
        italic = italic or false,
        extended = true
    })

    font_cache[font_id] = true
    return font_id
end

function SHIBI:GangOfThree(size, weight, italic)
    return self.Fonts:GangOfThree(size, weight, italic)
end

function SHIBI.Fonts:CreateDefaults()
    local sizes = {10, 12, 15, 18, 20, 22, 25, 30, 32, 35, 40, 45, 50, 55, 60, 65, 70}
    local weights = {500, 1000}
    local italics = {false, true}

    for _, size in ipairs(sizes) do
        for _, weight in ipairs(weights) do
            for _, italic in ipairs(italics) do
                SHIBI:Font(size, weight, italic)
            end
        end
    end
end

hook.Add("InitPostEntity", "SHIBI::Fonts::Init", function()
    SHIBI.Fonts:CreateDefaults()
    SHIBI.Log("[Fonts] Система шрифтов загружена")
end)

SHIBI.Log("[Fonts] cl_fonts.lua загружен")

function SHIBI.Fonts:CreateEx(family, name, size, data, force)
    data = data or {}
    local font_id = string.format("%s.%s.%d%s", self.Prefix, name, size, data.suffix and ("." .. data.suffix) or "")

    if font_cache[font_id] and not force then return font_id end

    surface.CreateFont(font_id, {
        font      = family,
        size      = SHIBI.ResponsiveY(size + size_offset),
        weight    = data.weight or 500,
        italic    = data.italic or false,
        blursize  = data.blursize or 0,
        scanlines = 0,
        antialias = data.antialias ~= false,
        additive  = data.additive or false,
        outline   = data.outline or false,
        shadow    = data.shadow or false,
        extended  = true,
    })

    self.List[font_id]    = true
    self.Heights[font_id] = draw.GetFontHeight(font_id)
    font_cache[font_id]   = true

    return font_id
end

if not CLIENT then return end

SHIBI.Character = SHIBI.Character or {}

local hairMaterialWords = {
    "hair",
    "bang",
    "fringe",
    "ponytail",
    "pigtail",
    "braid",
    "髪",
}
local materialCache = {}

local function IsHairMaterial(materialName)
    if not isstring(materialName) then return false end

    local normalized = string.lower(string.Replace(materialName, "\\", "/"))
    for _, word in ipairs(hairMaterialWords) do
        if string.find(normalized, word, 1, true) then
            return true
        end
    end

    return false
end

local function MakeTintedHairMaterial(materialName, color)
    local source = Material(materialName)
    if not source or source:IsError() then return nil end

    local baseTexture = source:GetString("$basetexture", "")
    if baseTexture == "" then return nil end

    local key = materialName .. ":" .. color.r .. ":" .. color.g .. ":" .. color.b
    if materialCache[key] then return materialCache[key] end

    local name = "SHIBI_HairTint_" .. util.CRC(key)
    local parameters = {
        ["$basetexture"] = baseTexture,
        ["$color2"] = string.format("[%g %g %g]", color.r / 255, color.g / 255, color.b / 255),
        ["$model"] = "1",
    }

    local lightwarpTexture = source:GetString("$lightwarptexture", "")
    if lightwarpTexture ~= "" then
        parameters["$lightwarptexture"] = lightwarpTexture
    end
    if source:GetInt("$alphatest") == 1 then parameters["$alphatest"] = "1" end
    if source:GetInt("$nocull") == 1 then parameters["$nocull"] = "1" end
    if source:GetInt("$translucent") == 1 then parameters["$translucent"] = "1" end
    if source:GetInt("$vertexalpha") == 1 then parameters["$vertexalpha"] = "1" end
    if source:GetInt("$vertexcolor") == 1 then parameters["$vertexcolor"] = "1" end

    local tinted = CreateMaterial(name, "VertexLitGeneric", parameters)
    materialCache[key] = tinted
    return tinted
end

function SHIBI.Character.ApplyHairColor(ent, value)
    if not IsValid(ent) then return end

    local color = IsColor(value) and Color(value.r, value.g, value.b, 255) or Color(255, 255, 255)
    ent.SHIBI_HairColor = color

    local materials = ent:GetMaterials() or {}
    for index, materialName in ipairs(materials) do
        if IsHairMaterial(materialName) then
            local tinted = MakeTintedHairMaterial(materialName, color)
            if tinted then
                ent:SetSubMaterial(index - 1, tinted:GetName())
            end
        end
    end
end

if matproxy and matproxy.Add then
    matproxy.Add({
        name = "HairColor",
        init = function(self, mat, values)
            self.resultVar = values.resultVar or "$color2"
            self.default = Vector(0.75, 0.75, 0.75)

            if isvector(values.default) then
                self.default = values.default
            elseif isstring(values.default) then
                local numbers = {}
                for number in string.gmatch(values.default, "[-+]?%d*%.?%d+") do
                    numbers[#numbers + 1] = tonumber(number)
                end
                if #numbers >= 3 then
                    self.default = Vector(numbers[1], numbers[2], numbers[3])
                end
            end
        end,
        bind = function(self, mat, ent)
            local color
            if IsValid(ent) and IsColor(ent.SHIBI_HairColor) then
                color = ent.SHIBI_HairColor
            elseif IsValid(ent) then
                local vector = ent:GetNWVector("SHIBI::HairColor", self.default)
                color = Color(
                    math.Clamp(vector.x * 255, 0, 255),
                    math.Clamp(vector.y * 255, 0, 255),
                    math.Clamp(vector.z * 255, 0, 255)
                )
            else
                color = Color(
                    math.Clamp(self.default.x * 255, 0, 255),
                    math.Clamp(self.default.y * 255, 0, 255),
                    math.Clamp(self.default.z * 255, 0, 255)
                )
            end

            mat:SetVector(self.resultVar, Vector(color.r / 255, color.g / 255, color.b / 255))
        end,
    })
end

net.Receive("SHIBI::Character::HairColor", function()
    local head = net.ReadEntity()
    local body = net.ReadEntity()
    local color = net.ReadVector()
    local hairColor = Color(
        math.Clamp(color.x * 255, 0, 255),
        math.Clamp(color.y * 255, 0, 255),
        math.Clamp(color.z * 255, 0, 255)
    )
    SHIBI.Character.ApplyHairColor(head, hairColor)
    SHIBI.Character.ApplyHairColor(body, hairColor)
end)

hook.Add("NetworkEntityCreated", "SHIBI::Character::RestoreHairColor", function(ent)
    timer.Simple(0.25, function()
        if not IsValid(ent) then return end
        local color = ent:GetNWVector("SHIBI::HairColor", vector_origin)
        if color == vector_origin then return end
        SHIBI.Character.ApplyHairColor(ent, Color(
            math.Clamp(color.x * 255, 0, 255),
            math.Clamp(color.y * 255, 0, 255),
            math.Clamp(color.z * 255, 0, 255)
        ))
    end)
end)

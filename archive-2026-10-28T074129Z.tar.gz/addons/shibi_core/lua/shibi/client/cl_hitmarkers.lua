local HM   = SHIBI.HitMarkers
local TYPE = HM.TYPE

local CurTime, IsValid, EyePos = CurTime, IsValid, EyePos
local math_min, math_max, math_sin, math_cos, math_rad, math_deg, math_atan2, math_log =
      math.min, math.max, math.sin, math.cos, math.rad, math.deg, math.atan2, math.log
local math_Rand, math_Clamp, Lerp = math.Rand, math.Clamp, Lerp
local surface_SetFont, surface_SetTextColor, surface_SetTextPos, surface_DrawText =
      surface.SetFont, surface.SetTextColor, surface.SetTextPos, surface.DrawText
local surface_SetDrawColor, surface_SetMaterial, surface_DrawTexturedRect, surface_DrawTexturedRectRotated =
      surface.SetDrawColor, surface.SetMaterial, surface.DrawTexturedRect, surface.DrawTexturedRectRotated

local unit = 1
local function RY(v) return v * unit end

local cvEnabled = CreateClientConVar("shibi_hitmarkers", "1", true, false, "Показывать хитмаркеры урона", 0, 1)

HM.Config = HM.Config or {
    FontId        = "bleach",
    FontSize      = 64,
    LabelSize     = 28,
    GlowBlur      = 8,

    PoolSize      = 48,
    MaxSparks     = 14,

    StackWindow   = 0.7,
    StackStepY    = 24,
    StackMax      = 6,
    JitterX       = 30,
    JitterY       = 8,
    CriticalLabelOffsetX = 0,

    HeadOffset    = 8,
    FollowTarget  = true,
    Comma         = true,

    NearDist      = 250,
    FarDist       = 2200,
    FarScale      = 0.65,

    AmountRef     = 150,
    AmountK       = 0.10,
    AmountMin     = 0.85,
    AmountMax     = 1.35,

    FlashMaterial = "sprites/light_glow02_add",
}
local cfg = HM.Config

HM.Styles = HM.Styles or {
    [TYPE.NORMAL] = {
        color = Color(255, 242, 160), hitFlash = 0.06,
        scale = 0.6, life = 0.85, fade = 0.3, fadeScale = 0.8,
        pop = 0.16, popFrom = 0.3, overshoot = 2.2,
        hop = 14, drift = 18, rise = 46,
        tiltFrom = -8, tiltTo = -3, skewFrom = 0.30, skewTo = 0.12,
        outline = { color = Color(0, 0, 0), size = 5, steps = 8 },
    },

    [TYPE.CRIT] = {
        color = Color(255, 104, 28), hitFlash = 0.08,
        scale = 0.95, life = 1.1, fade = 0.35, fadeScale = 0.85,
        pop = 0.2, popFrom = 2.1, overshoot = 2.0,
        hop = 0, drift = 14, rise = 56, shake = 7,
        tiltFrom = -14, tiltTo = -5, skewFrom = 0.38, skewTo = 0.16,
        outline = { color = Color(0, 0, 0), size = 6, steps = 12 },
        rim     = { color = Color(255, 225, 140, 200), size = 2 },
        flash   = { color = Color(255, 140, 40), size = 3.2, time = 0.28 },
        sparks  = {
            count = 12, speedMin = 260, speedMax = 600, gravity = 900,
            lifeMin = 0.30, lifeMax = 0.55, lenMin = 14, lenMax = 30, thick = 3,
            color = Color(255, 220, 90), color2 = Color(255, 70, 20),
        },
        label = { text = "CRITICAL!", color = Color(255, 232, 120), offsetY = -0.78 },
    },

    [TYPE.SPECIAL] = {
        color = Color(228, 246, 255), hitFlash = 0.1,
        scale = 1.15, life = 1.35, fade = 0.4, fadeScale = 0.9,
        pop = 0.24, popFrom = 0.2, overshoot = 2.6,
        hop = 10, drift = 14, rise = 64, shake = 3,
        tiltFrom = -10, tiltTo = -4, skewFrom = 0.32, skewTo = 0.14,
        outline = { color = Color(0, 0, 0), size = 6, steps = 12 },
        rim     = { color = Color(140, 210, 255, 220), size = 2 },
        glow    = { color = Color(60, 160, 255), alpha = 0.9, passes = 2, pulse = 5 },
        flash   = { color = Color(90, 180, 255), size = 3.8, time = 0.36 },
        sparks  = {
            count = 9, speedMin = 180, speedMax = 420, gravity = 300,
            lifeMin = 0.35, lifeMax = 0.6, lenMin = 12, lenMax = 26, thick = 3,
            color = Color(190, 235, 255), color2 = Color(50, 130, 255),
        },
    },
}

local function EaseOutCubic(t) t = 1 - t return 1 - t * t * t end
local function EaseInQuad(t) return t * t end
local function EaseInCubic(t) return t * t * t end

local function EaseOutBack(t, s)
    t = t - 1
    return t * t * ((s + 1) * t + s) + 1
end

local function EaseOutBounce(t)
    local n, d = 7.5625, 2.75
    if t < 1 / d then return n * t * t end
    if t < 2 / d then t = t - 1.5 / d return n * t * t + 0.75 end
    if t < 2.5 / d then t = t - 2.25 / d return n * t * t + 0.9375 end
    t = t - 2.625 / d
    return n * t * t + 0.984375
end

HM.Fonts = HM.Fonts or {}
HM.Fonts.mainBySize = HM.Fonts.mainBySize or {}
HM.Fonts.glowBySize = HM.Fonts.glowBySize or {}
HM.Fonts.labelBySize = HM.Fonts.labelBySize or {}

local FONT_MIN, FONT_MAX, FONT_STEP = 16, 160, 4
HM.Fonts.Sizes = {}
for size = FONT_MIN, FONT_MAX, FONT_STEP do
    HM.Fonts.Sizes[#HM.Fonts.Sizes + 1] = size
end

function HM.BuildFonts(force)
    if not SHIBI.Fonts or not SHIBI.Fonts.CreateEx or not SHIBI.GetFontFamily then
        HM._fontsReady = false
        return false
    end

    unit = SHIBI.ResponsiveY(1000) / 1000
    local family = SHIBI.GetFontFamily(cfg.FontId, "Tahoma")
    for _, size in ipairs(HM.Fonts.Sizes) do
        HM.Fonts.mainBySize[size] = SHIBI.Fonts:CreateEx(family, "HitMarker", size,
            { weight = 800, suffix = "Main" .. size }, force)
        HM.Fonts.glowBySize[size] = SHIBI.Fonts:CreateEx(family, "HitMarker", size,
            { weight = 800, blursize = cfg.GlowBlur, additive = true, suffix = "Glow" .. size }, force)
        HM.Fonts.labelBySize[size] = SHIBI.Fonts:CreateEx(family, "HitMarker", size,
            { weight = 800, suffix = "Label" .. size }, force)
    end
    HM._fontsReady = isstring(HM.Fonts.mainBySize[FONT_MIN])
        and isstring(HM.Fonts.mainBySize[FONT_MAX])
        and isstring(HM.Fonts.glowBySize[FONT_MIN])
        and isstring(HM.Fonts.labelBySize[FONT_MIN])
    return HM._fontsReady
end

local function PickSize(nominal)
    nominal = math_Clamp(math.floor(nominal / FONT_STEP + 0.5) * FONT_STEP, FONT_MIN, FONT_MAX)
    return nominal
end

local function GetFont(map, size)
    local font = map and map[size]
    if isstring(font) then return font end

    for delta = FONT_STEP, FONT_MAX - FONT_MIN, FONT_STEP do
        local smaller = map and map[size - delta]
        if isstring(smaller) then return smaller end
        local larger = map and map[size + delta]
        if isstring(larger) then return larger end
    end
    return "DermaDefaultBold"
end

hook.Add("OnScreenSizeChanged", "SHIBI::HitMarker::Fonts", function()
    timer.Simple(0, function() HM.BuildFonts(true) end)
end)

timer.Simple(0, function() HM.BuildFonts() end)

local flashMat = Material(cfg.FlashMaterial)

local DirCache = {}
local function Dirs(steps)
    local d = DirCache[steps]
    if d then return d end
    d = {}
    for i = 0, steps - 1 do
        local a = (i / steps) * math.pi * 2
        d[#d + 1] = math_cos(a)
        d[#d + 1] = math_sin(a)
    end
    DirCache[steps] = d
    return d
end

local Pool, Active = {}, {}
local FreeStack, freeCount, activeCount = {}, 0, 0
local nextOrder = 0
local Stack = setmetatable({}, { __mode = "k" })
local StackWorld = { t = 0, n = 0 }

local function NewMarker()
    local m = { pos = Vector(), sparks = {}, sparkN = 0, slot = 0 }
    for i = 1, cfg.MaxSparks do
        m.sparks[i] = { vx = 0, vy = 0, life = 0, len = 0, tint = 0 }
    end
    return m
end

function HM.InitPool()
    Pool, Active, FreeStack = {}, {}, {}
    activeCount, freeCount = 0, 0
    nextOrder = 0
    for i = 1, cfg.PoolSize do
        local m = NewMarker()
        Pool[i] = m
        freeCount = freeCount + 1
        FreeStack[freeCount] = m
    end
end

local function Acquire(now)
    local m
    if freeCount > 0 then
        m = FreeStack[freeCount]
        FreeStack[freeCount] = nil
        freeCount = freeCount - 1
    else
        
        local oldest, oldestIdx = nil, 0
        for i = 1, activeCount do
            local a = Active[i]
            if not oldest or a.born < oldest.born then oldest, oldestIdx = a, i end
        end
        m = oldest
        Active[oldestIdx] = Active[activeCount]
        Active[activeCount] = nil
        activeCount = activeCount - 1
    end
    activeCount = activeCount + 1
    Active[activeCount] = m
    return m
end

local function ReleaseAt(i)
    local m = Active[i]
    m.ent = nil
    Active[i] = Active[activeCount]
    Active[activeCount] = nil
    activeCount = activeCount - 1
    freeCount = freeCount + 1
    FreeStack[freeCount] = m
end

function HM.Clear()
    for i = activeCount, 1, -1 do ReleaseAt(i) end
end

local function NextStackSlot(ent, now)
    local st = IsValid(ent) and Stack[ent] or StackWorld
    if not st then
        st = { t = 0, n = 0 }
        Stack[ent] = st
    end
    if now - st.t <= cfg.StackWindow then
        st.n = (st.n + 1) % cfg.StackMax
    else
        st.n = 0
    end
    st.t = now
    return st.n
end

local function AmountScale(amount)
    local s = 1 + cfg.AmountK * math_log(math_max(amount, 1) / cfg.AmountRef)
    return math_Clamp(s, cfg.AmountMin, cfg.AmountMax)
end

function HM.Spawn(target, amount, hitType, fallbackPos)
    if not cvEnabled:GetBool() then return end
    if not HM._fontsReady then HM.BuildFonts() end

    amount  = math.Round(tonumber(amount) or 0)
    hitType = hitType or TYPE.NORMAL
    local style = HM.Styles[hitType] or HM.Styles[TYPE.NORMAL]

    if hook.Run("SHIBI.HitMarker.PreSpawn", target, amount, hitType) == false then return end

    local now = CurTime()
    local m = Acquire(now)
    nextOrder = nextOrder + 1
    m.order = nextOrder
    local ent = IsEntity(target) and IsValid(target) and target or nil

    m.ent    = ent
    m.type   = hitType
    m.style  = style
    m.born   = now
    m.seed   = math_Rand(0, 100)
    m.amount = amount
    m.text   = cfg.Comma and string.Comma(amount) or tostring(amount)
    m.baseScale = style.scale * AmountScale(amount)

    if ent then
        m.height = ent:OBBMaxs().z + cfg.HeadOffset
        m.pos:Set(ent:GetPos())
        m.pos.z = m.pos.z + m.height
    elseif isvector(target) then
        m.pos:Set(target)
    elseif isvector(fallbackPos) then
        m.pos:Set(fallbackPos)
    else
        m.pos:Set(EyePos())
    end

    local slot = NextStackSlot(ent, now)
    local side = (slot % 2 == 0) and 1 or -1
    m.offX = RY(side * math_Rand(cfg.JitterX * 0.3, cfg.JitterX))
    m.offY = RY(-slot * cfg.StackStepY + math_Rand(-cfg.JitterY, cfg.JitterY))

    local sp = style.sparks
    m.sparkN = 0
    if sp then
        local n = math_min(sp.count, cfg.MaxSparks)
        for i = 1, n do
            local s = m.sparks[i]
            local a = math_Rand(0, math.pi * 2)
            local v = math_Rand(sp.speedMin, sp.speedMax)
            s.vx   = math_cos(a) * v
            s.vy   = math_sin(a) * v - v * 0.35
            s.life = math_Rand(sp.lifeMin, sp.lifeMax)
            s.len  = math_Rand(sp.lenMin, sp.lenMax)
            s.tint = math_Rand(0, 1)
        end
        m.sparkN = n
    end

    return m
end

local function DrawRing(font, text, x, y, radius, steps, r, g, b, a)
    surface_SetFont(font)
    surface_SetTextColor(r, g, b, a)
    local d = Dirs(steps)
    for i = 1, #d, 2 do
        surface_SetTextPos(x + d[i] * radius, y + d[i + 1] * radius)
        surface_DrawText(text)
    end
end

local function DrawPlain(font, text, x, y, r, g, b, a)
    surface_SetFont(font)
    surface_SetTextColor(r, g, b, a)
    surface_SetTextPos(x, y)
    surface_DrawText(text)
end

local function DrawSparks(m, sp, age, cx, cy, ds)
    draw.NoTexture()
    local g = sp.gravity
    local c1, c2 = sp.color, sp.color2
    for i = 1, m.sparkN do
        local s = m.sparks[i]
        if age < s.life then
            local k  = age / s.life
            local px = cx + RY(s.vx * age) * ds
            local py = cy + RY(s.vy * age + 0.5 * g * age * age) * ds
            local vy = s.vy + g * age
            local t  = s.tint * (1 - k) + k
            surface_SetDrawColor(
                Lerp(t, c1.r, c2.r), Lerp(t, c1.g, c2.g), Lerp(t, c1.b, c2.b),
                255 * (1 - k * k))
            surface_DrawTexturedRectRotated(px, py, RY(s.len * (1 - k)) * ds + 1, RY(sp.thick) * ds,
                -math_deg(math_atan2(vy, s.vx)))
        end
    end
end

local function DrawMarker(m, now, eye)
    local st  = m.style
    local age = now - m.born
    if age >= st.life then return false end

    if cfg.FollowTarget and m.ent and IsValid(m.ent) then
        m.pos:Set(m.ent:GetPos())
        m.pos.z = m.pos.z + m.height
    end

    local scr = m.pos:ToScreen()
    if not scr.visible then return true end

    local tp = math_min(age / st.pop, 1)
    local fadeStart = st.life - st.fade
    local tf = age > fadeStart and (age - fadeStart) / st.fade or 0

    local dist = eye:Distance(m.pos)
    local ds = Lerp(math_Clamp((dist - cfg.NearDist) / (cfg.FarDist - cfg.NearDist), 0, 1), 1, cfg.FarScale)
    local scale = Lerp(EaseOutBack(tp, st.overshoot), st.popFrom, 1)
                * Lerp(EaseInQuad(tf), 1, st.fadeScale)
                * m.baseScale * ds
    local alpha = math_min(age / (st.pop * 0.5), 1) * (1 - EaseInQuad(tf))
    if alpha <= 0.01 then return true end

    local yAnim = -st.hop * (1 - EaseOutBounce(tp)) - st.drift * age - st.rise * EaseInCubic(tf)
    local x = scr.x + m.offX * ds
    local y = scr.y + m.offY * ds + RY(yAnim) * ds

    if st.shake and tp < 1 then
        local amp = RY(st.shake) * (1 - tp)
        x = x + math_sin(age * 95 + m.seed) * amp
        y = y + math_cos(age * 83 + m.seed) * amp
    end

    if not HM._fontsReady then HM.BuildFonts() end
    if not HM._fontsReady then return true end
    local fontSize = PickSize(cfg.FontSize * scale)
    local screenW, screenH = ScrW(), ScrH()
    local outline = st.outline
    local label = st.label
    local labelSize = PickSize(cfg.LabelSize * scale)
    local labelW, labelH = 0, 0
    local labelFont
    local textW, textH

    while true do
        surface_SetFont(GetFont(HM.Fonts.mainBySize, fontSize))
        textW, textH = surface.GetTextSize(m.text)
        local outlinePx = RY((outline and outline.size or 0) + (st.rim and st.rim.size or 0) + 6) * (fontSize / cfg.FontSize)
        if textW + outlinePx * 2 <= screenW - 8 or fontSize <= FONT_MIN then break end
        fontSize = math_max(FONT_MIN, fontSize - FONT_STEP)
    end

    local font = GetFont(HM.Fonts.mainBySize, fontSize)
    local glowFont = GetFont(HM.Fonts.glowBySize, fontSize)
    local outlineScale = fontSize / cfg.FontSize
    local outlinePx = RY((outline and outline.size or 0) * outlineScale)
    local rimPx = st.rim and RY(st.rim.size * outlineScale) or 0

    if label then
        labelSize = PickSize(cfg.LabelSize * scale * (fontSize / PickSize(cfg.FontSize * scale)))
        labelFont = GetFont(HM.Fonts.labelBySize, labelSize)
        surface_SetFont(labelFont)
        labelW, labelH = surface.GetTextSize(label.text)
    end

    local labelGap = label and RY(4) or 0
    local groupW = math_max(textW, labelW)
    local groupH = textH + labelH + labelGap

    local marginX = math_min(screenW * 0.45, groupW * 0.5 + outlinePx + rimPx + 4)
    local marginY = math_min(screenH * 0.45, groupH * 0.5 + outlinePx + rimPx + 4)
    x = math_Clamp(x, marginX, screenW - marginX)
    y = math_Clamp(y, marginY, screenH - marginY)

    local fl = st.flash
    if fl and age < fl.time then
        local k  = age / fl.time
        local sz = textH * fl.size * EaseOutCubic(k) * 0.5
        surface_SetMaterial(flashMat)
        surface_SetDrawColor(fl.color.r, fl.color.g, fl.color.b, 255 * (1 - k) * (1 - k))
        surface_DrawTexturedRect(x - sz * 0.5, y - sz * 0.5, sz, sz)
    end

    if m.sparkN > 0 then DrawSparks(m, st.sparks, age, x, y, ds) end

    local e = EaseOutCubic(tp)
    local groupLeft = x - groupW * 0.5
    local groupTop = y - groupH * 0.5
    local tx = groupLeft + (groupW - textW) * 0.5
    local ty = groupTop + labelH + labelGap
    local a255 = alpha * 255

    local gl = st.glow
    if gl then
        local pulse = 0.75 + 0.25 * math_sin(age * gl.pulse * math.pi * 2)
        for _ = 1, gl.passes do
            DrawPlain(glowFont, m.text, tx, ty, gl.color.r, gl.color.g, gl.color.b, a255 * gl.alpha * pulse)
        end
    end

    if st.rim then
        DrawRing(font, m.text, tx, ty, rimPx + outlinePx, outline.steps, st.rim.color.r, st.rim.color.g, st.rim.color.b, st.rim.color.a * alpha)
    end
    DrawRing(font, m.text, tx, ty, outlinePx, outline.steps, outline.color.r, outline.color.g, outline.color.b, a255)

    local c = st.color
    local w = math_Clamp(1 - age / st.hitFlash, 0, 1)
    DrawPlain(font, m.text, tx, ty,
        Lerp(w, c.r, 255), Lerp(w, c.g, 255), Lerp(w, c.b, 255), a255)

    if label then
        
        local labelOffsetX = (m.type == TYPE.CRIT) and RY(cfg.CriticalLabelOffsetX or 0) or 0
        local lx = groupLeft + (groupW - labelW) * 0.5 + labelOffsetX
        local ly = groupTop
        DrawRing(labelFont, label.text, lx, ly, RY(3), 8, 0, 0, 0, a255)
        DrawPlain(labelFont, label.text, lx, ly, label.color.r, label.color.g, label.color.b, a255)
    end

    return true
end

hook.Add("HUDPaint", "SHIBI::HitMarker::Draw", function()
    if activeCount == 0 then return end

    local now, eye = CurTime(), EyePos()

    for i = activeCount, 1, -1 do
        if now - Active[i].born >= Active[i].style.life then ReleaseAt(i) end
    end
    if activeCount == 0 then return end

    table.sort(Active, function(a, b) return a.order < b.order end)

    for i = 1, activeCount do
        DrawMarker(Active[i], now, eye)
    end
end)

net.Receive(HM.NET, function()
    local n = net.ReadUInt(6)
    for _ = 1, n do
        local ent    = net.ReadEntity()
        local amount = net.ReadUInt(HM.DAMAGE_BITS)
        local t      = net.ReadUInt(HM.TYPE_BITS)
        local pos    = net.ReadVector()
        HM.Spawn(IsValid(ent) and ent or pos, amount, t, pos)
    end
end)

HM.InitPool()
SHIBI.Log("[HitMarkers] Клиент загружен, пул: " .. cfg.PoolSize)

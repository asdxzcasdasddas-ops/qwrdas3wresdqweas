if SERVER then return end

local HoldType = SHIBI.HoldType
local states = setmetatable({}, {__mode = "k"})
local sequenceCache = setmetatable({}, {__mode = "k"})

local LAND_TIME = 0.32
local MOVE_EPSILON = 8
local TURN_SPEED = 10
local VISUAL_YAW_KEY = "SHIBI::HoldType::VisualYaw"
local PROFILE_NET = "SHIBI::HoldType::Profile"

hook.Remove("PrePlayerDraw", "SHIBI::HoldType::ApplyVisualYaw")
hook.Remove("PostPlayerDraw", "SHIBI::HoldType::RestoreVisualYaw")

local function ResolveSequence(ply, profileName, stateName, candidates)
    if not IsValid(ply) or not istable(candidates) then return -1 end

    sequenceCache[ply] = sequenceCache[ply] or {}
    local modelKey = ply:GetModel() .. ":" .. profileName .. ":" .. stateName
        .. ":" .. HoldType.GetRevision(profileName)
    local cached = sequenceCache[ply][modelKey]
    if cached ~= nil then return cached end

    for _, name in ipairs(candidates) do
        if not isstring(name) or name == "" then continue end

        local sequence = ply:LookupSequence(name)
        if sequence and sequence >= 0 then
            sequenceCache[ply][modelKey] = sequence
            return sequence
        end
    end

    sequenceCache[ply][modelKey] = -1
    return -1
end

net.Receive(PROFILE_NET, function()
    local name = net.ReadString()
    local payload = net.ReadString()
    if name == "" or #payload > 60000 then return end

    local encoded = util.JSONToTable(payload)
    if not istable(encoded) or not istable(encoded.states) then return end
    local profile = {
        playback_rate = tonumber(encoded.playback_rate) or 1,
        speed_scale = tonumber(encoded.speed_scale) or 1,
    }
    for state, data in pairs(encoded.states) do
        if istable(data) and istable(data.sequences) then
            local sequences = table.Copy(data.sequences)
            sequences.playback_rate = tonumber(data.playback_rate)
            profile[state] = sequences
        end
    end
    HoldType.ApplyProfile(name, profile, false)
end)

local function GetProfile(ply)
    local weapon = ply:GetActiveWeapon()
    return HoldType.GetForWeapon(weapon)
end

local function ForceLoop(ply, sequence)
    if not IsValid(ply) or sequence < 0 then return end

    local cycle = ply:GetCycle()
    if cycle >= 0.999 or cycle < 0 then
        ply:SetCycle(cycle % 1)
    end
end

local function CanOverride(ply)
    if not IsValid(ply) or not ply:Alive() then return false end
    if ply:InVehicle() or ply:GetMoveType() == MOVETYPE_NOCLIP then return false end
    if ply:WaterLevel() >= 2 then return false end
    return true
end

local function CleanupBaseAnimState(ply)
    local plyTable = ply:GetTable()

    if plyTable.m_bWasNoclipping then
        plyTable.m_bWasNoclipping = nil
        ply:AnimResetGestureSlot(GESTURE_SLOT_CUSTOM)
        ply:SetIK(true)
    end

    local onGround = ply:OnGround()
    if onGround and plyTable.m_bJumping then
        plyTable.m_bJumping = false
        plyTable.m_bFirstJumpFrame = false
    end
    plyTable.m_bWasOnGround = onGround
    plyTable.m_bInSwim = false
end

local function OnOverrideLost(ply)
    local data = states[ply]
    if data then
        data.visualYaw = nil
        data.visualTargetYaw = nil
    end
    HoldType.ResetMovementState(ply)
end

local overriding = setmetatable({}, {__mode = "k"})

local function SelectState(ply, velocity)
    return HoldType.SelectState(ply, velocity)
end

local function GetDirectionTarget(ply, velocity)
    local speed = velocity:Length2D()
    if speed > MOVE_EPSILON and ply:OnGround() then
        return velocity:Angle().y
    end

    return ply:EyeAngles().y
end

local function UpdateDirectionalFacing(ply, velocity)
    if not IsValid(ply) then return end

    local data = states[ply] or {}

    if HoldType.IsBodyTurnBlocked(ply) then
        data.visualYaw = ply:EyeAngles().y
        data.visualTargetYaw = data.visualYaw
        data.dashing = true
        states[ply] = data
        return
    end
    data.dashing = nil
    local currentYaw = data.visualYaw
        or ply:GetNW2Float(VISUAL_YAW_KEY, GetDirectionTarget(ply, velocity))
    local targetYaw = ply:GetNW2Float(VISUAL_YAW_KEY, GetDirectionTarget(ply, velocity))
    local delta = math.AngleDifference(targetYaw, currentYaw)
    local step = math.Clamp(1 - math.exp(-TURN_SPEED * FrameTime()), 0, 1)

    data.visualYaw = currentYaw + delta * step
    data.visualTargetYaw = targetYaw
    states[ply] = data
end

hook.Add("Think", "SHIBI::HoldType::SmoothVisualYaw", function()
    for _, ply in ipairs(player.GetAll()) do

        if not CanOverride(ply) then continue end
        UpdateDirectionalFacing(ply, ply:GetVelocity())
    end
end)

local function ReleaseOverride(ply)
    if overriding[ply] then
        overriding[ply] = nil
        OnOverrideLost(ply)
    end
end

hook.Add("CalcMainActivity", "SHIBI::HoldType::Activity", function(ply, velocity)
    if not CanOverride(ply) then return ReleaseOverride(ply) end

    local profile, profileName = GetProfile(ply)
    if not profile then return ReleaseOverride(ply) end

    local stateName = SelectState(ply, velocity)
    local sequence = ResolveSequence(ply, profileName, stateName, profile[stateName])

    if sequence < 0 then return ReleaseOverride(ply) end

    overriding[ply] = true
    CleanupBaseAnimState(ply)
    if stateName == "idle" or stateName == "crouch_idle" then
        ForceLoop(ply, sequence)
    end
    return -1, sequence
end)

hook.Add("PreRender", "SHIBI::HoldType::ApplyVisualYaw", function()
    for _, ply in ipairs(player.GetAll()) do
        local data = states[ply]
        if not data then continue end

        if data.renderYawApplied then
            ply:SetRenderAngles(data.previousRenderAngles)
            data.renderYawApplied = nil
        end
        if not CanOverride(ply) then continue end
        if data.dashing or HoldType.IsBodyTurnBlocked(ply) then continue end
        if not data or not data.visualYaw then continue end
        data.previousRenderAngles = ply:GetRenderAngles()
        data.renderYawApplied = true
        ply:SetRenderAngles(Angle(0, data.visualYaw, 0))

        ply:SetupBones()
    end
end)

hook.Add("PrePlayerDraw", "SHIBI::HoldType::ReapplyVisualYaw", function(ply)
    if not CanOverride(ply) then return end
    local data = states[ply]
    if not data or not data.visualYaw then return end
    if data.dashing or HoldType.IsBodyTurnBlocked(ply) then return end

    if not data.renderYawApplied then
        data.previousRenderAngles = ply:GetRenderAngles()
        data.renderYawApplied = true
    end
    ply:SetRenderAngles(Angle(0, math.NormalizeAngle(data.visualYaw), 0))
    ply:SetupBones()
end)

hook.Add("PostRender", "SHIBI::HoldType::RestoreVisualYaw", function()
    for ply, data in pairs(states) do
        if not data.renderYawApplied then continue end
        if IsValid(ply) then ply:SetRenderAngles(data.previousRenderAngles) end
        data.previousRenderAngles = nil
        data.renderYawApplied = nil
    end
end)

hook.Add("PlayerSwitchWeapon", "SHIBI::HoldType::WeaponChanged", function(ply)
    states[ply] = nil
end)

hook.Add("EntityRemoved", "SHIBI::HoldType::Cleanup", function(ent)
    states[ent] = nil
    overriding[ent] = nil
    sequenceCache[ent] = nil
end)

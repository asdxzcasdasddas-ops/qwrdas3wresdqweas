if SERVER then return end

SHIBI.HUD = SHIBI.HUD or {}

local hpBackground = Material("materials/shibi_core/hud/background_hp_bar.png", "noclamp smooth")
local hpBar = Material("materials/shibi_core/hud/hp_bar.png", "noclamp smooth")
local manaBackground = Material("materials/shibi_core/hud/background_stamina_bar.png", "noclamp smooth")
local manaBar = Material("materials/shibi_core/hud/stamina_bar.png", "noclamp smooth")

local hpValue, manaValue = 0, 120
local initialized = false
local nameFont

local function SmoothTo(current, target, speed)
    local alpha = 1 - math.exp(-speed * FrameTime())
    return Lerp(math.Clamp(alpha, 0, 1), current, target)
end

local function CharacterName(ply)
    if not IsValid(ply) then return "" end
    local name = ply.GetCharacterName and ply:GetCharacterName() or ""
    if isstring(name) and name ~= "" then return name end
    return string.Trim(ply:GetNWString("SHIBI::Character::Name", ""))
end

local function DrawResourceBar(id, value, maxValue, background, fill, x, y, w, h)
    if not SHIBI.DrawBar or background:IsError() or fill:IsError() then return end
    SHIBI.DrawBar(1, 0, id, math.max(0, value), math.max(1, maxValue), background, x, y, w, h, fill, x, y, w, h, false, 0, 0, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, color_white, color_white, 0, color_white, color_white, nil, 0, false, 1)
end

function SHIBI.HUD.ResetResources()
    initialized = false
    hpValue, manaValue = 0, 120
end

hook.Add("HUDShouldDraw", "SHIBI::HUD::HideDefaultBars", function(name)
    if name == "CHudHealth" or name == "CHudBattery" then return false end
end)

hook.Add("PlayerSpawn", "SHIBI::HUD::ResetResources", function(ply)
    if ply == LocalPlayer() then SHIBI.HUD.ResetResources() end
end)

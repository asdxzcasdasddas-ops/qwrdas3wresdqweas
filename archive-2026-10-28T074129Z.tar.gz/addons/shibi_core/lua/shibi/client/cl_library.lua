if not CLIENT then return end

SHIBI = SHIBI or {}

local ACTION_HOOK = "SHIBI::PostDrawTranslucentRenderables::Action"
local ACTION_NET_START = "SHIBI::Action::Start"
local ACTION_NET_STOP = "SHIBI::Action::Stop"
local ACTION_TIMER = "SHIBI::ActionUI::AutoStop"

local ACTION_SCALE = 0.05
local ACTION_UP_OFFSET = Vector(0, 0, 20)
local ACTION_RIGHT_OFFSET = 15
local ACTION_BAR_WIDTH = 325
local ACTION_BAR_HEIGHT = 20

SHIBI.ActionUI = SHIBI.ActionUI or { active = false, endTime = 0, maxValue = 0, barId = nil }

local function StopActionUI()
    local state = SHIBI.ActionUI
    state.active = false
    state.endTime = 0
    state.maxValue = 0
    timer.Remove(ACTION_TIMER)
end

hook.Add("PostDrawTranslucentRenderables", ACTION_HOOK, function()
    local st = SHIBI.ActionUI
    if not st.active then return end
    local ply = LocalPlayer()
    if not IsValid(ply) then return end
    local remaining = st.endTime - CurTime()
    if remaining <= 0 then
        StopActionUI()
        return
    end
    if not isfunction(SHIBI.DrawBar) then return end
    local pos = ply:GetPos() + ACTION_UP_OFFSET - ply:GetRight() * ACTION_RIGHT_OFFSET
    local ang = EyeAngles()
    ang:RotateAroundAxis(ang:Right(), 90)
    ang:RotateAroundAxis(ang:Up(), 90)
    cam.Start3D2D(pos, ang, ACTION_SCALE)
    SHIBI.DrawBar(3, 0, st.barId, remaining, st.maxValue, nil, 0, 0, ACTION_BAR_HEIGHT, ACTION_BAR_WIDTH, nil, 0, 0, ACTION_BAR_HEIGHT, ACTION_BAR_WIDTH, false, nil, nil, nil, nil, Color(11, 11, 11), color_white, 16, nil, nil, nil, 0.075)
    cam.End3D2D()
end)

net.Receive(ACTION_NET_STOP, function()
    StopActionUI()
end)

net.Receive(ACTION_NET_START, function()
    local duration = math.max(net.ReadInt(32), 0)
    local state = SHIBI.ActionUI
    local ply = LocalPlayer()
    timer.Remove(ACTION_TIMER)
    state.active = duration > 0
    state.maxValue = duration
    state.endTime = CurTime() + duration
    state.barId = "action_" .. (IsValid(ply) and ply:SteamID64() or "local")
    if duration <= 0 then return end
    timer.Create(ACTION_TIMER, duration + 0.1, 1, function()
        StopActionUI()
    end)
end)

SHIBI._radiusData = nil

function SHIBI.ShowRadius(center, radius, duration)
    if not isvector(center) then return false end
    radius = math.max(tonumber(radius) or 100, 0)
    duration = math.max(tonumber(duration) or 5, 0)
    SHIBI._radiusData = { pos = Vector(center.x, center.y, center.z), radius = radius, die = CurTime() + duration }
    return true
end

function SHIBI.HideRadius()
    SHIBI._radiusData = nil
end

hook.Add("PostDrawOpaqueRenderables", "SHIBI::PostDrawOpaqueRenderables::DrawRadius", function()
    local data = SHIBI._radiusData
    if not data then return end
    if CurTime() >= data.die then
        SHIBI._radiusData = nil
        return
    end
    render.SetColorMaterial()
    render.DrawWireframeSphere(data.pos, data.radius, 16, 16, Color(0, 255, 0, 200), true)
end)

function SHIBI.GetEntitiesInRadius(center, radius, filterFunction)
    if not isvector(center) then return {} end
    radius = math.max(tonumber(radius) or 0, 0)
    local entities = ents.FindInSphere(center, radius)
    if not isfunction(filterFunction) then return entities end
    local result = {}
    for _, entity in ipairs(entities) do
        if filterFunction(entity) then
            result[#result + 1] = entity
        end
    end
    return result
end

local BLUR = { start = 0, finish = 0, target = 0, power = 0 }
local blurMaterial = Material("pp/blurscreen")

local function DrawFullScreenBlur(strength)
    if blurMaterial:IsError() then return end
    local amount = math.Clamp(tonumber(strength) or 0, 0, 8)
    if amount <= 0 then return end
    local width, height, passes = ScrW(), ScrH(), 3
    surface.SetMaterial(blurMaterial)
    surface.SetDrawColor(255, 255, 255, 255)
    for pass = 1, passes do
        blurMaterial:SetFloat("$blur", (pass / passes) * amount)
        blurMaterial:Recompute()
        render.UpdateScreenEffectTexture()
        surface.DrawTexturedRect(0, 0, width, height)
    end
end

local function ScreenBlurLocal(power, duration)
    power = math.Clamp(tonumber(power) or 0.5, 0, 1)
    duration = math.max(tonumber(duration) or 0.25, 0)
    local now = CurTime()
    BLUR.start = now
    BLUR.finish = math.max(BLUR.finish or 0, now + duration)
    BLUR.target = math.max(BLUR.target or 0, power)
end

SHIBI.ScreenBlurLocal = ScreenBlurLocal

net.Receive("SHIBI::ScreenBlur", function()
    ScreenBlurLocal(net.ReadFloat(), net.ReadFloat())
end)

hook.Add("RenderScreenspaceEffects", "SHIBI::RenderScreenspaceEffects::ScreenBlur", function()
    if (BLUR.finish or 0) <= 0 then return end
    local now = CurTime()
    local remaining = BLUR.finish - now
    local duration = math.max(BLUR.finish - BLUR.start, 0.0001)
    local fade = 0
    if remaining > 0 then
        fade = math.Clamp(remaining / duration, 0, 1)
    else
        BLUR.target = 0
    end
    local desired = (BLUR.target or 0) * fade
    local lerpAmount = math.Clamp(FrameTime() * 12, 0, 1)
    BLUR.power = Lerp(lerpAmount, BLUR.power or 0, desired)
    if remaining <= 0 and BLUR.power < 0.001 then
        BLUR.start = 0
        BLUR.finish = 0
        BLUR.target = 0
        BLUR.power = 0
        return
    end
    if BLUR.power <= 0.001 then return end
    DrawFullScreenBlur(8 * BLUR.power)
end)

local ghostRings = {}

local function TraceFloorAt(position, hull, ignoredEntities)
    hull = hull or Vector(16, 16, 40)
    ignoredEntities = ignoredEntities or {}
    local function DoTrace(startHeight)
        return util.TraceHull({ start = position + Vector(0, 0, startHeight), endpos = position - Vector(0, 0, 4096), mins = -hull, maxs = hull, mask = MASK_PLAYERSOLID_BRUSHONLY, filter = ignoredEntities })
    end
    local trace = DoTrace(256)
    if trace.StartSolid or trace.AllSolid then
        trace = DoTrace(512)
    end
    return trace
end

local function RemoveGhostRing(owner)
    local list = ghostRings[owner]
    if not list then return end
    for _, ghost in ipairs(list) do
        if IsValid(ghost.model) then
            ghost.model:Remove()
        end
    end
    ghostRings[owner] = nil
end

local function EnsureGhostRing(owner, target, count, radius, life, bump, zMode)
    if not IsValid(owner) or not IsValid(target) then return end
    count = math.Clamp(math.floor(tonumber(count) or 0), 1, 255)
    radius = math.max(tonumber(radius) or 0, 0)
    life = math.max(tonumber(life) or 0.1, 0.05)
    bump = tonumber(bump) or 2
    RemoveGhostRing(owner)
    ghostRings[owner] = {}
    local list = ghostRings[owner]
    local baseYaw = target:EyeAngles().y
    local hull = Vector(16, 16, 40)
    local targetPosition = target:GetPos()
    local floorTrace = TraceFloorAt(targetPosition, hull, { owner, target })
    local anchorZ = (floorTrace.Hit and floorTrace.HitPos.z or targetPosition.z) + bump
    for index = 1, count do
        local degrees = baseYaw + (index - 1) * (360 / count)
        local direction = Angle(0, degrees, 0):Forward()
        direction.z = 0
        local wantedPosition = targetPosition + direction * radius
        local anchor = Vector(wantedPosition.x, wantedPosition.y, anchorZ)
        local model = ClientsideModel(owner:GetModel(), RENDERGROUP_OPAQUE)
        if not IsValid(model) then continue end
        model:SetNoDraw(false)
        model:SetIK(false)
        model:SetParent(nil)
        model:SetSkin(owner:GetSkin() or 0)
        for bodyGroup = 0, model:GetNumBodyGroups() - 1 do
            model:SetBodygroup(bodyGroup, owner:GetBodygroup(bodyGroup) or 0)
        end
        local lookDirection = Vector(targetPosition.x, targetPosition.y, anchor.z) - anchor
        lookDirection.z = 0
        local angles
        if lookDirection:LengthSqr() > 0.0001 then
            angles = lookDirection:Angle()
        else
            angles = Angle(0, degrees + 180, 0)
        end
        model:SetAngles(angles)
        model:InvalidateBoneCache()
        model:SetupBones()
        local minimums = model:OBBMins()
        model:SetPos(Vector(anchor.x, anchor.y, anchor.z - minimums.z))
        list[#list + 1] = { model = model, anchor = anchor, die = CurTime() + life, target = target, owner = owner, bump = bump, hull = hull, zMode = zMode or "pos" }
    end
end

net.Receive("SHIBI::GhostRing::Spawn", function()
    local owner, target, count, radius, life, bump = net.ReadEntity(), net.ReadEntity(), net.ReadUInt(8), net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
    EnsureGhostRing(owner, target, count, radius, life, bump, "pos")
end)

net.Receive("SHIBI::GhostRing::Kill", function()
    RemoveGhostRing(net.ReadEntity())
end)

hook.Add("Think", "SHIBI::Think::GhostRing", function()
    local now = CurTime()
    for owner, list in pairs(ghostRings) do
        if not IsValid(owner) then
            RemoveGhostRing(owner)
            continue
        end
        local ownerModel = owner:GetModel()
        local ownerSequenceName = owner:GetSequenceName(owner:GetSequence()) or ""
        local playbackRate = owner:GetPlaybackRate() or 1
        local cycle = owner:GetCycle() or 0
        for index = #list, 1, -1 do
            local ghost = list[index]
            local model = ghost.model
            if not IsValid(model) or now >= ghost.die then
                if IsValid(model) then model:Remove() end
                table.remove(list, index)
                continue
            end
            if model:GetModel() ~= ownerModel then
                model:SetModel(ownerModel)
            end
            model:SetSkin(owner:GetSkin() or 0)
            for bodyGroup = 0, model:GetNumBodyGroups() - 1 do
                model:SetBodygroup(bodyGroup, owner:GetBodygroup(bodyGroup) or 0)
            end
            if ownerSequenceName ~= "" then
                local sequence = model:LookupSequence(ownerSequenceName)
                if sequence and sequence >= 0 and model:GetSequence() ~= sequence then
                    model:ResetSequence(sequence)
                end
            end
            model:SetPlaybackRate(playbackRate)
            model:SetCycle(cycle)
            for pose = 0, model:GetNumPoseParameters() - 1 do
                local poseName = model:GetPoseParameterName(pose)
                if poseName and poseName ~= "" then
                    model:SetPoseParameter(poseName, owner:GetPoseParameter(poseName))
                end
            end
            local target = ghost.target
            if IsValid(target) then
                if ghost.zMode == "floor" then
                    local trace = TraceFloorAt(target:GetPos(), ghost.hull, { ghost.owner, target })
                    ghost.anchor.z = (trace.Hit and trace.HitPos.z or target:GetPos().z) + ghost.bump
                else
                    ghost.anchor.z = target:GetPos().z + ghost.bump
                end
            end
            model:InvalidateBoneCache()
            model:SetupBones()
            local minimums = model:OBBMins()
            model:SetPos(Vector(ghost.anchor.x, ghost.anchor.y, ghost.anchor.z - minimums.z))
        end
        if #list == 0 then
            ghostRings[owner] = nil
        end
    end
end)

local vignette = { enabled = false, startTime = 0, untilTime = 0, fadeIn = 0.25, fadeOut = 0.45, strength = 1, color = Color(0, 0, 0, 255), current = 0, phase = "idle", outStart = 0, outBase = 0 }

local vignetteTop = Material("vgui/gradient-u")
local vignetteBottom = Material("vgui/gradient-d")
local vignetteLeft = Material("vgui/gradient-l")
local vignetteRight = Material("vgui/gradient-r")

local function Smooth01(value)
    value = math.Clamp(value, 0, 1)
    return value * value * (3 - 2 * value)
end

local function HasVignetteGradients()
    return not vignetteTop:IsError() and not vignetteBottom:IsError() and not vignetteLeft:IsError() and not vignetteRight:IsError()
end

net.Receive("SHIBI.Vignette.Set", function()
    local turnOn, duration, strength, fadeIn, fadeOut, color = net.ReadBool(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadColor(true)
    local now = CurTime()
    if turnOn then
        vignette.enabled = true
        vignette.startTime = now
        vignette.untilTime = now + math.max(0.05, duration)
        vignette.fadeIn = math.max(0, fadeIn)
        vignette.fadeOut = math.max(0, fadeOut)
        vignette.strength = math.Clamp(strength, 0, 1)
        vignette.color = Color(color.r, color.g, color.b, 255)
        vignette.phase = vignette.fadeIn > 0 and "in" or "hold"
        vignette.outStart = 0
        vignette.outBase = 0
        return
    end
    if fadeOut >= 0 then
        vignette.fadeOut = fadeOut
    end
    vignette.enabled = true
    vignette.phase = "out"
    vignette.outStart = now
    vignette.outBase = math.min(vignette.current or 0, vignette.strength or 1)
end)

local function ComputeVignetteTarget(now)
    if not vignette.enabled then return 0 end
    if vignette.phase == "in" then
        local progress = (now - vignette.startTime) / math.max(vignette.fadeIn, 0.0001)
        if progress >= 1 then vignette.phase = "hold" end
        return vignette.strength * Smooth01(progress)
    end
    if vignette.phase == "hold" then
        if now < vignette.untilTime then return vignette.strength end
        vignette.phase = "out"
        vignette.outStart = now
        vignette.outBase = math.min(vignette.current or vignette.strength, vignette.strength)
    end
    if vignette.phase == "out" then
        if vignette.fadeOut <= 0 then
            vignette.enabled = false
            vignette.phase = "idle"
            vignette.current = 0
            return 0
        end
        local progress = (now - vignette.outStart) / vignette.fadeOut
        local target = math.max(0, vignette.outBase * (1 - Smooth01(progress)))
        if progress >= 1 or target <= 0.0005 then
            vignette.enabled = false
            vignette.phase = "idle"
            vignette.current = 0
            return 0
        end
        return target
    end
    return 0
end

local function DrawVignette(amount, color)
    if amount <= 0 then return end
    local width, height = ScrW(), ScrH()
    local padding = math.floor(math.min(width, height) * (0.12 * amount + 0.02))
    local alpha = math.Clamp(220 * amount, 0, 255)
    surface.SetDrawColor(color.r, color.g, color.b, alpha)
    if HasVignetteGradients() then
        surface.SetMaterial(vignetteTop)
        surface.DrawTexturedRect(0, 0, width, padding)
        surface.SetMaterial(vignetteBottom)
        surface.DrawTexturedRect(0, height - padding, width, padding)
        surface.SetMaterial(vignetteLeft)
        surface.DrawTexturedRect(0, 0, padding, height)
        surface.SetMaterial(vignetteRight)
        surface.DrawTexturedRect(width - padding, 0, padding, height)
        return
    end
    surface.DrawRect(0, 0, width, padding)
    surface.DrawRect(0, height - padding, width, padding)
    surface.DrawRect(0, 0, padding, height)
    surface.DrawRect(width - padding, 0, padding, height)
end

hook.Add("HUDPaint", "SHIBI::HUDPaint::Vignette", function()
    if not vignette.enabled then return end
    local target = ComputeVignetteTarget(CurTime())
    local interpolation = math.Clamp(FrameTime() * 10, 0, 1)
    vignette.current = Lerp(interpolation, vignette.current, target)
    DrawVignette(vignette.current, vignette.color)
end)

local clones = {}

local function FindSequenceSafe(entity, name)
    if not IsValid(entity) then return -1 end
    if not isstring(name) or name == "" then return -1 end
    local sequence = entity:LookupSequence(name)
    if sequence and sequence >= 0 then return sequence end
    sequence = entity:LookupSequence(string.lower(name))
    if sequence and sequence >= 0 then return sequence end
    local activity = _G[name]
    if isnumber(activity) then
        sequence = entity:SelectWeightedSequence(activity)
        if sequence and sequence >= 0 then return sequence end
    end
    return -1
end

local function ApproachYaw(fromYaw, toYaw, maximumStep)
    local difference = math.AngleDifference(toYaw, fromYaw)
    if math.abs(difference) <= maximumStep then return toYaw end
    return fromYaw + math.Clamp(difference, -maximumStep, maximumStep)
end

local function FindNearestClientPlayer(position, owner, radius)
    local bestPlayer, bestDistance
    for _, ply in ipairs(player.GetAll()) do
        if not IsValid(ply) or ply == owner or not ply:Alive() then continue end
        local distance = position:DistToSqr(ply:GetPos())
        if distance <= radius * radius and (not bestDistance or distance < bestDistance) then
            bestPlayer = ply
            bestDistance = distance
        end
    end
    return bestPlayer
end

net.Receive("SHIBI::Clone::Spawn", function()
    local position, angles, modelPath, skin, bodyGroupCount = net.ReadVector(), net.ReadAngle(), net.ReadString(), net.ReadUInt(8), net.ReadUInt(8)
    local bodyGroups = {}
    for index = 0, bodyGroupCount - 1 do
        bodyGroups[index] = net.ReadUInt(8)
    end
    local sequenceName, playbackRate, lifetime, scale, owner, lookRadius, lookSpeed = net.ReadString(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadEntity(), net.ReadFloat(), net.ReadFloat()
    if not isstring(modelPath) or modelPath == "" then
        modelPath = "models/player/kleiner.mdl"
    end
    local model = ClientsideModel(modelPath, RENDERGROUP_OPAQUE)
    if not IsValid(model) then return end
    model:SetNoDraw(false)
    model:SetPos(position)
    model:SetAngles(angles)
    model:SetIK(false)
    model:SetSkin(skin)
    for index = 0, model:GetNumBodyGroups() - 1 do
        model:SetBodygroup(index, bodyGroups[index] or 0)
    end
    if isnumber(scale) and scale > 0 and scale ~= 1 then
        model:SetModelScale(scale, 0)
    end
    model:InvalidateBoneCache()
    model:SetupBones()
    local sequence = FindSequenceSafe(model, sequenceName)
    if sequence < 0 then
        sequence = FindSequenceSafe(model, "idle_all_01")
    end
    if sequence < 0 then
        sequence = 0
    end
    playbackRate = playbackRate ~= 0 and playbackRate or 1
    model:SetSequence(sequence)
    model:ResetSequenceInfo()
    model:SetCycle(0)
    model:SetPlaybackRate(playbackRate)
    model._shibiDieAt = CurTime() + math.max(0.05, lifetime)
    model._shibiRate = playbackRate
    model._shibiSequenceDuration = model:SequenceDuration(sequence)
    if model._shibiSequenceDuration <= 0 then
        model._shibiSequenceDuration = 1
    end
    model._shibiOwner = IsValid(owner) and owner or nil
    model._shibiLookRadius = math.max(lookRadius, 0)
    model._shibiLookSpeed = math.max(lookSpeed, 0)
    clones[#clones + 1] = model
end)

hook.Add("Think", "SHIBI::Think::Clone", function()
    local now, frameTime = CurTime(), FrameTime()
    for index = #clones, 1, -1 do
        local model = clones[index]
        if not IsValid(model) or now >= (model._shibiDieAt or 0) then
            if IsValid(model) then model:Remove() end
            table.remove(clones, index)
            continue
        end
        local rate = model._shibiRate or 1
        model:SetPlaybackRate(rate)
        model:FrameAdvance(frameTime)
        model:InvalidateBoneCache()
        model:SetupBones()
        local radius = model._shibiLookRadius or 0
        if radius <= 0 then continue end
        local target = FindNearestClientPlayer(model:GetPos(), model._shibiOwner, radius)
        if not IsValid(target) then continue end
        local direction = target:WorldSpaceCenter() - model:GetPos()
        direction.z = 0
        if direction:LengthSqr() <= 0.0001 then continue end
        local wantedYaw = direction:Angle().y
        local currentAngles = model:GetAngles()
        currentAngles.y = ApproachYaw(currentAngles.y, wantedYaw, (model._shibiLookSpeed or 540) * frameTime)
        model:SetAngles(currentAngles)
    end
end)

local verticalTornadoes = {}

net.Receive("SHIBI::VertTornado::Start", function()
    local trap, height, heightMinus, amplitude, period, proportionalGain, derivativeGain, maximumVelocity, started, phase = net.ReadEntity(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadFloat()
    if not IsValid(trap) then return end
    verticalTornadoes[trap] = { height = height, heightMinus = heightMinus, amplitude = amplitude, period = math.max(0.2, period), proportionalGain = proportionalGain, derivativeGain = derivativeGain, maximumVelocity = maximumVelocity, started = started, phase = phase, lastDesiredZ = nil, smoothVelocityZ = 0 }
end)

net.Receive("SHIBI::VertTornado::Stop", function()
    verticalTornadoes[net.ReadEntity()] = nil
end)

local function ExponentialLerp(alpha, from, to)
    return from + (to - from) * math.Clamp(alpha, 0, 1)
end

hook.Add("SetupMove", "SHIBI::SetupMove::VerticalTornadoSmooth", function(ply, moveData)
    if ply ~= LocalPlayer() then return end
    if next(verticalTornadoes) == nil then return end
    local nearestTrap, nearestDistance, playerPosition = nil, nil, ply:GetPos()
    for trap in pairs(verticalTornadoes) do
        if not IsValid(trap) then
            verticalTornadoes[trap] = nil
            continue
        end
        local distance = trap:GetPos():DistToSqr(playerPosition)
        if not nearestDistance or distance < nearestDistance then
            nearestTrap, nearestDistance = trap, distance
        end
    end
    if not IsValid(nearestTrap) then return end
    local data = verticalTornadoes[nearestTrap]
    if not data then return end
    local trapPosition = nearestTrap:GetPos() - Vector(0, 0, data.heightMinus or 0)
    local height = math.max(data.height or 256, 1)
    local minimumZ, maximumZ, centerZ = trapPosition.z, trapPosition.z + height, trapPosition.z + height * 0.5
    local amplitude = tonumber(data.amplitude) or height * 0.45
    local period = math.max(data.period or 1.2, 0.2)
    local omega = (2 * math.pi) / period
    local maximumVelocity = math.max(math.abs(data.maximumVelocity or 500), 1)
    local proportionalGain = tonumber(data.proportionalGain) or 0
    local derivativeGain = tonumber(data.derivativeGain) or 0
    if proportionalGain <= 0 then proportionalGain = omega * omega end
    if derivativeGain <= 0 then derivativeGain = 2 * omega end
    local now, currentZ, velocity = CurTime(), ply:GetPos().z, moveData:GetVelocity()
    local currentVelocityZ = velocity.z
    local desiredRawZ = math.Clamp(centerZ + amplitude * math.sin(omega * (now - (data.started or 0)) + (data.phase or 0)), minimumZ, maximumZ)
    local frameTime = math.max(FrameTime(), 0.0001)
    local positionAlpha = 1 - math.exp(-12 * frameTime)
    if data.lastDesiredZ == nil then
        data.lastDesiredZ = desiredRawZ
    else
        data.lastDesiredZ = ExponentialLerp(positionAlpha, data.lastDesiredZ, desiredRawZ)
    end
    local difference = data.lastDesiredZ - currentZ
    local commandedVelocity = math.Clamp(proportionalGain * difference - derivativeGain * currentVelocityZ, -maximumVelocity, maximumVelocity)
    if currentZ < minimumZ then
        commandedVelocity = math.max(commandedVelocity, math.min(220, (minimumZ - currentZ) * 4))
    elseif currentZ > maximumZ then
        commandedVelocity = math.min(commandedVelocity, -math.min(220, (currentZ - maximumZ) * 4))
    end
    local velocityAlpha = 1 - math.exp(-18 * frameTime)
    data.smoothVelocityZ = ExponentialLerp(velocityAlpha, data.smoothVelocityZ or 0, commandedVelocity)
    velocity.z = data.smoothVelocityZ
    moveData:SetVelocity(velocity)
end)

hook.Add("NotifyShouldTransmit", "SHIBI::NotifyShouldTransmit::VerticalTornado", function(entity, shouldTransmit)
    if not shouldTransmit then verticalTornadoes[entity] = nil end
end)

hook.Add("EntityRemoved", "SHIBI::EntityRemoved::VerticalTornado", function(entity)
    verticalTornadoes[entity] = nil
end)

local SCREEN_SHAKE = { effects = {}, maximumAmplitude = 10 }

local function ClampNumber(value, minimum, maximum)
    return math.max(minimum, math.min(maximum, value))
end

local function EaseOutQuadratic(value)
    return 1 - (1 - value) * (1 - value)
end

local function ScreenShakeLocal(amplitude, frequency, duration, options)
    amplitude = ClampNumber(tonumber(amplitude) or 0.5, 0, SCREEN_SHAKE.maximumAmplitude)
    frequency = ClampNumber(tonumber(frequency) or 6, 0.01, 50)
    duration = math.max(tonumber(duration) or 0.35, 0)
    if duration <= 0 or amplitude <= 0 then return end
    options = istable(options) and options or {}
    local axes = istable(options.axes) and options.axes or (istable(options.ax) and options.ax or { x = 1, y = 1, z = 1 })
    local roll = ClampNumber(tonumber(options.roll) or 0.25, 0, 1)
    local positionMultiplier = ClampNumber(tonumber(options.pos) or 0.15, 0, 1)
    local seed = tonumber(options.seed) or math.random() * 1000
    local now = RealTime()
    SCREEN_SHAKE.effects[#SCREEN_SHAKE.effects + 1] = { finish = now + duration, duration = duration, amplitude = amplitude, frequency = frequency, axes = { x = tonumber(axes.x) or 1, y = tonumber(axes.y) or 1, z = tonumber(axes.z) or 1 }, roll = roll, positionMultiplier = positionMultiplier, seed = seed }
end

SHIBI.ScreenShakeLocal = ScreenShakeLocal

net.Receive("SHIBI::ScreenShake", function()
    local amplitude, frequency, duration, hasOptions = net.ReadFloat(), net.ReadFloat(), net.ReadFloat(), net.ReadBool()
    local options
    if hasOptions then
        options = { roll = net.ReadFloat(), pos = net.ReadFloat(), axes = { x = net.ReadFloat(), y = net.ReadFloat(), z = net.ReadFloat() }, seed = net.ReadFloat() }
    end
    ScreenShakeLocal(amplitude, frequency, duration, options)
end)

function SHIBI.ScreenShakeSample(baseAngles)
    if #SCREEN_SHAKE.effects == 0 then return vector_origin, angle_zero end
    local now, angleOffset, positionOffset, changed = RealTime(), Angle(0, 0, 0), Vector(0, 0, 0), false
    for index = #SCREEN_SHAKE.effects, 1, -1 do
        local effect = SCREEN_SHAKE.effects[index]
        if not effect or now >= effect.finish or effect.duration <= 0 then
            table.remove(SCREEN_SHAKE.effects, index)
            continue
        end
        changed = true
        local remainingFactor = ClampNumber((effect.finish - now) / effect.duration, 0, 1)
        local fade = EaseOutQuadratic(remainingFactor)
        local amplitude = effect.amplitude * fade
        local angularFrequency = 2 * math.pi * effect.frequency
        local seed = effect.seed
        local waveOne = math.sin(angularFrequency * (now + seed * 0.37))
        local waveTwo = math.cos(angularFrequency * (now + seed * 0.73))
        local waveThree = math.sin(angularFrequency * (now + seed * 1.13))
        angleOffset.p = angleOffset.p + waveOne * amplitude * effect.axes.x
        angleOffset.y = angleOffset.y + waveTwo * amplitude * effect.axes.y
        angleOffset.r = angleOffset.r + ((waveOne - waveTwo) * 0.5 * amplitude * effect.roll * effect.axes.z)
        local positionAmplitude = amplitude * effect.positionMultiplier
        if positionAmplitude > 0 and baseAngles then
            local forward, right, up = baseAngles:Forward(), baseAngles:Right(), baseAngles:Up()
            positionOffset = positionOffset + forward * (waveTwo * positionAmplitude * 0.6) + right * (waveThree * positionAmplitude * 0.6) + up * (waveOne * positionAmplitude * 0.4)
        end
    end
    if not changed then return vector_origin, angle_zero end
    return positionOffset, angleOffset
end

hook.Add("CalcView", "SHIBI::CalcView::ScreenShake", function(ply, position, angles, fov, zNear, zFar)
    if SHIBI.Cutscene and SHIBI.Cutscene.IsActive and SHIBI.Cutscene.IsActive() then return end
    if SHIBI.ThirdPerson and SHIBI.ThirdPerson.IsActive and SHIBI.ThirdPerson.IsActive() then return end
    if istable(SHIBI.Camera) and isfunction(SHIBI.Camera.Mode) and SHIBI.Camera:Mode() then return end
    if not SHIBI.ScreenShakeSample then return end

    local positionOffset, angleOffset = SHIBI.ScreenShakeSample(angles)
    if not positionOffset or not angleOffset then return end

    local hasPosition = not positionOffset:IsZero()
    local hasAngles = math.abs(angleOffset.p) > 0.0001
        or math.abs(angleOffset.y) > 0.0001
        or math.abs(angleOffset.r) > 0.0001

    if not hasPosition and not hasAngles then return end

    return {
        origin = position + positionOffset,
        angles = Angle(
            angles.p + angleOffset.p,
            angles.y + angleOffset.y,
            angles.r + angleOffset.r
        ),
        fov = fov,
        znear = zNear,
        zfar = zFar,
        drawviewer = false
    }
end)

hook.Add("PlayerSpawn", "SHIBI::PlayerSpawn::ScreenShake", function(ply)
    if ply ~= LocalPlayer() then return end
    table.Empty(SCREEN_SHAKE.effects)
end)

hook.Add("ShutDown", "SHIBI::ShutDown::ClientLibrary", function()
    StopActionUI()
    SHIBI._radiusData = nil
    table.Empty(SCREEN_SHAKE.effects)
    table.Empty(verticalTornadoes)
    for owner in pairs(ghostRings) do
        RemoveGhostRing(owner)
    end
    for _, model in ipairs(clones) do
        if IsValid(model) then model:Remove() end
    end
    table.Empty(clones)
end)

net.Receive("SHIBI::Particle::Aura", function()
    local ply, particle, time, attach = net.ReadEntity(), net.ReadString(), net.ReadFloat(), net.ReadUInt(8) or 4
    if not IsValid(ply) then return end
    local part = CreateParticleSystem(ply, particle, attach, 0)
    if time and time > 0 then
        timer.Simple(time, function()
            if IsValid(part) then
                part:StopEmission(false, false, false)
            end
        end)
    end
end)

net.Receive("SHIBI::Particle::Beam", function()
    local ply, target, particle, time = net.ReadEntity(), net.ReadEntity(), net.ReadString(), net.ReadFloat()
    if not IsValid(ply) or not IsValid(target) then return end
    local part = CreateParticleSystem(ply, particle, PATTACH_ABSORIGIN_FOLLOW, 0, Vector(0, 0, ply:OBBCenter().z))
    if not IsValid(part) then return end
    part:SetControlPoint(1, target:GetPos() + Vector(0, 0, target:OBBCenter().z))
    if time and time > 0 then
        timer.Simple(time, function()
            if IsValid(part) then
                part:StopEmission(false, false, false)
            end
        end)
    end
end)

net.Receive("SHIBI::Particle::Effect", function()
    local ply, particle, pos, ang, time = net.ReadEntity(), net.ReadString(), net.ReadVector(), net.ReadAngle(), net.ReadFloat()
    if not IsValid(ply) then return end
    ParticleEffect(particle, pos, ang, ply)
    if time and time > 0 then
        timer.Simple(time, function()
            if IsValid(ply) then
                ply:StopParticles()
            end
        end)
    end
end)

net.Receive("SHIBI::Particle::Stop", function()
    local ply = net.ReadEntity()
    if IsValid(ply) then
        ply:StopParticles()
    end
end)

function SHIBI.ParticleCreateAura(ply, particle, time, attach)
    if not IsValid(ply) then return end
    attach = attach or 4
    time = time or 1
    local part = CreateParticleSystem(ply, particle, attach, 0)
    if time and time > 0 then
        timer.Simple(time, function()
            if IsValid(part) then
                part:StopEmission(false, false, false)
            end
        end)
    end
    return part
end

function SHIBI.ParticleStop(ply)
    if IsValid(ply) then
        ply:StopParticles()
    end
end

print("[SHIBI] cl_library.lua загружен")

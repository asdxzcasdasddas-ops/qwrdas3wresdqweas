SHIBI.Refresh = SHIBI.Refresh or {}

local restoreQueue = {}
local cleanupQueue = {}
SHIBI.Refresh.State = SHIBI.Refresh.State or {}

function SHIBI.Refresh.Register(name, restoreFn)
    if not isfunction(restoreFn) then return end
    restoreQueue[name] = restoreFn
end

function SHIBI.Refresh.Cleanup(name, cleanupFn)
    if not isfunction(cleanupFn) then return end
    cleanupQueue[name] = cleanupFn
end

function SHIBI.Refresh.Run()
    for name, fn in pairs(cleanupQueue) do
        local success, err = pcall(fn)
        if not success then
            SHIBI.Log("[Refresh] Error cleaning '" .. name .. "': " .. tostring(err))
        end
    end

    for name, fn in pairs(restoreQueue) do
        local success, err = pcall(fn)
        if not success then
            SHIBI.Log("[Refresh] Error restoring '" .. name .. "': " .. tostring(err))
        else
            SHIBI.Log("[Refresh] Restored: " .. name)
        end
    end
end

if SHIBI.Refresh then
    timer.Simple(0, SHIBI.Refresh.Run)
end

hook.Add("PostCleanupMap", "SHIBI::PostCleanupMap::Refresh", function()
    timer.Simple(0.5, function()
        if SHIBI and SHIBI.Refresh then
            SHIBI.Refresh.Run()
        end
    end)
end)

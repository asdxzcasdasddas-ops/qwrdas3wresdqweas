if SERVER then return end

SHIBI.Stamina = SHIBI.Stamina or {}
SHIBI.Stamina.Max = 120

function SHIBI.Stamina.Get(ply)
    ply = IsValid(ply) and ply or LocalPlayer()
    if not IsValid(ply) then return 0 end
    return math.Clamp(ply:GetNWFloat("SHIBI::Mana", SHIBI.Stamina.Max), 0, SHIBI.Stamina.Max)
end

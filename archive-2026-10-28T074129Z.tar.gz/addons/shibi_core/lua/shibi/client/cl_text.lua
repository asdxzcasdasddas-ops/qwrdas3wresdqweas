local Responsive = SHIBI.Responsive
local ResponsiveX = SHIBI.ResponsiveX
local ResponsiveY = SHIBI.ResponsiveY

function SHIBI.GetTextSize(text, font)
    if font then surface.SetFont(font) end
    return surface.GetTextSize(text)
end

function SHIBI.FirstToUpper(str)
    return (str:gsub("^%l", string.upper))
end

function SHIBI.DrawSimpleText(text, font, x, y, col, xAlign, yAlign)
    local w, h = SHIBI.GetTextSize(text, font)
    if xAlign == 1 then
        x = x - w / 2
    elseif xAlign == 2 then
        x = x - w
    end

    if yAlign == 1 then
        y = y - h / 2
    elseif yAlign == 4 then
        y = y - h
    end

    surface.SetTextPos(math.ceil(x), math.ceil(y))
    surface.SetTextColor(col.r, col.g, col.b, col.a)
    surface.DrawText(text)
    return w, h
end

function SHIBI.DrawShadowText(text, font, x, y, col, ax, ay, d)
    draw.DrawText(text, font, x + d, y + d, Color(0, 0, 0, col.a), ax, ay)
    draw.DrawText(text, font, x, y, col, ax, ay)
end

function SHIBI.TextWrap(text, font, spacing, maxWidth)
    local words = string.Explode(" ", text)
    local lines = {}
    local currentLine = ""

    for _, word in ipairs(words) do
        local testLine = currentLine .. (currentLine ~= "" and " " or "") .. word
        local testLineWidth = SHIBI.GetTextSize(testLine, font)

        if testLineWidth <= maxWidth then
            currentLine = testLine
        else
            table.insert(lines, currentLine)
            currentLine = word
        end
    end

    if currentLine ~= "" then
        table.insert(lines, currentLine)
    end

    local widestLineWidth = 0
    local totalHeight = #lines * spacing

    for _, line in ipairs(lines) do
        local lineWidth = SHIBI.GetTextSize(line, font)
        if lineWidth > widestLineWidth then
            widestLineWidth = lineWidth
        end
    end

    return lines, widestLineWidth, totalHeight
end

function SHIBI.WrapText(text, width, font)
    local textWidth = SHIBI.GetTextSize(text, font)
    if textWidth <= width then return text end
    local totalWidth = 0
    local spaceWidth = SHIBI.GetTextSize(' ')
    text = text:gsub("(%s?[%S]+)", function(word)
        local char = string.sub(word, 1, 1)
        if char == "\n" or char == "\t" then totalWidth = 0 end
        local wordlen = SHIBI.GetTextSize(word)
        totalWidth = totalWidth + wordlen
        if wordlen >= width then
            local splitWord, splitPoint = charWrap(word, width - (totalWidth - wordlen), width)
            totalWidth = splitPoint
            return splitWord
        elseif totalWidth < width then
            return word
        end

        if char == ' ' then
            totalWidth = wordlen - spaceWidth
            return '\n' .. string.sub(word, 2)
        end

        totalWidth = wordlen
        return '\n' .. word
    end)
    return text
end

function SHIBI.EllipsesText(text, width, font)
    local textWidth = SHIBI.GetTextSize(text, font)
    if textWidth <= width then return text end
    local infiniteLoopPrevention = 0
    repeat
        text = string.Left(text, #text - 1)
        textWidth = SHIBI.GetTextSize(text .. "...")
        infiniteLoopPrevention = infiniteLoopPrevention + 1
    until textWidth <= width or infiniteLoopPrevention > 10000

    text = text .. "..."
    return text
end

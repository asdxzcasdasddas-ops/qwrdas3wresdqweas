if not CLIENT then return end

SHIBI = SHIBI or {}
SHIBI.ThirdPerson = SHIBI.ThirdPerson or {}

local TP = SHIBI.ThirdPerson
TP.Config = TP.Config or {}

local defaults = {
    ToggleKey = KEY_F2,
    Distance = 150,
    Shoulder = 14,
    Height = 7,
    PitchMin = -75,
    PitchMax = 75,
    FollowSmooth = 0,
    RotationSmooth = 0,
    TransitionSmooth = 0.05,
    WheelStep = 12,
    MinDistance = 80,
    MaxDistance = 260,
    CollisionRadius = 5,
    CollisionPadding = 8,
    HeadBob = false,
    HeadBobAmount = 1.2,
    HeadBobFrequency = 8,
}

for key, value in pairs(defaults) do
    if TP.Config[key] == nil then TP.Config[key] = value end
end

local cfg = TP.Config
cfg.RotationSmooth = 0
local enabled = false
local lastToggle = 0
local view = {}
local state = {
    blend = 0,
    initialized = false,
    origin = Vector(),
    focus = Vector(),
    angles = Angle(),
    distanceScale = 1,
    bob = 0,
    ignore = {},
}

local hullMins = Vector(-cfg.CollisionRadius, -cfg.CollisionRadius, -cfg.CollisionRadius)
local hullMaxs = Vector(cfg.CollisionRadius, cfg.CollisionRadius, cfg.CollisionRadius)
local worldUp = Vector(0, 0, 1)

function TP.IsActive()
    return enabled or state.blend > 0.001
end

local cvDistance = CreateClientConVar("shibi_camera_tp_distance", tostring(cfg.Distance), true, false, "Third-person camera distance", 80, 260)
local cvShoulder = CreateClientConVar("shibi_camera_tp_shoulder", tostring(cfg.Shoulder), true, false, "Third-person shoulder offset", -40, 40)
local cvHeight = CreateClientConVar("shibi_camera_tp_height", tostring(cfg.Height), true, false, "Third-person camera height", -20, 40)
local cvHeadBob = CreateClientConVar("shibi_camera_tp_headbob", cfg.HeadBob and "1" or "0", true, false, "Enable subtle third-person head bob", 0, 1)

local function SmoothFactor(dt, smoothTime)
    return math.Clamp(1 - math.exp(-dt / math.max(smoothTime, 0.001)), 0, 1)
end

local function BuildIgnoreList(ply)
    local list = state.ignore
    table.Empty(list)
    list[#list + 1] = ply

    local weapon = ply:GetActiveWeapon()
    if IsValid(weapon) then list[#list + 1] = weapon end

    if IsValid(ply.SHIBI_HeadEnt) then
        list[#list + 1] = ply.SHIBI_HeadEnt
    end

    for _, child in ipairs(ply:GetChildren()) do
        if IsValid(child) then list[#list + 1] = child end
    end

    return list
end

local function ToggleCamera(ply)
    if not IsValid(ply) or not ply:Alive() or ply:InVehicle() then return end
    local now = RealTime()
    if now - lastToggle < 0.25 then return end
    lastToggle = now
    enabled = not enabled
end

hook.Add("PlayerBindPress", "SHIBI::ThirdPerson::F2Bind", function(ply, bind, pressed)
    if ply ~= LocalPlayer() or not pressed then return end
    bind = string.lower(bind)
    if string.find(bind, "gm_showteam", 1, true) or string.find(bind, "showscores", 1, true) then
        ToggleCamera(ply)
        return true
    end
end)

hook.Add("PlayerButtonDown", "SHIBI::ThirdPerson::F2Key", function(ply, button)
    if ply == LocalPlayer() and button == cfg.ToggleKey then ToggleCamera(ply) end
end)

hook.Add("SHIBI.FKeyPressed", "SHIBI::ThirdPerson::F2Hook", function(keyNo)
    if keyNo == 2 then ToggleCamera(LocalPlayer()) end
end)

hook.Add("PlayerBindPress", "SHIBI::ThirdPerson::Zoom", function(ply, bind, pressed)
    if ply ~= LocalPlayer() or not pressed or not enabled then return end
    bind = string.lower(bind)

    local direction
    if string.find(bind, "invnext", 1, true) or string.find(bind, "mwheelup", 1, true) then
        direction = 1
    elseif string.find(bind, "invprev", 1, true) or string.find(bind, "mwheeldown", 1, true) then
        direction = -1
    end

    if not direction then return end
    local distance = math.Clamp(cvDistance:GetFloat() - direction * cfg.WheelStep, cfg.MinDistance, cfg.MaxDistance)
    RunConsoleCommand("shibi_camera_tp_distance", tostring(distance))
    return true
end)

hook.Add("CalcView", "SHIBI::ThirdPerson::Camera", function(ply, origin, angles, fov, znear, zfar)
    if ply ~= LocalPlayer() then return end
    if SHIBI.Cutscene and SHIBI.Cutscene.IsActive and SHIBI.Cutscene.IsActive() then return end

    if not IsValid(ply) or not ply:Alive() or ply:InVehicle() then
        enabled = false
        state.blend = 0
        state.initialized = false
        return
    end

    local dt = math.min(FrameTime(), 0.05)
    local targetBlend = enabled and 1 or 0
    local step = dt / math.max(cfg.TransitionSmooth, 0.001)
    state.blend = math.Approach(state.blend, targetBlend, step)

    if not state.initialized then
        state.origin:Set(origin)
        state.focus:Set(origin)
        state.angles:Set(angles)
        state.initialized = true
    end

    if state.blend < 0.001 and not enabled then
        state.blend = 0
        state.initialized = false
        return
    end

    local aimAngles = ply:EyeAngles()
    local targetAngles = Angle(
        math.Clamp(aimAngles.p, cfg.PitchMin, cfg.PitchMax),
        aimAngles.y,
        0
    )
    state.angles:Set(targetAngles)
    local cameraAngles = targetAngles
    local targetFocus = ply:EyePos()
    if cfg.FollowSmooth <= 0 then
        state.focus:Set(targetFocus)
    else
        state.focus = LerpVector(SmoothFactor(dt, cfg.FollowSmooth), state.focus, targetFocus)
    end

    local distance = cvDistance:GetFloat()
    local shoulder = cvShoulder:GetFloat()
    local desired = state.focus - cameraAngles:Forward() * distance
        + cameraAngles:Right() * shoulder
        + worldUp * cvHeight:GetFloat()

    local tr = util.TraceHull({
        start = state.focus,
        endpos = desired,
        mins = hullMins,
        maxs = hullMaxs,
        filter = BuildIgnoreList(ply),
        mask = MASK_SOLID,
    })

    local desiredScale = 1
    if tr.Hit then
        local fullDistance = state.focus:Distance(desired)
        if fullDistance > 0 then
            desiredScale = math.Clamp(state.focus:Distance(tr.HitPos) / fullDistance, 0, 1)
        end
    end

    state.distanceScale = desiredScale
    local targetOrigin = state.focus + (desired - state.focus) * state.distanceScale

    local bobTarget = 0
    if cvHeadBob:GetBool() and ply:OnGround() then
        local speed = ply:GetVelocity():Length2D()
        local weight = math.Clamp(speed / 220, 0, 1)
        bobTarget = math.sin(CurTime() * cfg.HeadBobFrequency) * cfg.HeadBobAmount * weight
    end
    state.bob = bobTarget
    targetOrigin = targetOrigin + worldUp * state.bob

    if cfg.FollowSmooth <= 0 then
        state.origin:Set(targetOrigin)
    else
        state.origin = LerpVector(SmoothFactor(dt, cfg.FollowSmooth), state.origin, targetOrigin)
    end

    local blend = state.blend
    if enabled and blend > 0.92 then blend = 1 end
    if not enabled and blend < 0.08 then blend = 0 end
    view.origin = LerpVector(blend, origin, state.origin)
    view.angles = blend >= 1 and cameraAngles or LerpAngle(blend, angles, cameraAngles)

    if SHIBI.ScreenShakeSample then
        local positionOffset, angleOffset = SHIBI.ScreenShakeSample(view.angles)
        if positionOffset then view.origin = view.origin + positionOffset end
        if angleOffset then
            view.angles = Angle(
                view.angles.p + angleOffset.p,
                view.angles.y + angleOffset.y,
                view.angles.r + angleOffset.r
            )
        end
    end

    view.fov = fov
    view.znear = znear
    view.zfar = zfar
    view.drawviewer = state.blend > 0.015

    return view
end)

hook.Add("PlayerSpawn", "SHIBI::ThirdPerson::Reset", function(ply)
    if ply ~= LocalPlayer() then return end
    enabled = false
    state.blend = 0
    state.initialized = false
    state.distanceScale = 1
end)

hook.Add("ShutDown", "SHIBI::ThirdPerson::Cleanup", function()
    enabled = false
    state.initialized = false
end)

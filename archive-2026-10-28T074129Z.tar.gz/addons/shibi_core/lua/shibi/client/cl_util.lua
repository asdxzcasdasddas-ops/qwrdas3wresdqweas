local scrw, scrh = ScrW(), ScrH()
local baseW, baseH = 1920, 1080
local scaleX, scaleY = scrw / baseW, scrh / baseH

local function UpdateResponsive(newW, newH)
    scrw, scrh = newW or ScrW(), newH or ScrH()
    if baseW <= 0 then baseW = 1920 end
    if baseH <= 0 then baseH = 1080 end
    scaleX, scaleY = scrw / baseW, scrh / baseH
end

hook.Add("OnScreenSizeChanged", "SHIBI::ResponsiveUpdate", function(newW, newH) UpdateResponsive(newW, newH) end)

UpdateResponsive()

function SHIBI.ResponsiveX(x)
    return math.Round(x * scaleX)
end

function SHIBI.ResponsiveY(y)
    return math.Round(y * scaleY)
end

function SHIBI.Responsive(x, y)
    return SHIBI.ResponsiveX(x), SHIBI.ResponsiveY(y)
end

function SHIBI.UnresponsiveX(x)
    return math.Round(x / scaleX)
end

function SHIBI.UnresponsiveY(y)
    return math.Round(y / scaleY)
end

function SHIBI.Unresponsive(x, y)
    return SHIBI.UnresponsiveX(x), SHIBI.UnresponsiveY(y)
end

SHIBI.MaterialCache = SHIBI.MaterialCache or {}
function SHIBI.GetMaterial(path, flags)
    flags = flags or "noclamp smooth"

    local key = path .. "|" .. flags
    if not SHIBI.MaterialCache[key] then
        SHIBI.MaterialCache[key] = Material("materials/" .. path .. ".png", flags)
    end
    return SHIBI.MaterialCache[key]
end

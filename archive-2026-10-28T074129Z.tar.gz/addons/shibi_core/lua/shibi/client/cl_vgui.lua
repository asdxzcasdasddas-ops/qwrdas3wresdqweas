local ResponsiveX = SHIBI.ResponsiveX
local ResponsiveY = SHIBI.ResponsiveY
local Responsive = SHIBI.Responsive
local getMaterial = SHIBI.GetMaterial
local Language = SHIBI.Languages
function SHIBI.Frame(s, width, height, close_bool, close_sizeX, close_sizeY, close_btn, flag, space, rounded)
    if flag then timer.Simple(0.2, function() SHIBI.FrameIsOpen = true end) end
    space = space or 20
    rounded = rounded or 6

    s:SetSize(Responsive(width, height))
    s:Center()
    s:MakePopup()
    s:SetTitle("")
    s:ShowCloseButton(false)
    s:SetDraggable(false)

    if close_bool then
        s.cls = vgui.Create("DButton", s)
        s.cls:SetSize(Responsive(close_sizeX, close_sizeY))
        s.cls:SetPos(Responsive(width - close_sizeX - space, space))
        s.cls:SetText("")

        s.cls.Paint = function(self, w, h)
            local alpha = self:IsHovered() and 20 or 10
            SHIBI.DrawRoundedBox(ResponsiveY(rounded), 0, 0, w, h, Color(238, 255, 0, alpha))
            paint.startVGUI()
                SHIBI.DrawOutlinedBox(ResponsiveY(rounded), 0, 0, w, h, Color(238, 255, 0), 1)
            paint.endVGUI()
            SHIBI.DrawSimpleText("X", "SHIBI.Gilroy.18", w * .5, h * .5, color_white, 1, 1)
        end

        s.cls.DoClick = function()
            if SHIBI.IsSpinning then return end
            SHIBI.PlaySound("mugen/ui/notifications/undo.mp3")
            s:Remove()
            if flag then timer.Simple(0.2, function() SHIBI.FrameIsOpen = false end) end
        end
    end

    if close_btn then
        s.Think = function(self)
            if input.IsKeyDown(KEY_ESCAPE) and IsValid(self) and not SHIBI.IsSpinning then
                SHIBI.PlaySound("mugen/ui/notifications/undo.mp3")
                self:Remove()
                if flag then timer.Simple(0.2, function() SHIBI.FrameIsOpen = false end) end
            end
        end
    end

    if flag then
        s.OnRemove = function(self)
            timer.Simple(0.2, function() SHIBI.FrameIsOpen = false end)
        end
    end
end

function SHIBI.Vbar(s, color, color_grip)
    local vbar = s:GetVBar()
    vbar:SetWide(ResponsiveX(5))
    vbar:SetHideButtons(true)

    vbar.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, color and color or Color(32, 32, 32))
    end

    vbar.btnGrip.Paint = function(self, w, h)
        draw.RoundedBox(0, 0, 0, w, h, color_grip and color_grip or Color(200, 200, 200))
    end
end

function SHIBI.Button(s, color_hover, color, background, text, font, icon, icon_size)
    s:SetText("")
    s.hoverStatus = 0
    s.Paint = function(self, w, h)
        if not background then
            surface.SetDrawColor(self:IsHovered() and color_hover or color)
            surface.DrawRect(0, 0, w, h)
        else
            surface.SetDrawColor(self:IsHovered() and color_hover or color)
            surface.SetMaterial(background)
            surface.DrawTexturedRect(0, 0, w, h)
        end

        if text then
            SHIBI.DrawSimpleText(text, font, w * .5 + (icon and icon_size * .5 - 2 or 0), h * .5 - 1, color_white, 1, 1)
        end

        if icon then
            surface.SetDrawColor(color_white)
            surface.SetMaterial(icon)
            local indent = (h - icon_size) * 0.5
            surface.DrawTexturedRect(indent, indent, icon_size, icon_size)
        end
    end
end

function SHIBI.DrawRoundedBox(radius, x, y, w, h, color)
    draw.RoundedBox(radius, x, y, w, h, color)
end

function SHIBI.DrawOutlinedBox(radius, x, y, w, h, colors, outline)
    radius = radius or 8
    colors = colors or color_white
    outline = outline or 2
    paint.outlines.drawOutline(radius, x + ResponsiveX(1), y + ResponsiveY(1), w - ResponsiveX(2), h - ResponsiveY(2), colors, nil, outline)
end

function SHIBI.DrawRect(color, x, y, w, h)
    surface.SetDrawColor(color)
    surface.DrawRect(ResponsiveX(x), ResponsiveY(y), ResponsiveX(w), ResponsiveY(h))
end

function SHIBI.DrawTexturedRect(color, material, x, y, w, h)
    surface.SetDrawColor(color)
    surface.SetMaterial(material)
    surface.DrawTexturedRect(ResponsiveX(x), ResponsiveY(y), ResponsiveX(w), ResponsiveY(h))
end

function SHIBI.DrawBar(direction, forClock, id, value, maxValue, mat_background, backgroundX, backgroundY, backgroundW, backgroundH, mat_bat, barX, barY, barW, barH, bool, textX, textY, xAlign, yAlign, color, color_bar, cornerRadius, color_text, color_text_bar, font, lerp, outlined, outliner)
    local ply = LocalPlayer()
    local uniqueKey = ply:SteamID() .. "_" .. tostring(id)
    forClock = forClock or 0
    cornerRadius = cornerRadius or 0
    color = color or color_white
    color_bar = color_bar or color_white
    color_text = color_text or color_white
    color_text_bar = color_text_bar or color_white
    font = font or "SHIBI.Benzin.Bold.15"
    lerp = lerp or 0.005
    outlined = outlined or false
    outliner = outliner or 1

    if mat_background then
        SHIBI.DrawTexturedRect(color_white, mat_background, backgroundX, backgroundY, backgroundW, backgroundH)
    else
        SHIBI.DrawRoundedBox(ResponsiveY(cornerRadius), ResponsiveX(backgroundX), ResponsiveY(backgroundY), ResponsiveX(backgroundW), ResponsiveY(backgroundH), color)
    end

    local progress = math.Clamp(value / maxValue, 0, 1)
    local drawX = ResponsiveX(barX)
    local drawY = ResponsiveY(barY)
    local drawW = ResponsiveX(barW)
    local drawH = ResponsiveY(barH)
    local barWidth = drawW * progress
    local barHeight = drawH * progress

    local function DrawBarBox(x, y, w, h, col)
        if outlined then
            paint.startVGUI()
                SHIBI.DrawOutlinedBox(ResponsiveY(cornerRadius), x, y, w, h, col, outliner)
            paint.endVGUI()
        else
            SHIBI.DrawRoundedBox(ResponsiveY(cornerRadius), x, y, w, h, col)
        end
    end

    if direction >= 1 and direction <= 4 then
        if mat_bat then
            surface.SetDrawColor(color_white)
            surface.SetMaterial(mat_bat)
            if direction == 1 then
                surface.DrawTexturedRectUV(drawX, drawY, barWidth, drawH, 0, 0, progress, 1)
            elseif direction == 2 then
                surface.DrawTexturedRectUV(drawX + (drawW - barWidth), drawY, barWidth, drawH, 1 - progress, 0, 1, 1)
            elseif direction == 3 then
                surface.DrawTexturedRectUV(drawX, drawY, drawW, barHeight, 0, 0, 1, progress)
            elseif direction == 4 then
                surface.DrawTexturedRectUV(drawX, drawY + (drawH - barHeight), drawW, barHeight, 0, 1 - progress, 1, 1)
            end
        else
            if direction == 1 then
                DrawBarBox(drawX, drawY, barWidth, drawH, color_bar)
            elseif direction == 2 then
                DrawBarBox(drawX + (drawW - barWidth), drawY, barWidth, drawH, color_bar)
            elseif direction == 3 then
                DrawBarBox(drawX, drawY, drawW, barHeight, color_bar)
            elseif direction == 4 then
                DrawBarBox(drawX, drawY + (drawH - barHeight), drawW, barHeight, color_bar)
            end
        end
    elseif direction == 5 or direction == 6 then
        local segments = 100
        local angleStart = -90
        local angleEnd = angleStart + (direction == 5 and 360 * progress or 360 * (1 - progress))

        render.SetStencilEnable(true)
        render.ClearStencil()
        render.SetStencilWriteMask(1)
        render.SetStencilTestMask(1)
        render.SetStencilReferenceValue(1)
        render.SetStencilPassOperation(STENCILOPERATION_REPLACE)
        render.SetStencilFailOperation(STENCILOPERATION_KEEP)
        render.SetStencilZFailOperation(STENCILOPERATION_KEEP)
        render.SetStencilCompareFunction(STENCILCOMPARISONFUNCTION_ALWAYS)

        render.OverrideColorWriteEnable(true, false, false)

        cam.Start2D()
            draw.NoTexture()
            surface.SetDrawColor(255, 255, 255, 255)
            local centerX = drawX + drawW / 2
            local centerY = drawY + drawH / 2
            surface.DrawPoly(SHIBI.GenerateCircle(centerX, centerY, ResponsiveX(barW / 2 + forClock), segments, angleStart, angleEnd))
        cam.End2D()

        render.OverrideColorWriteEnable(false)
        render.SetStencilCompareFunction(direction == 6 and STENCILCOMPARISONFUNCTION_NOTEQUAL or STENCILCOMPARISONFUNCTION_EQUAL)

        if mat_bat then
            surface.SetDrawColor(color_white)
            surface.SetMaterial(mat_bat)
            surface.DrawTexturedRect(drawX, drawY, drawW, drawH)
        else
            DrawBarBox(drawX, drawY, drawW, drawH, color_bar)
        end

        render.SetStencilEnable(false)
    end

    if bool then SHIBI.DrawTextWithOverflow(value .. "/" .. maxValue, font, ResponsiveX(textX), ResponsiveY(textY), ResponsiveX(barW - 5), color_text, color_text_bar, xAlign, yAlign) end
end

function SHIBI.GenerateCircle(cx, cy, radius, segments, startAngle, endAngle)
    local verts = {}
    table.insert(verts, {x = cx, y = cy})
    for i = 0, segments do
        local angle = math.rad(startAngle + (endAngle - startAngle) * (i / segments))
        table.insert(verts, {x = cx + math.cos(angle) * radius, y = cy + math.sin(angle) * radius})
    end
    return verts
end

function SHIBI.PlaySound(path, volume, callback)
    if not path or path == "" then
        path = "mugen/ui/notifications/generic.mp3"
    end

    volume = volume or 1

    sound.PlayFile("sound/" .. path, "mono", function(station, err)
        if IsValid(station) then
            station:SetVolume(volume)
            station:Play()

            if callback then
                callback(station)
            end
        end
    end)
end

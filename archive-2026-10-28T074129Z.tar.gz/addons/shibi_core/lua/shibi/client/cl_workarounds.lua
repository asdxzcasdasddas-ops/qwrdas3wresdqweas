if not GM then
    GM = GAMEMODE or {}
end

local cfg = SHIBI.Config

local ScrW = ScrW
local ScrH = ScrH
local Angle = Angle
local Vector = Vector
local IsValid = IsValid
local LocalPlayer = LocalPlayer
local RunConsoleCommand = RunConsoleCommand

local hook_Call = hook.Call
local hook_Add = hook.Add
local timer_Create = timer.Create
local string_lower = string.lower
local string_match = string.match
local string_find = string.find
local gui_SetMousePos = gui.SetMousePos
local gui_MousePos = gui.MousePos
local gui_EnableScreenClicker = gui.EnableScreenClicker

local scrW, scrH = ScrW(), ScrH()

local keyBinds = {
    ["gm_showhelp"] = "ShowHelp",
    ["gm_showteam"] = "ShowTeam",
    ["gm_showspare1"] = "ShowSpare1",
    ["gm_showspare2"] = "ShowSpare2"
}

function GM:PlayerBindPress(ply, bind, pressed)
    self.Sandbox.PlayerBindPress(self, ply, bind, pressed)
    bind = string_lower(bind)
    local bnd = string_match(bind, "gm_[a-z]+[12]?")
    if bnd and keyBinds[bnd] then hook_Call(keyBinds[bnd], GM or GAMEMODE) end
    if not cfg.VoiceWhenDead and not ply:Alive() and string_find(bind, "voicerecord") then return true end
end

local function handleFKeyPress(ply, keyNo)
    if ply ~= nil and ply ~= LocalPlayer() then return end
    if keyNo < 0 or keyNo > 4 then return end
    hook_Call("SHIBI.FKeyPressed", GM or GAMEMODE, keyNo)
end

function GM:ShowHelp(ply)
    handleFKeyPress(ply, 1)
end

function GM:ShowTeam(ply)
    handleFKeyPress(ply, 2)
end

function GM:ShowSpare1(ply)
    handleFKeyPress(ply, 3)
end

function GM:ShowSpare2(ply)
    handleFKeyPress(ply, 4)
end

local mouseX, mouseY
local cursorUnlocked = false
hook_Add("SHIBI.FKeyPressed", "SHIBI.UnlockCursorBind", function(keyNo)
    if keyNo ~= 3 then return end
    cursorUnlocked = not cursorUnlocked
    if cursorUnlocked then
        if not (mouseX and mouseY) then
            gui_SetMousePos(scrW * .5, scrH * .5)
        else
            gui_SetMousePos(mouseX, mouseY)
        end
    else
        mouseX, mouseY = gui_MousePos()
    end

    gui_EnableScreenClicker(cursorUnlocked)
end)

if cfg.EnableDecalCleaner then
    timer_Create("SHIBI.DecalCleaner", 2 * 60, 0, function() RunConsoleCommand("r_cleardecals") end)
end

if cfg.FirstPersonDeathView then
    local view = {
        origin = Vector(0, 0, 0),
        angles = Angle(0, 0, 0),
        fov = 90,
        znear = 1
    }

    hook_Add("CalcView", "SHIBI.FirstPersonDeathView", function(ply, origin, angles, fov)
        if ply:Health() > 0 then return end
        local ragdoll = ply:GetRagdollEntity()
        if not IsValid(ragdoll) then return end
        local head = ragdoll:LookupAttachment("eyes")
        head = ragdoll:GetAttachment(head)
        if not head or not head.Pos then return end
        if not ragdoll.BonesRattled then
            ragdoll.BonesRattled = true
            ragdoll:InvalidateBoneCache()
            ragdoll:SetupBones()
            local matrix
            for bone = 0, ragdoll:GetBoneCount() or 1 do
                if ragdoll:GetBoneName(bone):lower():find("head") then
                    matrix = ragdoll:GetBoneMatrix(bone)
                    break
                end
            end

            if IsValid(matrix) then matrix:SetScale(vector_origin) end
        end

        view.origin = head.Pos + head.Ang:Up() * 8
        view.angles = head.Ang
        return view
    end)
end

SHIBI.Anim = SHIBI.Anim or {}

SHIBI.Anim.Slot   = GESTURE_SLOT_VCD or 6
SHIBI.Anim.Weight = 1

function SHIBI.Anim.Resolve(entry, defaultSpeed)
    defaultSpeed = tonumber(defaultSpeed) or 1
    if isstring(entry) then
        if entry == "" then return nil end
        return entry, math.Clamp(defaultSpeed, 0.05, 4), nil
    end
    if not istable(entry) or not isstring(entry.seq) or entry.seq == "" then return nil end

    local speed = tonumber(entry.speed) or defaultSpeed
    if speed ~= speed or speed == math.huge or speed == -math.huge then speed = 1 end

    local duration = tonumber(entry.duration)
    if not duration or duration ~= duration or duration <= 0 or duration == math.huge then
        duration = nil
    end

    return entry.seq, math.Clamp(speed, 0.05, 4), duration
end

local meta = FindMetaTable("Player")
function meta:SetAnim(seq, speed, loop, targetDuration)
    if SERVER then
        return SHIBI.Anim.Play(self, seq, speed, loop, targetDuration)
    end
    return false
end

function meta:ResetAnim(expectedGeneration)
    if SERVER then
        return SHIBI.Anim.Stop(self, expectedGeneration)
    end
    return false
end

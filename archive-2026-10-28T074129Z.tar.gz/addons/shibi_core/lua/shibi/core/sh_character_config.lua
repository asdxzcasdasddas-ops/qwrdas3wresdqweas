SHIBI.Character = SHIBI.Character or {}

SHIBI.Character.Config = {
    Male = {
        Body = "models/maha/shinsei/shinigami_academy.mdl",
        Head = "models/maha/shinsei/head_homme_6.mdl",
        PreviewAnim = "baizai4_0_battle_idle_base",
    },
    Female = {
        Body = "models/maha/shinsei/shinigami_academy_female.mdl",
        Head = "models/shinsei/arach/head_femme2.mdl",
        PreviewAnim = "nilu2_0_battle_idle_base",
    },
}

SHIBI.Character.HeadModels = {
    Male = {
        "models/maha/shinsei/head_homme_9.mdl",
        "models/maha/shinsei/head_homme_7.mdl",
        "models/maha/shinsei/head_homme_6.mdl",
        "models/maha/shinsei/head_homme_5.mdl",
        "models/maha/shinsei/head_homme_4.mdl",
        "models/maha/shinsei/head_homme_3.mdl",
    },
    Female = {
        "models/shinsei/arach/head_femme2.mdl",
        "models/shinsei/arach/head_femme15.mdl",
        "models/shinsei/arach/head_femme14.mdl",
        "models/shinsei/arach/head_femme13.mdl",
        "models/shinsei/arach/head_femme9.mdl",
        "models/shinsei/arach/head_femme1.mdl",
        "models/shinsei/arach/head_femme12.mdl",
        "models/shinsei/arach/head_femme7.mdl",
    },
}

SHIBI.Character.HeadNames = {
    Male = {"Лицо 1", "Лицо 2", "Лицо 3", "Лицо 4", "Лицо 5", "Лицо 6"},
    Female = {"Лицо 1", "Лицо 2", "Лицо 3", "Лицо 4", "Лицо 5", "Лицо 6", "Лицо 7", "Лицо 8"},
}

SHIBI.Character.PreviewAnimations = {
    {name = "Спокойная стойка", sequences = {"baizai4_0_battle_idle_base", "nilu2_0_battle_idle_base", "idle_all_01"}},
    {name = "Боевая стойка", sequences = {"idle_all_02", "idle_all_01"}},
    {name = "Разминка", sequences = {"gesture_item_throw", "idle_all_01"}},
    {name = "Танец", sequences = {"taunt_dance", "idle_all_01"}},
}

SHIBI.Character.Clothes = {
    Male = {
        { name = "Шинигами", model = "models/maha/shinsei/shinigami_academy.mdl", faction = "shinigami" },
        { name = "Арранкар", model = "models/minih/shinsei/tenue_arrancar.mdl", faction = "espada" },
    },
    Female = {
        { name = "Шинигами", model = "models/maha/shinsei/shinigami_academy_female.mdl", faction = "shinigami" },
        { name = "Арранкар", model = "models/minih/shinsei/parnkgjas_femme.mdl", faction = "espada" },
    },
}

SHIBI.Character.HairNames = {
    Male = {
        "Вульф - Кат", "Шторы", "Зализанная", "Удлиненный френч кроп",
        "Распиздяй", "Распиздяй 2", "Навес", "Луковое кольцо",
        "Классика", "Зализанные шторы", "Японский Мафиози", "Моггер",
        "Киска", "Тяжелый Гурман", "Ольга Бузова", "Мамбет",
        "Тяжелый Люкс", "Тяжелый Люкс 2", "Тяжелый Люкс растрепанный",
        "Зубы Забор", "Белоснежка", "Черноснежка", "Златовласка",
        "Дрейк", "Дрейк 2", "Танцуй Пантера", "Жесткий пацык", "Жесткий пацык 2",
    },
    Female = {
        "Горшок", "Альтушка", "Лужайка", "Лимонное Каре",
        "Сучка", "Сучка 2", "Вертихвостка", "Домашний вайб",
        "Каре ягненка", "Гейша", "Медиум", "Рапунцель",
        "Растрепыш", "Прическа на бок", "Барби герл", "Растрепыш 2",
        "Чечевичка", "Жанулька", "Трубочка", "",
        "Киркоров", "Француженка", "Сузуя Джузо",
    },
}

SHIBI.Character.EyeNames = {
    Male = {
        "Голубые", "Белые", "Карие", "Бирюзовые", "Синие", "Серые",
        "Черные", "Янтарные", "Пурпурные", "Зеленые", "Фиолетовые",
        "Желтые", "Красные", "Эндер",
    },
    Female = {
        "Синий", "Черный", "Белые", "Бирюзовые", "Тёмно-Синий", "Серые",
        "Карие", "Янтарные", "Оранжевые", "Красные", "Пурпурные",
        "Фиолетовые", "Зеленые",
    },
}

SHIBI.Character.Gender = {
    MALE = "male",
    FEMALE = "female",
}

function SHIBI.Character.GetParts(gender)
    gender = string.lower(gender or "male")
    if gender == "female" then return SHIBI.Character.Config.Female end
    return SHIBI.Character.Config.Male
end

function SHIBI.Character.GetHeadModel(gender, index)
    local key = string.lower(gender or "male") == "female" and "Female" or "Male"
    local models = SHIBI.Character.HeadModels[key]
    index = math.Clamp(math.floor(tonumber(index) or 1), 1, #models)
    return models[index], index
end

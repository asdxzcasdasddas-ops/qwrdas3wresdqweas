local Lerp = Lerp
local Color = Color
local tonumber = tonumber

local math_Clamp = math.Clamp
local math_min = math.min
local math_max = math.max
local math_pi = math.pi
local string_format = string.format
local string_upper = string.upper
local string_Split = string.Split
local string_sub = string.sub
local string_Replace = string.Replace
local string_len = string.len

SHIBI.Colors = {}
SHIBI.Colors.Background = Color(33, 33, 33, 253)
SHIBI.Colors.Header = Color(82, 87, 93, 90)
SHIBI.Colors.PrimaryText = Color(255, 255, 255, 255)
SHIBI.Colors.SecondaryText = Color(189, 189, 189, 255)
SHIBI.Colors.Primary = Color(25, 118, 210)
SHIBI.Colors.Positive = Color(66, 134, 50)
SHIBI.Colors.Negative = Color(211, 47, 47)

function SHIBI.OffsetColor(col, amount)
    return Color(math_Clamp(col.r + amount, 0, 255), math_Clamp(col.g + amount, 0, 255), math_Clamp(col.b + amount, 0, 255))
end

function SHIBI.LerpColor(t, from, to)
    local newCol = Color(0, 0, 0)
    newCol.r = Lerp(t, from.r, to.r)
    newCol.g = Lerp(t, from.g, to.g)
    newCol.b = Lerp(t, from.b, to.b)
    newCol.a = Lerp(t, from.a, to.a)
    return newCol
end

function SHIBI.CopyColor(col)
    return Color(col.r, col.g, col.b, col.a)
end

function SHIBI.Hue2RGB(p, q, t)
    if t < 0 then t = t + 1 end
    if t > 1 then t = t - 1 end
    if t < 1 / 6 then return p + (q - p) * 6 * t end
    if t < 1 / 2 then return q end
    if t < 2 / 3 then return p + (q - p) * (2 / 3 - t) * 6 end
    return p
end

function SHIBI.HSLToColor(h, s, l, a)
    local r, g, b
    local t = h / (2 * math_pi)
    if s == 0 then
        r, g, b = l, l, l
    else
        local q
        if l < 0.5 then
            q = l * (1 + s)
        else
            q = l + s - l * s
        end

        local p = 2 * l - q
        r = SHIBI.Hue2RGB(p, q, t + 1 / 3)
        g = SHIBI.Hue2RGB(p, q, t)
        b = SHIBI.Hue2RGB(p, q, t - 1 / 3)
    end
    return Color(r * 255, g * 255, b * 255, (a or 1) * 255)
end

function SHIBI.ColorToHSL(col)
    local r = col.r / 255
    local g = col.g / 255
    local b = col.b / 255
    local max, min = math_max(r, g, b), math_min(r, g, b)
    b = max + min
    local h = b / 2
    if max == min then return 0, 0, h end
    local s, l = h, h
    local d = max - min
    s = l > .5 and d / (2 - b) or d / b
    if max == r then
        h = (g - b) / d + (g < b and 6 or 0)
    elseif max == g then
        h = (b - r) / d + 2
    elseif max == b then
        h = (r - g) / d + 4
    end
    return h * .16667, s, l
end

function SHIBI.DecToHex(d, zeros)
    return string_format("%0" .. (zeros or 2) .. "x", d)
end

function SHIBI.RGBToHex(color)
    return "#" .. SHIBI.DecToHex(math_max(math_min(color.r, 255), 0)) .. SHIBI.DecToHex(math_max(math_min(color.g, 255), 0)) .. SHIBI.DecToHex(math_max(math_min(color.b, 255), 0))
end

function SHIBI.HexToRGB(hex)
    hex = hex:gsub("#", "")
    if #hex == 3 then
        local r = hex:sub(1, 1)
        local g = hex:sub(2, 2)
        local b = hex:sub(3, 3)
        return Color(tonumber("0x" .. r .. r), tonumber("0x" .. g .. g), tonumber("0x" .. b .. b))
    end
    return Color(tonumber("0x" .. hex:sub(1, 2)), tonumber("0x" .. hex:sub(3, 4)), tonumber("0x" .. hex:sub(5, 6)))
end

function SHIBI.InverseLerp(pos, p1, p2)
    local range = 0
    range = p2 - p1
    if range == 0 then return 1 end
    return (pos - p1) / range
end

local hexvals = {
    ["0"] = 0,
    ["1"] = 1,
    ["2"] = 2,
    ["3"] = 3,
    ["4"] = 4,
    ["5"] = 5,
    ["6"] = 6,
    ["7"] = 7,
    ["8"] = 8,
    ["9"] = 9,
    ["A"] = 10,
    ["B"] = 11,
    ["C"] = 12,
    ["D"] = 13,
    ["E"] = 14,
    ["F"] = 15,
}

function SHIBI.Hex(hex)
    hex = string_upper(hex)
    hex = string_Split(hex, "")
    local num = 0
    for i = 1, #hex do
        local h = hex[i]
        local v = hexvals[h]
        v = v * (16 ^ (#hex - i))
        num = num + v
    end
    return num
end

function SHIBI.HexColor(hex, alpha)
    if string_sub(hex, 1, 1) ~= "#" then return color_white end
    hex = string_Replace(hex, "#", "")
    local ct = {}
    local len = string_len(hex)
    if len ~= 3 and len ~= 6 then return color_white end
    for i = 1, 3 do
        local l2 = len / 3
        local m = 1
        ct[i] = SHIBI.Hex(string_sub(hex, l2 * i - m, l2 * i))
    end
    return Color(ct[1], ct[2], ct[3], alpha or 255)
end

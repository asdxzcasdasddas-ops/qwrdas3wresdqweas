SHIBI.Config = SHIBI.Config or {}
SHIBI.Config.Developers = SHIBI.Config.Developers or {}

-- список своих. остальным тут делать нечего
SHIBI.Config.Developers = {
    ["STEAM_0:1:573918740"] = true,
}

SHIBI.Config.Language = SHIBI.Config.Language or "ru"
SHIBI.Config.LogPrefixCol = SHIBI.Config.LogPrefixCol or Color(52, 168, 235)
SHIBI.Config.LogMessageCol = SHIBI.Config.LogMessageCol or Color(255, 255, 255)
SHIBI.Config.LogWarningCol = SHIBI.Config.LogWarningCol or Color(242, 141, 24)
SHIBI.Config.LogErrorCol = SHIBI.Config.LogErrorCol or Color(230, 60, 60)
SHIBI.Config.FlashlightOn = SHIBI.Config.FlashlightOn or false
SHIBI.Config.VoiceWhenDead = SHIBI.Config.VoiceWhenDead or false
if SHIBI.Config.EnableDecalCleaner == nil then SHIBI.Config.EnableDecalCleaner = true end
if SHIBI.Config.FirstPersonDeathView == nil then SHIBI.Config.FirstPersonDeathView = true end
SHIBI.Config.ChatMessageMaxLength = SHIBI.Config.ChatMessageMaxLength or 512

local meta = FindMetaTable("Player")
function meta:IsDeveloper()
    if not IsValid(self) then return false end
    return SHIBI.Config.Developers[self:SteamID()] == true
end

SHIBI.Cutscene = SHIBI.Cutscene or {}
local C = SHIBI.Cutscene

C.NET    = "SHIBI::Cutscene"
C.Radius = 400
C.Scenes = C.Scenes or {}

function C.Define(id, data)
    assert(isstring(id) and id ~= "" and istable(data), "[Cutscene] bad id")
    assert(tonumber(data.duration) and data.duration > 0, "[Cutscene] " .. id .. ": нет duration")
    assert(istable(data.keys) and #data.keys >= 2, "[Cutscene] " .. id .. ": нужно минимум два кадра")

    table.sort(data.keys, function(a, b) return a.t < b.t end)
    data.impulses = data.impulses or {}
    data.flashes  = data.flashes or {}
    data.rumbles  = data.rumbles or {}
    C.Scenes[id] = data
    return data
end

local function Smooth(x)
    x = math.Clamp(x, 0, 1)
    return x * x * (3 - 2 * x)
end

local function CatmullRom(p0, p1, p2, p3, t)
    local t2, t3 = t * t, t * t * t
    return 0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t2 + (-p0 + 3 * p1 - 3 * p2 + p3) * t3)
end

function C.Sample(def, p)
    local keys = def.keys
    local n = #keys
    p = math.Clamp(p, 0, 1)

    local i = 1
    while i < n - 1 and p > keys[i + 1].t do
        i = i + 1
    end

    local a, b = keys[i], keys[i + 1]
    local span = math.max(b.t - a.t, 0.0001)
    local f = math.Clamp((p - a.t) / span, 0, 1)

    local pos, look, fov
    if b.hard then
        local e = Smooth(f)
        pos  = LerpVector(e, a.pos, b.pos)
        look = LerpVector(e, a.look, b.look)
        if a.fov and b.fov then fov = Lerp(e, a.fov, b.fov) end
    else
        local k0 = keys[math.max(i - 1, 1)]
        local k3 = keys[math.min(i + 2, n)]
        pos  = CatmullRom(k0.pos, a.pos, b.pos, k3.pos, f)
        look = CatmullRom(k0.look, a.look, b.look, k3.look, f)
        if a.fov and b.fov then
            fov = CatmullRom(k0.fov or a.fov, a.fov, b.fov, k3.fov or b.fov, f)
        end
    end

    return pos, look, fov
end

SHIBI.Dash = SHIBI.Dash or {}
SHIBI.Dash.Config = SHIBI.Dash.Config or {}

SHIBI.Dash.Config.TestWeaponClass = "weapon_shibi_holdtype_test"

SHIBI.Dash.Config.DashWeaponClasses = {
    ["weapon_shibi_holdtype_test"] = true,
    ["weapon_shibi_katana"]        = true,
    ["weapon_shibi_tichki"] = true,
}

SHIBI.Dash.Config.DirectionCodes = {
    [0] = {forward = 1, side = 0, animation = "forward"},
    [1] = {forward = -1, side = 0, animation = "backward"},
    [2] = {forward = 0, side = -1, animation = "left"},
    [3] = {forward = 0, side = 1, animation = "right"},
    [4] = {forward = 1, side = -1, animation = "left"},
    [5] = {forward = 1, side = 1, animation = "right"},
    [6] = {forward = -1, side = -1, animation = "left"},
    [7] = {forward = -1, side = 1, animation = "right"},
}

SHIBI.Dash.Config.InputCodes = {
    ["1:0"] = 0,
    ["-1:0"] = 1,
    ["0:-1"] = 2,
    ["0:1"] = 3,
    ["1:-1"] = 4,
    ["1:1"] = 5,
    ["-1:-1"] = 6,
    ["-1:1"] = 7,
}

SHIBI.Dash.Config.TestWeapon = {
    Enabled = true,
    Animations = {
        forward     = {seq = "m_hand_dashstep_front", speed = 2.5, lock = 0.38},
        backward    = {seq = "m_dashstep_behind",     speed = 1.0, lock = 0.4},
        left        = {seq = "m_dashstep_left",       speed = 1.25, lock = 0.4},
        right       = {seq = "m_dashstep_right",      speed = 1.25, lock = 0.4},
        double_jump = {seq = "evo_move8_double_saut_f", speed = 1},
    },

    Movement = {
        Duration = 0.38,
        AverageSpeed = 530,

        Curve = "ue5",
        AttackFraction = 0.12,
        ExitSpeed = 260,
        CompensateFriction = true,
        Smoothness = 2,
        GroundCooldown = 0.90,
        AirCooldown = 0.65,
        OneAirDash = true,
        MaxPeakSpeed = 1100,
    },

    Air = {
        MaxRise = 40,
        MaxFall = 250,
        GravityScale = 0.25,
    },

    Ground = {
        SnapToGround = true,
        SnapDistance = 18,
    },

    Animation = {
        DashSpeed = 1.0,
        DoubleJumpSpeed = 1.0,
        OneShot = true,

        TurnLockExtra = 0.15,
        TurnLockMin = 0.7,
        TurnLockMax = 2.0,
    },

    DoubleJump = {
        Enabled = true,
        Velocity = 450,
        Cooldown = 0.25,
        StaminaCost = 25,
    },

    Stamina = {
        DashCost = 18,
    },

    Security = {
        RequestGuard = 0.12,
    },
}

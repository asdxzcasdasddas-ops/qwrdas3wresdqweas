SHIBI.FontFiles = SHIBI.FontFiles or {}
function SHIBI.RegisterFontFile(id, path, family)
    
    if not (isstring(id) and isstring(path) and isstring(family)) then
        error("[SHIBI Fonts] RegisterFontFile expects string id, path and family", 2)
    end
    SHIBI.FontFiles[id] = { path = path, family = family }
end

function SHIBI.GetFontFamily(id, fallback)
    local entry = SHIBI.FontFiles[id]
    return entry and entry.family or fallback or "Tahoma"
end

SHIBI.RegisterFontFile("bleach", "resource/fonts/bleach.ttf", "Bleach")

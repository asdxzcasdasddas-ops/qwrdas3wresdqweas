SHIBI.HoldType = SHIBI.HoldType or {}

local HoldType = SHIBI.HoldType
HoldType.Registry = HoldType.Registry or {}
HoldType.Revisions = HoldType.Revisions or {}
HoldType.Default = "default"

local REQUIRED_STATES = {
    "idle",
    "walk",
    "run",
    "sprint",
    "jump",
    "land",
    "crouch_idle",
    "crouch_walk",
}
local movementStates = setmetatable({}, {__mode = "k"})
local MOVE_EPSILON = 8
local LAND_TIME = 0.32

local function NormalizeSequences(sequences)
    local normalized = {}

    for _, state in ipairs(REQUIRED_STATES) do
        local value = sequences[state]

        if isstring(value) then
            normalized[state] = {value}
        elseif istable(value) then
            local names = {}
            for _, name in ipairs(value) do
                if isstring(name) and name ~= "" then
                    names[#names + 1] = name
                end
            end
            names.playback_rate = tonumber(value.playback_rate)
            normalized[state] = names
        end
    end

    normalized.playback_rate = tonumber(sequences.playback_rate) or 1
    normalized.speed_scale = tonumber(sequences.speed_scale) or 1
    return normalized
end

local function ApplyProfile(name, sequences, sync)
    if not isstring(name) or name == "" or not istable(sequences) then return false end

    name = string.lower(string.Trim(name))
    local profile = NormalizeSequences(sequences)
    HoldType.Registry[name] = profile
    if name == HoldType.Default then
        HoldType.Unarmed = profile
    end
    HoldType.Revisions[name] = (HoldType.Revisions[name] or 0) + 1
    hook.Run("SHIBI::HoldTypeProfileUpdated", name, HoldType.Revisions[name])

    if SERVER and sync ~= false and HoldType.SyncProfile then
        HoldType.SyncProfile(name, profile)
    end
    return true
end

function HoldType.Register(name, sequences)
    return ApplyProfile(name, sequences, true)
end

function HoldType.Update(name, sequences)
    return HoldType.Register(name, sequences)
end

function HoldType.GetRevision(name)
    if not isstring(name) then return 0 end
    return HoldType.Revisions[string.lower(string.Trim(name))] or 0
end

function HoldType.SetPlaybackRate(name, state, rate)
    local profile = HoldType.Get(name)
    rate = tonumber(rate)
    if not profile or not rate or rate ~= rate or rate == math.huge or rate == -math.huge then
        return false
    end

    rate = math.Clamp(rate, 0.05, 4)
    local updated = table.Copy(profile)
    if state == "*" then
        updated.playback_rate = rate
        for _, stateName in ipairs(REQUIRED_STATES) do
            local stateData = updated[stateName]
            if istable(stateData) then
                stateData.playback_rate = rate
            end
        end
    elseif not state or state == "" then
        updated.playback_rate = rate
    else
        state = string.lower(tostring(state))
        if not table.HasValue(REQUIRED_STATES, state) then return false end
        local stateData = updated[state]
        if not istable(stateData) then stateData = {stateData} end
        stateData.playback_rate = rate
        updated[state] = stateData
    end
    return HoldType.Register(name, updated)
end

function HoldType.SetSequence(name, state, sequences)
    local profile = HoldType.Get(name)
    if not profile or not isstring(state) then return false end
    state = string.lower(string.Trim(state))
    if not table.HasValue(REQUIRED_STATES, state) then return false end

    if isstring(sequences) then
        sequences = {sequences}
    end
    if not istable(sequences) then return false end

    local updated = table.Copy(profile)
    local stateData = table.Copy(sequences)
    local oldState = updated[state]
    if stateData.playback_rate == nil and istable(oldState) then
        stateData.playback_rate = oldState.playback_rate
    end
    updated[state] = stateData
    return HoldType.Register(name, updated)
end

HoldType.ApplyProfile = ApplyProfile

function HoldType.Get(name)
    if not isstring(name) then return nil end
    return HoldType.Registry[string.lower(string.Trim(name))]
end

function HoldType.GetForWeapon(weapon)
    if not IsValid(weapon) then
        return HoldType.Get(HoldType.Default), HoldType.Default
    end

    local name = weapon.ShibiHoldType

    if not isstring(name) or name == "" then
        name = weapon:GetNWString("SHIBI::HoldType", "")
    end

    if name == "" then return nil end
    return HoldType.Get(name), string.lower(name)
end

function HoldType.SelectState(ply, velocity)
    local data = movementStates[ply]
    if not data then
        data = {wasOnGround = ply:OnGround(), landUntil = 0}
        movementStates[ply] = data
    end

    local onGround = ply:OnGround()
    if onGround and not data.wasOnGround then
        data.landUntil = CurTime() + LAND_TIME
    end
    data.wasOnGround = onGround

    if not onGround then return "jump" end
    if data.landUntil > CurTime() then return "land" end

    local speed = velocity:Length2D()
    if ply:Crouching() then
        return speed > MOVE_EPSILON and "crouch_walk" or "crouch_idle"
    end
    if speed <= MOVE_EPSILON then return "idle" end
    if speed >= math.max(ply:GetRunSpeed(), 1) * 0.86 then return "sprint" end
    if speed >= math.max(ply:GetWalkSpeed(), 1) * 1.15 then return "run" end
    return "walk"
end

function HoldType.IsBodyTurnBlocked(ply)
    if not IsValid(ply) then return false end
    if ply:GetNW2Bool("SHIBI::Dash::Active", false) then return true end
    return CurTime() < ply:GetNW2Float("SHIBI::Dash::TurnLockUntil", 0)
end

function HoldType.ResetMovementState(ply)
    movementStates[ply] = nil
end

function HoldType.GetPlaybackRate(ply, velocity)
    if not (IsValid(ply) and ply:Alive()) then return nil end
    if ply:InVehicle() or ply:GetMoveType() == MOVETYPE_NOCLIP or ply:WaterLevel() >= 2 then
        return nil
    end
    local profile = HoldType.GetForWeapon(ply:GetActiveWeapon())
    if not profile then return nil end

    local state = profile[HoldType.SelectState(ply, velocity)]
    local rate = (istable(state) and tonumber(state.playback_rate))
        or tonumber(profile.playback_rate) or 1
    rate = rate * (tonumber(profile.speed_scale) or 1)
    if rate ~= rate or rate == math.huge or rate == -math.huge then return 1 end
    return math.Clamp(rate, 0.05, 4)
end

function HoldType.InstallPlaybackRate()
    local gm = GAMEMODE
    if not gm or not isfunction(gm.UpdateAnimation) then return false end
    if HoldType._PlaybackRateGM == gm
        and HoldType._PlaybackRateWrapper == gm.UpdateAnimation then
        return true
    end

    local original = gm.UpdateAnimation
    local wrapper = function(self, ply, velocity, maxSeqGroundSpeed, ...)
        local a, b, c, d, e, f = original(self, ply, velocity, maxSeqGroundSpeed, ...)
        local rate = HoldType.GetPlaybackRate(ply, velocity)
        if rate and IsValid(ply) then
            ply:SetPlaybackRate(rate)
        end
        return a, b, c, d, e, f
    end

    gm.UpdateAnimation = wrapper
    HoldType._PlaybackRateGM = gm
    HoldType._PlaybackRateWrapper = wrapper
    return true
end

HoldType.InstallPlaybackRate()
hook.Add("Initialize", "SHIBI::HoldType::InstallPlaybackRate", function()
    HoldType.InstallPlaybackRate()
end)
hook.Add("InitPostEntity", "SHIBI::HoldType::InstallPlaybackRate", function()
    HoldType.InstallPlaybackRate()
end)
hook.Add("OnReloaded", "SHIBI::HoldType::InstallPlaybackRate", function()
    HoldType.InstallPlaybackRate()
end)

HoldType.Register("default", {
    idle = {"evo_512qpt5l3oowp213", "idle_all_01", "idle"},
    walk = {"evo_2kh3hdascgth", "walk_all", "walk"},
    run = {"evo_2kh3hdascgth", "run_all", "run"},
    sprint = {"evo_2kh3hdascgth", "run_all", "run"},
    jump = {"h_jump", "jump_holding_glide", "jump"},
    land = {"evo_36rgx0yt6cv2wg6p", "evo_36rgx0yt6cv2wg6p", "land"},
    crouch_idle = {"cidle_all", "crouch_idle", "idle_all_01"},
    crouch_walk = {"cwalk_all", "crouch_walk", "evo_2kh3hdascgth"},
    playback_rate = 1,
})

HoldType.Register("test", {
    idle = {"idle_all_02", "evo_512qpt5l3oowp213", "idle_all_01", playback_rate = 1},
    walk = {"evo_2kh3hdascgth", "walk_all", playback_rate = 2},
    run = {"evo_2kh3hdascgth", "run_all", playback_rate = 1.0},
    sprint = {"evo_07lmiiv4n8rc0pkz", "run_all", playback_rate = 1},
    jump = {"oldjimmy_akaza_a_p1012_v00_c90_basejump01_2", "jump_holding_glide", playback_rate = 0.9},
    land = {"evo_36rgx0yt6cv2wg6p", "evo_36rgx0yt6cv2wg6p", playback_rate = 0.9},
    crouch_idle = {"cidle_all", "crouch_idle", "idle_all_02", playback_rate = 0.75},
    crouch_walk = {"cwalk_all", "crouch_walk", "evo_2kh3hdascgth", playback_rate = 0.7},
    playback_rate = 1,
})
HoldType.Register("katana", {
    idle = {"tysibazhuangnan_0_battle_idle_base", "idle_all_01", "idle", playback_rate = 0.6},
    walk = {"evo_2kh3hdascgth", "walk_all", playback_rate = 2},
    run = {"evo_2kh3hdascgth", "run_all", playback_rate = 1.0},
    sprint = {"evo_81yb5x2oz12h", "run_all", playback_rate = 1},
    jump = {"oldjimmy_akaza_a_p1012_v00_c90_basejump01_2", "jump_holding_glide", playback_rate = 0.9},
    land = {"evo_36rgx0yt6cv2wg6p", "evo_36rgx0yt6cv2wg6p", playback_rate = 0.9},
    crouch_idle = {"cidle_all", "crouch_idle", "idle_all_02", playback_rate = 0.75},
    crouch_walk = {"cwalk_all", "crouch_walk", "evo_2kh3hdascgth", playback_rate = 0.7},
    playback_rate = 1,
})

HoldType.Register("sai", {
    idle = {"yin3_0_battle_idle_base", "idle_all_01", "idle", playback_rate = 0.6},
    walk = {"evo_2kh3hdascgth", "walk_all", playback_rate = 2},
    run = {"evo_2kh3hdascgth", "run_all", playback_rate = 1.0},
    sprint = {"evo_07lmiiv4n8rc0pkz", "run_all", playback_rate = 1},
    jump = {"oldjimmy_akaza_a_p1012_v00_c90_basejump01_2", "jump_holding_glide", playback_rate = 0.9},
    land = {"evo_36rgx0yt6cv2wg6p", "evo_36rgx0yt6cv2wg6p", playback_rate = 0.9},
    crouch_idle = {"cidle_all", "crouch_idle", "idle_all_02", playback_rate = 0.75},
    crouch_walk = {"cwalk_all", "crouch_walk", "evo_2kh3hdascgth", playback_rate = 0.7},
    playback_rate = 1,
})

HoldType.Weapon = HoldType.Registry
HoldType.Unarmed = HoldType.Get("default")
HoldType.RegisterWeapon = HoldType.Register
HoldType.GetWeapon = HoldType.Get

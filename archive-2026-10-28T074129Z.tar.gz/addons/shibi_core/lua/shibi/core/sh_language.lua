local type = type
local tostring = tostring
local pairs = pairs
SHIBI.Languages = SHIBI.Languages or {}
local cfg = SHIBI.Config or {}

local languageCache = {}

function SHIBI.Languages:String(id, data)
    if type(id) ~= "string" then return "nil" end

    if not languageCache[cfg.Language] then
        languageCache[cfg.Language] = {}
    end

    if not data and languageCache[cfg.Language][id] then
        return languageCache[cfg.Language][id]
    end

    local result = SHIBI.Languages[cfg.Language] and SHIBI.Languages[cfg.Language][id]
    if not result then
        if not data then
            languageCache[cfg.Language][id] = "nil"
        end
        return "nil"
    end

    if type(data) ~= "table" then
        languageCache[cfg.Language][id] = result
        return result
    end

    for key, value in pairs(data) do
        result = result:gsub("{" .. key .. "}", tostring(value))
    end

    return result
end

SHIBI.Languages["ru"] = {
    ["Context Menu Off"] = "Стандартный Context-Menu выключен",
    ["Context Menu On"] = "Стандартный Context-Menu включен",
    ["Time Year"] = "г",
    ["Time Month"] = "м",
    ["Time Week"] = "н",
    ["Time Day"] = "д",
    ["Time Hour"] = "ч",
    ["Time Minute"] = "м",
    ["Time Second"] = "сек",
    ["VGUI Confirm"] = "ПРИМЕНИТЬ",
    ["VGUI Search"] = "Поиск...",
}

SHIBI.Languages["en"] = {
    ["Context Menu Off"] = "Standard Context Menu disabled",
    ["Context Menu On"] = "Standard Context Menu enabled",
    ["Time Year"] = "y",
    ["Time Month"] = "m",
    ["Time Week"] = "w",
    ["Time Day"] = "d",
    ["Time Hour"] = "h",
    ["Time Minute"] = "m",
    ["Time Second"] = "s",
    ["VGUI Confirm"] = "CONFIRM",
    ["VGUI Search"] = "Search...",
}

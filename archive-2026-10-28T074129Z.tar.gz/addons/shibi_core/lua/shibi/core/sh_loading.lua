SHIBI.Anim = SHIBI.Anim or {}
SHIBI.Anim.LoadingModels = {
    "models/player/anim_shinemeig_shinsei.mdl",
    "models/player/wiltos/anim_extension_shinsei_combat.mdl",
    "models/player/anim_shinemeig_shinsei_combat.mdl",
    "models/player/anim_shinemeig_shinsei_combat_hakudo.mdl",
    "models/player/anim_shinemeig_shinsei_emote.mdl",
    "models/player/wiltos/anim_extension_mod13.mdl",
    "models/player/wiltos/anim_extension_mod9.mdl",
    "models/player/anim_judgement.mdl",
    "models/player/anim_phalanx.mdl",
    "models/player/anim_pure.mdl",
    "models/player/anim_ryoku.mdl",
    "models/player/anim_vanguard.mdl",
    "models/player/player_anim_shared.mdl",
    "models/player/wiltos/anim_base.mdl",
    "models/player/wiltos/anim_base_female.mdl",
    "models/player/wiltos/anim_base_zombie.mdl",
    "models/player/wiltos/anim_extension_bs.mdl",
    "models/player/wiltos/anim_extension_mod12.mdl",
    "models/player/wiltos/anim_extension_mod14.mdl",
    "models/player/wiltos/anim_extension_mod15.mdl",
    "models/player/wiltos/anim_extension_mod16.mdl",
    "models/player/wiltos/anim_extension_mod18.mdl",
    "models/player/wiltos/anim_extension_mod2.mdl",
    "models/player/wiltos/anim_extension_mod3.mdl",
    "models/player/wiltos/anim_extension_mod4.mdl",
    "models/player/wiltos/anim_extension_mod5.mdl",
    "models/player/wiltos/anim_extension_nmrih.mdl",
}

SHIBI.Anim._Loaded = SHIBI.Anim._Loaded or false

function SHIBI.Anim.AutoLoad()
    if SHIBI.Anim._Loaded then return end
    SHIBI.Anim._Loaded = true

    if not wOS or not wOS.DynaBase then
        SHIBI.LogError("[AnimAutoLoad] wOS.DynaBase не загружен")
        return
    end

    local models = SHIBI.Anim.LoadingModels
    if not istable(models) or #models == 0 then
        SHIBI.LogWarning("[AnimAutoLoad] Список пуст")
        return
    end

    local mounted = 0

    for i, mdl in ipairs(models) do
        if not isstring(mdl) or mdl == "" then continue end
        if not file.Exists(mdl, "GAME") then
            SHIBI.LogWarning("[AnimAutoLoad] Файл не найден: " .. mdl)
            continue
        end

        wOS.DynaBase:RegisterSource({
            Name   = "[SHIBI] Anim #" .. i,
            Type   = WOS_DYNABASE.EXTENSION,
            Shared = mdl,
        })

        hook.Add("PreLoadAnimations", "SHIBI::AnimAutoLoad::" .. i, function(gender)
            if gender ~= WOS_DYNABASE.SHARED then return end
            IncludeModel(mdl)
        end)

        mounted = mounted + 1
    end

    if CLIENT then
        wOS.DynaBase.LIVE_RELOAD = true
    end

    if wOS.DynaBase.DefaultTable and wOS.DynaBase.DefaultTable.Shared then
        added = table.Copy(wOS.DynaBase.DefaultTable.Shared)
    else
        added = {}
    end

    hook.Call("PreLoadAnimations", nil, WOS_DYNABASE.SHARED, added)

    if AdjustMountOrder and WRITE_TO_POINTER and INCLUDE_MODEL_START and INCLUDE_MODEL_END_SHARED then
        local ntable = AdjustMountOrder(added, WOS_DYNABASE.SHARED)
        added = ntable or added
        WRITE_TO_POINTER(INCLUDE_MODEL_START, INCLUDE_MODEL_END_SHARED, WOS_DYNABASE.SHARED)
    end

    if SERVER then
        hook.Call("PostLoadAnimations")
    else
        wOS.DynaBase.ReloadModelBool = true
    end

    SHIBI.Log(("[AnimAutoLoad] Загружено %d моделей"):format(mounted))
end

if CLIENT then
    hook.Add("InitPostEntity", "SHIBI::AnimAutoLoad::Client", function()
        timer.Simple(2, function()
            SHIBI.Anim.AutoLoad()
            timer.Simple(0.5, function()
                if wOS and wOS.DynaBase and wOS.DynaBase.ReloadAnimations then
                    wOS.DynaBase.LIVE_RELOAD = true
                    wOS.DynaBase:ReloadAnimations()
                    SHIBI.Log("[AnimAutoLoad] ReloadAnimations вызван на клиенте")
                end
            end)
        end)
    end)
end

if SERVER then
    hook.Add("InitPostEntity", "SHIBI::AnimAutoLoad::Server", function()
        timer.Simple(2, function()
            SHIBI.Anim.AutoLoad()
        end)
    end)
end

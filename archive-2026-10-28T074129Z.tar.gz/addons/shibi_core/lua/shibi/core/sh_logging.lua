-- логи. без них потом не поймёшь, кто сломал сервер
local MsgC = MsgC
local string_format = string.format
local debug_Trace = debug.Trace
local debug_getinfo = debug.getinfo
SHIBI.Config = SHIBI.Config or {}
SHIBI.Util = SHIBI.Util or {}
SHIBI.Util.GetCurrentTimeStamp = SHIBI.Util.GetCurrentTimeStamp or function()
    return os.date("%Y-%m-%d %H:%M:%S")
end

local cfg = SHIBI.Config

local prefixCol = cfg.LogPrefixCol or Color(255, 255, 255)
local messageCol = cfg.LogMessageCol or Color(200, 200, 200)
local warningCol = cfg.LogWarningCol or Color(255, 255, 0)
local errorCol = cfg.LogErrorCol or Color(255, 0, 0)

function SHIBI.Log(msg, prefixColOverride)
    local timestamp = SHIBI.Util.GetCurrentTimeStamp()
    local fullMsg = string_format("[%s] SHIBI | %s", timestamp, msg)
    MsgC(prefixColOverride or prefixCol, fullMsg .. "\n")
end

function SHIBI.LogWarning(warningMsg)
    local timestamp = SHIBI.Util.GetCurrentTimeStamp()
    local fullMsg = string_format("[%s] SHIBI - WARNING | %s", timestamp, warningMsg)
    MsgC(warningCol, fullMsg .. "\n")
end

function SHIBI.LogError(errorMsg)
    local timestamp = SHIBI.Util.GetCurrentTimeStamp()
    local fullMsg = string_format("[%s] SHIBI - ERROR | %s", timestamp, errorMsg)
    MsgC(errorCol, fullMsg .. "\n")
    debug_Trace()
end

function SHIBI.Assert(expression, errorMsg)
    if not expression then
        SHIBI.LogError(errorMsg)
    end
end

function SHIBI.CheckType(var, expectedType)
    local actualType = type(var)
    if actualType ~= expectedType then
        SHIBI.LogError(string_format("Ожидаемый тип \"%s\" для переменной, получен \"%s\"", expectedType, actualType))
    end
end

local levelMap = {
    ["INFO"] = { color = messageCol, prefix = "INFO" },
    ["WARNING"] = { color = warningCol, prefix = "WARNING" },
    ["ERROR"] = { color = errorCol, prefix = "ERROR" },
}

function SHIBI.LogWithContext(level, msg, prefixColOverride)
    local logDetails = levelMap[level:upper()] or levelMap["INFO"]
    local timestamp = SHIBI.Util.GetCurrentTimeStamp()
    local callerInfo = debug_getinfo(2, "Sl")
    local fullMsg = string_format("[%s] SHIBI - %s | %s (File: %s, Line: %d)", timestamp, logDetails.prefix, msg, callerInfo.source, callerInfo.currentline)
    MsgC(prefixColOverride or logDetails.color, fullMsg .. "\n")
end

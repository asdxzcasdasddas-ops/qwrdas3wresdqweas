local particleFiles = {
    "particles/1fsc.pcf",
    "particles/li_blc_base_p1.pcf",
    "particles/ya_ds_evo_p1.pcf",
}

local particleNames = {
    "martialhit_heavy_helper_1_geams_solve",
    "orbe_bijuu_izox",
    "[0]_takitsubo",
    "[*]_sword_hit_effect",
    "[*]_stunning_effect",
    "[10]_foam_cyclone",
}

local function LoadParticles()
    for _, pcf in ipairs(particleFiles) do
        pcall(game.AddParticles, pcf)
    end

    for _, name in ipairs(particleNames) do
        pcall(PrecacheParticleSystem, name)
    end
end

hook.Add("Initialize", "SHIBI::Particles::Init", LoadParticles)
timer.Simple(0.1, LoadParticles)

SHIBI.Log("[Particles] часть загружена")

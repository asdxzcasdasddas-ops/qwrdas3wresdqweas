local DURATION = 3.1

local function T(sec)
    return sec / DURATION
end

SHIBI.Cutscene.Define("hollow_debut", {
    duration = DURATION,
    blendIn  = 0,
    minDistance = 240,

    keys = {
        { t = T(0.00), pos = Vector(300,  40, 200), look = Vector(0, 0,  0), fov = 60 },
        { t = T(0.45), pos = Vector(260, -20, 160), look = Vector(0, 0,  0), fov = 58 },
        { t = T(0.50), hard = true, pos = Vector(190, -120, -40), look = Vector(0, 0, 10), fov = 48 },
        { t = T(1.10), pos = Vector(140, -70,   0), look = Vector(0, 0,  0), fov = 44 },
        { t = T(1.60), pos = Vector(120, -45,   5), look = Vector(0, 0,  0), fov = 40 },
        { t = T(2.10), pos = Vector(110, -10,   8), look = Vector(0, 0,  0), fov = 38 },
        { t = T(2.60), pos = Vector(120,  40,  10), look = Vector(0, 0,  0), fov = 40 },
        { t = T(3.20), pos = Vector(300,  60, 120), look = Vector(0, 0,  0), fov = 64 },
    },

    flashes = {
        { at = 0.45, dur = 0.60, alpha = 0.80 },
        { at = 1.10, dur = 0.50, alpha = 0.35, color = Color(255, 210, 210) },
    },

    impulses = {
        { at = 1.55, pitch = -7.0, yaw = 2.0, dur = 1.0 },
        { at = 1.84, pitch = -3.0, yaw = 0.5, dur = 0.8 },
    },

    rumbles = {
        { from = 1.10, to = 2.20, pitch = 1.2, yaw = 1.0, freq = 38 },
    },
})

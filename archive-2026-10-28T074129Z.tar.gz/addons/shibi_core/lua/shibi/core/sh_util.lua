local cfg = SHIBI.Config
local isstring = isstring
local isnumber = isnumber
local tonumber = tonumber
local IsValid = IsValid
local SysTime = SysTime
local pairs = pairs
local ipairs = ipairs
local FindMetaTable = FindMetaTable
local os_time = os.time
local math_random = math.random
local math_Clamp = math.Clamp
local math_floor = math.floor
local math_Round = math.Round
local table_insert = table.insert
local table_concat = table.concat
local table_remove = table.remove
local table_HasValue = table.HasValue
local table_sort = table.sort
local player_GetAll = player.GetAll
local file_Find = file.Find
local string_format = string.format
local string_find = string.find
local string_match = string.match
local meta = FindMetaTable("Player")

local TIME_UNITS = {
    m = 1,
    h = 60,
    d = 1440,
    w = 10080,
    mo = 43800,
    y = 525600
}

function SHIBI.Util.IsSteamID(str)
    return isstring(str) and str:match("^STEAM_[0-5]:[0-1]:[0-9]+$") ~= nil
end

function SHIBI.Util.IsSteamID64(str)
    return isstring(str) and str:sub(1, 7) == "7656119" and (#str == 17 or #str == 18)
end

function SHIBI.Util.ParseTime(length)
    local totalMinutes = 0
    local found = false
    if isnumber(length) then
        totalMinutes = math_Clamp(length, 0, 31536000)
        found = true
    elseif isstring(length) then
        for num, unit in length:gmatch("(%d+)(%a+)") do
            local unitMinutes = TIME_UNITS[unit]
            if unitMinutes then
                totalMinutes = totalMinutes + (tonumber(num) * unitMinutes)
                found = true
            end
        end
    end
    return found and math_Clamp(totalMinutes, 0, 31536000) or false
end

function SHIBI.Util.TimeToStr(time, formatType)
    time = tonumber(time)
    formatType = formatType or "time"
    if not time then return "00:00:00:00" end
    local s = time % 60
    time = math.floor(time / 60)
    local m = time % 60
    time = math.floor(time / 60)
    local h = time % 24
    time = math.floor(time / 24)
    local d = time % 7
    time = math.floor(time / 7)
    local w = time % 4
    time = math.floor(time / 4)
    local mo = time % 12
    local y = math.floor(time / 12)
    if formatType == "detailed" then
        local result = ""
        if y > 0 then result = result .. y .. "г " end
        if mo > 0 then result = result .. mo .. "м " end
        if w > 0 then result = result .. w .. "н " end
        if d > 0 then result = result .. d .. "д " end
        if h > 0 then result = result .. h .. "ч " end
        if m > 0 then result = result .. m .. "м " end
        return result:Trim()
    else
        local parts = {d, h, m, s}
        local firstNonZero = 1
        for i = 1, #parts - 1 do
            if parts[i] ~= 0 then break end
            firstNonZero = i + 1
        end

        local formatted = {}
        for i = firstNonZero, #parts do
            table.insert(formatted, string.format("%02i", parts[i]))
        end
        return table.concat(formatted, ":")
    end
end

function SHIBI.Util.GetCurrentTimeStamp()
    return os.date("%Y-%m-%d %H:%M:%S")
end

function SHIBI.Util.FindPlayerByName(targetName)
    for _, target in ipairs(player_GetAll()) do
        if string_find(string.lower(target:Nick()), string.lower(targetName), 1, true) then return target end
    end
    return nil
end

function SHIBI.Util.FindPlayersInSphere(pos, radius, plyList)
    radius = radius ^ 2
    local results = {}
    local players = plyList or player_GetAll()
    for _, ply in ipairs(players) do
        if ply:GetPos():DistToSqr(pos) <= radius then table_insert(results, ply) end
    end
    return results
end

function SHIBI.Util.FindEmptyPos(initialPos, ignore, maxDist, stepSize, checkSize)
    if not isvector(initialPos) then return initialPos end
    maxDist = maxDist or 300
    stepSize = stepSize or 30
    checkSize = checkSize or Vector(16, 16, 64)
    ignore = ignore or {}

    local pos = Vector(initialPos)
    local startPos = Vector(initialPos)

    for dist = 0, maxDist, stepSize do
        for angle = 0, 360, 45 do
            local ang = Angle(0, angle, 0)
            local offset = ang:Forward() * dist
            local checkPos = startPos + offset
            checkPos.z = startPos.z

            local tr = util.TraceHull({
                start = checkPos,
                endpos = checkPos,
                mins = -checkSize,
                maxs = checkSize,
                mask = MASK_PLAYERSOLID,
                filter = ignore,
            })

            if not tr.Hit and not tr.StartSolid then
                return checkPos
            end
        end
    end

    return initialPos
end

function SHIBI.Util.NickSortedPlayers()
    local plys = player_GetAll()
    table_sort(plys, function(a, b) return a:Nick() < b:Nick() end)
    return plys
end

function SHIBI.Util.FormatElapsedTime(seconds)
    local minutes = math_floor(seconds / 60)
    seconds = seconds % 60
    if minutes > 0 then
        return string_format("%d minute%s и %.2f second%s", minutes, minutes > 1 and "s" or "", seconds, seconds > 1 and "s" or "")
    else
        return string_format("%.2f second%s", seconds, seconds > 1 and "s" or "")
    end
end

function SHIBI.Util.IsMap(name)
    local cachedMaps = SHIBI._cachedMaps
    if not cachedMaps then
        cachedMaps = {}
        for _, fileName in ipairs(file_Find("maps/*.bsp", "GAME")) do
            cachedMaps[#cachedMaps + 1] = fileName:sub(1, -5):lower()
        end
        SHIBI._cachedMaps = cachedMaps
    end

    name = name:lower():gsub("%.bsp$", "")
    return table_HasValue(cachedMaps, name) and name or false
end

function SHIBI.Util.SteamIDTo64(steamid)
    return util.SteamIDTo64(steamid)
end

function SHIBI.Util.SteamID64ToSteam(steamid64)
    return util.SteamIDFrom64(steamid64)
end

-- переопределяем админа, потому что группы у нас свои, а не как у людей
function meta:IsAdmin()
    return self:IsUserGroup("admin") or self:IsUserGroup("superadmin")
end

function meta:IsSuperAdmin()
    return self:IsUserGroup("superadmin")
end

function meta:IsDeveloper()
    return self:IsUserGroup("developer") or self:IsSuperAdmin()
end

function meta:IsStaff()
    return self:IsAdmin() or self:IsSuperAdmin() or self:IsDeveloper()
end

meta.SHIBI_OriginalNick = meta.SHIBI_OriginalNick or meta.Nick
meta.SHIBI_OriginalName = meta.SHIBI_OriginalName or meta.Name
meta.SHIBI_OriginalGetName = meta.SHIBI_OriginalGetName or meta.GetName

function meta:GetCharacterName()
    local characterName = string.Trim(self:GetNWString("SHIBI::Character::Name", ""))
    if characterName ~= "" then
        return characterName
    end

    return nil
end

function meta:Nick()
    local characterName = self:GetCharacterName()
    if characterName then return characterName end

    return meta.SHIBI_OriginalNick(self)
end

function meta:Name()
    local characterName = self:GetCharacterName()
    if characterName then return characterName end

    local original = meta.SHIBI_OriginalName or meta.SHIBI_OriginalNick
    return original(self)
end

function meta:GetName()
    local characterName = self:GetCharacterName()
    if characterName then return characterName end

    local original = meta.SHIBI_OriginalGetName or meta.SHIBI_OriginalNick
    return original(self)
end

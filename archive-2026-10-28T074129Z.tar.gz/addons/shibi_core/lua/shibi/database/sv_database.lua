SHIBI.Config = SHIBI.Config or {}
SHIBI.Config.Database = SHIBI.Config.Database or {
    EnableMySQL = false,
    Host = "127.0.0.1",
    Username = "root",
    Password = nil,
    Database = "shibi",
    Port = 3306,
}

local cfg = SHIBI.Config.Database

-- эту функцию никто не вызывает, но пусть лежит, жалко что ли
function SHIBI.InitializeDB()
    if cfg.EnableMySQL then
        if not mysqloo or not mysqloo.CreateDatabase then
            SHIBI.LogError("[MySQL] EnableMySQL = true, но модуль mysqloo не установлен")
            return
        end
        SHIBI.Log("[MySQL] Подключение к базе данных...")

        MYSQLOO_DB = mysqloo.CreateDatabase(cfg.Host, cfg.Username, cfg.Password, cfg.Database, cfg.Port)

        function MYSQLOO_DB:onConnected()
            SHIBI.Log("[MySQL] Успешное подключение!")

            local query = self:query("SELECT 5+5")
            function query:onSuccess(data)
                SHIBI.Log("[MySQL] Успешно подключились к базе данных!")
            end

            function query:onError(err, sql)
                SHIBI.Log("[MySQL] Ошибка выполнения запроса!")
                SHIBI.Log("[MySQL] SQL: " .. (sql or "Неизвестный SQL"))
                SHIBI.Log("[MySQL] Ошибка: " .. (err or "Неизвестная ошибка"))
            end

            query:start()
        end

        function MYSQLOO_DB:onConnectionFailed(err)
            SHIBI.Log("[MySQL] Ошибка подключения к базе данных!")
            SHIBI.Log("[MySQL] Ошибка: " .. (err or "Неизвестная ошибка"))
        end
    end
end

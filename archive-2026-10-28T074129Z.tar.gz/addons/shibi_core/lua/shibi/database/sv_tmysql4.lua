if not util.IsBinaryModuleInstalled("mysqloo") then return end
require("mysqloo")
if mysqloo.VERSION ~= "9" then error("using outdated mysqloo version") end

tmysql = tmysql or {}
tmysql.Connections = tmysql.Connections or {}

local database = {}
local baseMeta = FindMetaTable("MySQLOO Database") or {}
local databaseMT = {
    __index = function(tbl, key) return database[key] or baseMeta[key] end
}

function database:Escape(...)
    if self.Disconnected then error("database already disconnected") end
    return self:escape(...)
end

function database:Connect()
    self:connect()
    self:wait()
    if self:status() ~= mysqloo.DATABASE_CONNECTED then return false, "[TMYSQL Wrapper]: Failed to connect to database" end
    table.insert(tmysql.Connections, self)
    return true
end

function database:Query(str, callback, ...)
    if self.Disconnected then error("database already disconnected") end
    local additionalArgs = {...}
    local qu = self:query(str)
    if not callback then
        qu:start()
        return
    end

    qu.onSuccess = function(qu, result)
        local results = {
            {
                status = true,
                error = nil,
                affected = qu:affectedRows(),
                lastid = qu:lastInsert(),
                data = result
            }
        }

        while qu:hasMoreResults() do
            result = qu:getNextResults()
            table.insert(results, {
                status = true,
                error = nil,
                affected = qu:affectedRows(),
                lastid = qu:lastInsert(),
                data = result
            })
        end

        table.insert(additionalArgs, results)
        callback(unpack(additionalArgs))
    end

    qu.onAborted = function(qu)
        local data = {
            status = false,
            error = "Query aborted"
        }

        table.insert(additionalArgs, {data})
        callback(unpack(additionalArgs))
    end

    qu.onError = function(qu, err)
        local data = {
            status = false,
            error = err
        }

        table.insert(additionalArgs, {data})
        callback(unpack(additionalArgs))
    end

    qu:start()
end

function database:SetCharacterSet(name)
    return self:setCharacterSet(name)
end

function database:Disconnect()
    if self.Disconnected then error("database already disconnected") end
    self:abortAllQueries()
    table.RemoveByValue(tmysql.Connections, self)
    self.Disconnected = true
    self:disconnect()
end

function database:Option(option, value)
    if self.Disconnected then error("database already disconnected") end
    if option == bit.lshift(1, 16) then
        self:setMultiStatements(tobool(value))
    else
        SHIBI.Log("[TMYSQL Wrapper]: Unsupported tmysql option")
    end
end

function tmysql.GetTable()
    return tmysql.Connections
end

function tmysql.initialize(host, user, password, database, port, unixSocketPath, clientFlags)
    local db = mysqloo.connect(host, user, password, database, port, unixSocketPath)
    setmetatable(db, databaseMT)
    local status, err = db:Connect()
    if not status then return nil, err end
    return db, err
end

function tmysql.Create(host, user, password, database, port, unixSocketPath, clientFlags)
    local db = mysqloo.connect(host, user, password, database, port, unixSocketPath)
    setmetatable(db, databaseMT)
    return db
end

tmysql.Connect = tmysql.initialize

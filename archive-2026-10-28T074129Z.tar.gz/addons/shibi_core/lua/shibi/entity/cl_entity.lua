SHIBI.Entities.CL = SHIBI.Entities.CL or {}
local CL = SHIBI.Entities.CL

local function lerp(a, minv, maxv)
    return minv + (maxv - minv) * a
end

local function CL_AttachParticlesOnce(self, def)
    if self._clParticlesDone then return end
    if not istable(def) or not istable(def.particles) or #def.particles == 0 then return end

    self._clParticlesDone = true

    local attachName = def.particle_attach or "attach"
    local attachId   = self.LookupAttachment and self:LookupAttachment(attachName) or 0
    local haveAttach = isnumber(attachId) and attachId > 0

    local boneId
    if not haveAttach and isstring(def.particle_bone) and self:LookupBone(def.particle_bone) then
        boneId = self:LookupBone(def.particle_bone)
    end

    for _, pname in ipairs(def.particles) do
        if isstring(pname) and pname ~= "" then
            if PrecacheParticleSystem then
                PrecacheParticleSystem(pname)
            end

            if haveAttach then
                ParticleEffectAttach(pname, PATTACH_POINT_FOLLOW, self, attachId)
            elseif boneId then
                ParticleEffectAttach(pname, PATTACH_BONE_FOLLOW, self, boneId)
            else
                ParticleEffectAttach(pname, PATTACH_ABSORIGIN_FOLLOW, self, 0)
            end
        end
    end
end

function CL.CommonInitialize(self)
    local def = SHIBI.Entities:GetDefByClass(self:GetClass()) or {}
    self._def = def
    if (def.role or "generic") ~= "npc" then
        CL_AttachParticlesOnce(self, def)
    end
end

function CL.CommonDraw(self)
    local def  = self._def or SHIBI.Entities:GetDefByClass(self:GetClass()) or {}
    local role = self._role or def.role or "generic"

    if role ~= "npc" then
        CL_AttachParticlesOnce(self, def)

        local t = CurTime()
        local base = def.float_offset or 0
        local dz = 0
        if def.float_min ~= nil or def.float_max ~= nil then
            local minv = def.float_min or 0
            local maxv = def.float_max or 0
            local a = (math.sin(t * (def.float_speed or 2)) + 1) * 0.5
            dz = lerp(a, minv, maxv)
        elseif (def.float_amp or 0) ~= 0 then
            dz = math.sin(t * (def.float_speed or 2)) * (def.float_amp or 8)
        end

        local rotateSpeed = def.rotate_speed or 0
        local pos  = self:GetPos() + Vector(0, 0, base + dz)

        local ang  = self:GetAngles()
        if rotateSpeed ~= 0 then
            ang:RotateAroundAxis(ang:Up(), (t * rotateSpeed) % 360)
        end

        self:SetRenderOrigin(pos)
        self:SetRenderAngles(ang)
        self:SetupBones()
        self:DrawModel()
        self:SetRenderOrigin()
        self:SetRenderAngles()
    else
        self:DrawModel()
    end
end

function CL.CommonOnRemove(self)
    if self.StopParticles then
        self:StopParticles()
    end
end

SHIBI.Entities = SHIBI.Entities or {}
local E = SHIBI.Entities

E.Config = E.Config or {}

function E:Add(def)
    if not istable(def) or not isstring(def.class) then return end
    E.Config[def.class] = table.Copy(def)
end

function E:GetDefByClass(class)
    return class and E.Config[class] or nil
end

local function register_one(def)
    if scripted_ents.Get(def.class) then return end

    local ENT = {}
    ENT.Type = def.enttype or "anim"
    ENT.Base = def.base or (ENT.Type == "ai" and "base_ai" or "base_anim")
    ENT.PrintName = def.printName or def.class
    ENT.Category = def.category or "SHIBI | Custom"
    ENT.Spawnable = def.spawnable or false
    ENT.Description = def.desc or "none"
    ENT.AdminSpawnable = def.adminspawnable or false
    ENT.AutomaticFrameAdvance = (ENT.Type == "ai") and true or nil
    ENT._role = def.role or "generic"

    scripted_ents.Register(ENT, def.class)
end

function E:RegisterAll()
    for _, def in pairs(E.Config) do
        register_one(def)
    end
end

SHIBI.Entities.SV = SHIBI.Entities.SV or {}
local SV = SHIBI.Entities.SV

local function safeModel(m)
    if isstring(m) and util.IsValidModel(m) then
        return m
    end
    return "models/props_junk/garbage_milkcarton001a.mdl"
end

function SV.CommonInitialize(self)
    local def = SHIBI.Entities:GetDefByClass(self:GetClass())
    self._def = def
    local mdl = safeModel(def.model)
    self:SetModel(mdl)
    util.PrecacheModel(mdl)
    self:SetSkin(def.skin or 0)
    
    if self.Type == "ai" then
        self:SetHullType(def.npc_hull or HULL_HUMAN)
        self:SetHullSizeNormal()
        self:SetNPCState(def.npc_state or NPC_STATE_SCRIPT)
        self:SetSolid(SOLID_BBOX)
        self:CapabilitiesAdd(def.npc_caps or CAP_ANIMATEDFACE)
        self:SetUseType(SIMPLE_USE)
        self:DropToFloor()
        if isstring(def.npc_sequence) then
            self:SetSequence(def.npc_sequence)
        end
    else
        self:PhysicsInit(SOLID_VPHYSICS)
        self:SetMoveType(MOVETYPE_VPHYSICS)
        self:SetSolid(SOLID_VPHYSICS)
        self:SetUseType(SIMPLE_USE)
        if def.collision_group then
            self:SetCollisionGroup(def.collision_group)
        end
        local phys = self:GetPhysicsObject()
        if IsValid(phys) then
            phys:Wake()
        end
    end
end

function SV.CommonUse(self, activator)
    if not (IsValid(activator) and activator:IsPlayer()) then return end
    local def = self._def or SHIBI.Entities:GetDefByClass(self:GetClass()) or {}
    local role = self._role or def.role or "generic"

    if isfunction(def.on_use_sv) then
        local handled = def.on_use_sv(self, activator, def)
        if handled ~= nil then return end
    end

    if role ~= "npc" then
        self:Remove()
    end
end

function SV.CommonThink(self)
    local def = SHIBI.Entities:GetDefByClass(self:GetClass())
    if isstring(def.npc_sequence) then
        self:SetSequence(def.npc_sequence)
    end
    self:NextThink(CurTime() + 1)
    return true
end

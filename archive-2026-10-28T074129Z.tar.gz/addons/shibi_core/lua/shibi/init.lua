-- Пацаны, это загрузчик. Дальше он сам всё найдёт и подключит
_G.SHIBI = _G.SHIBI or {}

SHIBI.Version = "1.0.0"
SHIBI.BootTime = os.clock()
SHIBI.BootCount = (SHIBI.BootCount or 0) + 1
include("shibi/shared.lua")

function SHIBI.LoadFolder(folder)
    local files = file.Find(folder .. "/*.lua", "LUA")
    local _, folders = file.Find(folder .. "/*", "LUA")
    
    for _, file in ipairs(files) do
        local path = folder .. "/" .. file
        
        -- вот тут я заипался перечислять эти файлы, но зато не грузятся дважды
        if file == "cl_hud.lua" or file == "cl_resources.lua" or file == "sv_resources.lua" or file == "sh_wos_holdtypes.lua" or file == "sh_holdtypes.lua" or file == "sh_holdtypes_data.lua" or file == "sv_holdtypes.lua" or file == "sv_holdtypes_register.lua" or file == "cl_holdtypes_register.lua" then
            continue
        elseif file:StartsWith("sh_") then
            if SERVER then AddCSLuaFile(path) end
            include(path)
        elseif file:StartsWith("cl_") then
            if SERVER then AddCSLuaFile(path) end
            if CLIENT then include(path) end
        elseif file:StartsWith("sv_") then
            if SERVER then include(path) end
        end
    end
    
    -- и понеслась рекурсия
    for _, subfolder in ipairs(folders) do
        SHIBI.LoadFolder(folder .. "/" .. subfolder)
    end
end

local function LoadCore()
    local folders = {
        "shibi/core",
        "shibi/math",
        "shibi/network",
        "shibi/entity",
        "shibi/client",
        "shibi/server",
        "shibi/abilities",
        "shibi/database",
    }
    
    for _, folder in ipairs(folders) do
        SHIBI.LoadFolder(folder)
    end
end

LoadCore()

if SHIBI.Log then
    SHIBI.Log("SHIBI Core v" .. SHIBI.Version .. " загружено за " .. math.Round(os.clock() - SHIBI.BootTime, 2) .. "с.")
end

if SERVER then
    AddCSLuaFile("shibi/shared.lua")
end

-- математика. без неё способности летят не туда, куда целились
local abs, max, sqrt, pi, exp, cos, cosh = math.abs, math.max, math.sqrt, math.pi, math.exp, math.cos, math.cosh

local function tovec(v)
    if isangle(v) then return v:Forward() end
    if isvector(v) then return v end
    return nil
end

local function veq(a, b, eps)
    eps = eps or 1e-6
    return abs(a.x - b.x) < eps and abs(a.y - b.y) < eps and abs(a.z - b.z) < eps
end

local function build_coeffs(f, z, r)
    local w = 2 * pi * f
    local d = w * sqrt(abs(z * z - 1))
    local k1 = z / (pi * f)
    local k2 = 1 / ((2 * pi * f) * (2 * pi * f))
    local k3 = (r or 0) * z / (2 * pi * f)
    return w, z, d, k1, k2, k3
end

local function stable_k2(k1, k2, dt)
    return max(k2, dt * dt / 2 + dt * k1 / 2, dt * k1)
end

local function coeffs(f, z, r)
    local w = 2 * pi * f
    local d = w * sqrt(abs(z * z - 1))
    local k1 = z / (pi * f)
    local k2 = 1 / ((2 * pi * f) * (2 * pi * f))
    local k3 = (r or 0) * z / (2 * pi * f)
    return w, z, d, k1, k2, k3
end

SHIBI.Module = SHIBI.Module or {}

function SHIBI.Module:New(f, z, r, x0)
    assert(isnumber(f) and f > 0, "invalid frequency f")
    assert(isnumber(z) and z > 0, "invalid damping z")
    assert(isnumber(r or 0), "invalid velocity weight r")
    local v0 = tovec(x0)
    assert(v0 ~= nil, "x0 must be Vector or Angle")
    local obj = setmetatable({}, {
        __index = self
    })

    obj._f, obj._z, obj._r = f, z, r or 0
    obj.w, obj.z, obj.d, obj.k1, obj.k2, obj.k3 = build_coeffs(f, z, r)
    obj.xp = Vector(v0)
    obj.y = Vector(v0)
    obj.yd = Vector(0, 0, 0)
    obj._eps = 1e-6
    obj._mindt = 1e-4
    obj._maxdt = 0.25
    return obj
end

function SHIBI.Module:SetVector(x0)
    local v0 = tovec(x0)
    if not v0 then return self end
    self.xp = Vector(v0)
    self.y = Vector(v0)
    self.yd = Vector(0, 0, 0)
    return self
end

function SHIBI.Module:SetParams(f, z, r)
    if f then
        assert(isnumber(f) and f > 0, "f must be > 0")
        self._f = f
    end

    if z then
        assert(isnumber(z) and z > 0, "z must be > 0")
        self._z = z
    end

    if r ~= nil then
        assert(isnumber(r), "r must be number")
        self._r = r
    end

    self.w, self.z, self.d, self.k1, self.k2, self.k3 = build_coeffs(self._f, self._z, self._r)
    return self
end

function SHIBI.Module:Reset(x0)
    if x0 ~= nil then
        self:SetVector(x0)
        return self
    end

    self.xp:Set(self.y)
    self.yd:Set(0, 0, 0)
    return self
end

function SHIBI.Module:Get()
    return self.y
end

function SHIBI.Module:GetVelocity()
    return self.yd
end

function SHIBI.Module:GetParams()
    return self._f, self._z, self._r
end

local function normalize_inputs(self, dt, x, xd)
    assert(isnumber(dt), "dt must be number")
    dt = dt < self._mindt and self._mindt or (dt > self._maxdt and self._maxdt or dt)
    local xv = tovec(x)
    if not xv then return nil end
    local xdv = xd and tovec(xd) or nil
    if not xdv then
        xdv = (xv - self.xp) / dt
        self.xp = xv
    end

    if veq(xv, self.y, self._eps) then return dt, xv, xdv, true end
    return dt, xv, xdv, false
end

function SHIBI.Module:Update(dt, x, xd)
    local ok_dt, xv, xdv, early = normalize_inputs(self, dt, x, xd)
    if not ok_dt then return self.y end
    if early then return self.y end
    local k2s = stable_k2(self.k1, self.k2, ok_dt)
    self.y = self.y + ok_dt * self.yd
    self.yd = self.yd + ok_dt * (xv + self.k3 * xdv - self.y - self.k1 * self.yd) / k2s
    return self.y
end

function SHIBI.Module:UpdateExpensive(dt, x, xd)
    local ok_dt, xv, xdv, early = normalize_inputs(self, dt, x, xd)
    if not ok_dt then return self.y end
    if early then return self.y end
    local k1s, k2s
    if self.w * ok_dt < self.z then
        k1s = self.k1
        k2s = stable_k2(self.k1, self.k2, ok_dt)
    else
        local t1 = exp(-self.z * self.w * ok_dt)
        local alpha = 2 * t1 * ((self.z <= 1) and cos(ok_dt * self.d) or cosh(ok_dt * self.d))
        local beta = t1 * t1
        local t2 = ok_dt / (1 + beta - alpha + 1e-12)
        k1s = (1 - beta) * t2
        k2s = ok_dt * t2
    end

    self.y = self.y + ok_dt * self.yd
    self.yd = self.yd + ok_dt * (xv + self.k3 * xdv - self.y - k1s * self.yd) / k2s
    return self.y
end

SHIBI.Spring = SHIBI.Spring or {}

function SHIBI.Spring:New(f, z, r, x0)
    assert(isnumber(f) and f > 0, "invalid spring f")
    assert(isnumber(z) and z > 0, "invalid spring z")
    local v0 = tovec(x0) or Vector(0, 0, 0)
    local o = setmetatable({}, {
        __index = self
    })

    o._f, o._z, o._r = f, z, r or 0
    o.w, o.z, o.d, o.k1, o.k2, o.k3 = coeffs(f, z, r)
    o.xp = Vector(v0)
    o.y = Vector(v0)
    o.yd = Vector(0, 0, 0)
    o._eps, o._mindt, o._maxdt = 1e-6, 1e-4, 0.25
    return o
end

function SHIBI.Spring:Set(x0)
    local v0 = tovec(x0)
    if not v0 then return self end
    self.xp:Set(v0)
    self.y:Set(v0)
    self.yd:Set(0, 0, 0)
    return self
end

function SHIBI.Spring:SetParams(f, z, r)
    if f then
        assert(f > 0)
        self._f = f
    end

    if z then
        assert(z > 0)
        self._z = z
    end

    if r ~= nil then
        assert(isnumber(r))
        self._r = r
    end

    self.w, self.z, self.d, self.k1, self.k2, self.k3 = coeffs(self._f, self._z, self._r)
    return self
end

local function norm_inputs(self, dt, x, xd)
    assert(isnumber(dt))
    dt = dt < self._mindt and self._mindt or (dt > self._maxdt and self._maxdt or dt)
    local xv = tovec(x)
    if not xv then return end
    local xdv = xd and tovec(xd) or nil
    if not xdv then
        xdv = (xv - self.xp) / dt
        self.xp = Vector(xv)
    end

    local early = veq(xv, self.y, self._eps)
    return dt, xv, xdv, early
end

function SHIBI.Spring:Update(dt, x, xd)
    local ok_dt, xv, xdv, early = norm_inputs(self, dt, x, xd)
    if not ok_dt or early then return self.y end
    local k2s = stable_k2(self.k1, self.k2, ok_dt)
    self.y = self.y + ok_dt * self.yd
    self.yd = self.yd + ok_dt * (xv + self.k3 * xdv - self.y - self.k1 * self.yd) / k2s
    return self.y
end

function SHIBI.Spring:UpdateExpensive(dt, x, xd)
    local ok_dt, xv, xdv, early = norm_inputs(self, dt, x, xd)
    if not ok_dt or early then return self.y end
    local k1s, k2s
    if self.w * ok_dt < self.z then
        k1s = self.k1
        k2s = stable_k2(self.k1, self.k2, ok_dt)
    else
        local t1 = exp(-self.z * self.w * ok_dt)
        local alpha = 2 * t1 * ((self.z <= 1) and cos(ok_dt * self.d) or cosh(ok_dt * self.d))
        local beta = t1 * t1
        local t2 = ok_dt / (1 + beta - alpha + 1e-12)
        k1s = (1 - beta) * t2
        k2s = ok_dt * t2
    end

    self.y = self.y + ok_dt * self.yd
    self.yd = self.yd + ok_dt * (xv + self.k3 * xdv - self.y - k1s * self.yd) / k2s
    return self.y
end

local TYPE_FLOAT = 45

local function ReadType(type)
    if type == TYPE_STRING then return net.ReadString()
    elseif type == TYPE_NUMBER then return net.ReadInt(32)
    elseif type == TYPE_ENTITY then return net.ReadEntity()
    elseif type == TYPE_BOOL then return net.ReadBool()
    elseif type == TYPE_FLOAT then return net.ReadFloat()
    end
end

net.Receive("SHIBI::NWVar::Sync", function()
    local isPublic = net.ReadBool()
    local ent = net.ReadEntity()
    local type = net.ReadUInt(8)
    local key = net.ReadString()
    local value = ReadType(type)

    if not IsValid(ent) then return end

    local funcName = isPublic and "GetPublicVars" or "GetPrivateVars"
    local typeName = SHIBI.VarTypes[type]
    if not typeName then return end

    local tbl = ent[funcName] and ent[funcName](ent, typeName)
    if tbl then
        tbl[key] = value
    end
end)

net.Receive("SHIBI::NWVar::SyncAll", function()
    local count = net.ReadUInt(14)
    for _ = 1, count do
        local ent = net.ReadEntity()
        for _ = 1, 5 do
            local type = net.ReadUInt(8)
            local len = net.ReadUInt(12)
            local vars = ent:GetPublicVars(SHIBI.VarTypes[type])
            for _ = 1, len do
                local key = net.ReadString()
                local value = ReadType(type)
                vars[key] = value
            end
        end
    end
end)

local FindMetaTable = FindMetaTable

local meta = FindMetaTable("Entity")
function meta:getRPAngle(key, fallback, pvsOnly)
    return SHIBI.GetNWAngle(self, key, fallback, pvsOnly)
end

function meta:getRPBool(key, fallback, pvsOnly)
    return SHIBI.GetNWBool(self, key, fallback, pvsOnly)
end

function meta:getRPEntity(key, fallback, pvsOnly)
    return SHIBI.GetNWEntity(self, key, fallback, pvsOnly)
end

function meta:getRPFloat(key, fallback, pvsOnly)
    return SHIBI.GetNWFloat(self, key, fallback, pvsOnly)
end

function meta:getRPInt(key, fallback, pvsOnly)
    return SHIBI.GetNWInt(self, key, fallback, pvsOnly)
end

function meta:getRPString(key, fallback, pvsOnly)
    return SHIBI.GetNWString(self, key, fallback, pvsOnly)
end

function meta:getRPVector(key, fallback, pvsOnly)
    return SHIBI.GetNWVector(self, key, fallback, pvsOnly)
end

function meta:setRPAngle(key, val, pvsOnly)
    SHIBI.SetNWAngle(self, key, val, pvsOnly)
end

function meta:setRPBool(key, val, pvsOnly)
    SHIBI.SetNWBool(self, key, val, pvsOnly)
end

function meta:setRPEntity(key, val, pvsOnly)
    SHIBI.SetNWEntity(self, key, val, pvsOnly)
end

function meta:setRPFloat(key, val, pvsOnly)
    SHIBI.SetNWFloat(self, key, val, pvsOnly)
end

function meta:setRPInt(key, val, pvsOnly)
    SHIBI.SetNWInt(self, key, val, pvsOnly)
end

function meta:setRPString(key, val, pvsOnly)
    SHIBI.SetNWString(self, key, val, pvsOnly)
end

function meta:setRPVector(key, val, pvsOnly)
    SHIBI.SetNWVector(self, key, val, pvsOnly)
end

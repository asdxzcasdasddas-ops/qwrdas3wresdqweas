function SHIBI.BuildVarTable()
    return {
        String = {},
        Bool = {},
        Int = {},
        Entity = {},
        Float = {}
    }
end

SHIBI.VarTypes = {
    [TYPE_STRING] = "String",
    [TYPE_NUMBER] = "Int",
    [TYPE_ENTITY] = "Entity",
    [TYPE_BOOL] = "Bool",
    [45] = "Float"
}

SHIBI.StringToType = {
    String = TYPE_STRING,
    Int = TYPE_NUMBER,
    Entity = TYPE_ENTITY,
    Bool = TYPE_BOOL,
    Float = 45
}

util.AddNetworkString("SHIBI::NWVar::Sync")
util.AddNetworkString("SHIBI::NWVar::SyncAll")

local ENTS = {}
local TYPE_FLOAT = 45

local function WriteType(type, val)
    if type == TYPE_NUMBER then net.WriteInt(val, 32)
    elseif type == TYPE_BOOL then net.WriteBool(val)
    elseif type == TYPE_STRING then net.WriteString(val)
    elseif type == TYPE_ENTITY then net.WriteEntity(val)
    elseif type == TYPE_FLOAT then net.WriteFloat(val) end
end

local function WriteSet(type, kv)
    net.WriteString(kv[1])
    WriteType(type, kv[2])
end

local function IterTable(tbl)
    local t = {[0] = 0}
    for k,v in pairs(tbl) do
        t[0] = t[0] + 1
        t[t[0]] = {k, v}
    end
    return t
end

local function WriteTypeTable(ent, type)
    local tbl = ent:GetPublicVars(SHIBI.VarTypes[type])
    local kvList = IterTable(tbl)
    net.WriteUInt(type, 8)
    net.WriteUInt(kvList[0], 12)
    for i = 1, kvList[0] do
        WriteSet(type, kvList[i])
    end
end

local function WriteAllVars(ent)
    net.WriteEntity(ent)
    for type, _ in pairs(SHIBI.VarTypes) do
        WriteTypeTable(ent, type)
    end
end

function SHIBI.SyncAllPublic(ply)
    local list, count = {}, 0
    for k in pairs(ENTS) do
        if IsValid(k) then
            count = count + 1
            list[count] = k
        else
            ENTS[k] = nil
        end
    end

    net.Start("SHIBI::NWVar::SyncAll")
        net.WriteUInt(#list, 14)
        for _, ent in ipairs(list) do
            WriteAllVars(ent)
        end
    net.Send(ply)
end

function SHIBI.SyncVar(ent, type, key, value, recipient)
    if recipient == nil then
        recipient = true
    end

    net.Start("SHIBI::NWVar::Sync")
        net.WriteBool(recipient == true)
        net.WriteEntity(ent)
        net.WriteUInt(type, 8)
        net.WriteString(key)
        WriteType(type, value)

    if recipient == true then
        net.Broadcast()
    elseif IsValid(recipient) and recipient:IsPlayer() then
        net.Send(recipient)
    end
end

local ENTITY = FindMetaTable("Entity")
for typeName, typeID in pairs(SHIBI.StringToType) do
    local setPublic = "SetPublic" .. typeName
    local setPrivate = "SetPrivate" .. typeName

    ENTITY[setPublic] = function(self, key, value)
        local tbl = self:GetPublicVars(typeName)
        tbl[key] = value
        ENTS[self] = true

        SHIBI.SyncVar(self, typeID, key, value, true)
    end

    ENTITY[setPrivate] = function(self, key, value)
        local tbl = self:GetPrivateVars(typeName)
        tbl[key] = value
        ENTS[self] = true

        SHIBI.SyncVar(self, typeID, key, value, self)
    end
end

hook.Add("PlayerInitialSpawn", "SHIBI::PlayerInitialSpawn::NWVar", function(ply)
    timer.Simple(1, function()
        if IsValid(ply) then
            SHIBI.SyncAllPublic(ply)
        end
    end)
end)

hook.Add("EntityRemoved","SHIBI::EntityRemoved::NWvar", function(ent)
    ENTS[ent] = nil
end)

hook.Add("PlayerDisconnected","SHIBI::PlayerDisconnected::NWvar", function(ply)
    ENTS[ply] = nil
end)

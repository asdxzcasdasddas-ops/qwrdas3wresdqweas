if not SERVER then return end

SHIBI.Abilities = SHIBI.Abilities or {}
local A = SHIBI.Abilities

local NET_SAVE   = "SHIBI::Ability::SaveLoadout"
local NET_LOAD   = "SHIBI::Ability::Loadout"
local NET_UNLOCK = "SHIBI::Ability::Unlock"

util.AddNetworkString(NET_SAVE)
util.AddNetworkString(NET_LOAD)
util.AddNetworkString(NET_UNLOCK)

local SLOT_COUNT    = 6
local MAX_ABILITIES = 255
local MAX_ID_LEN    = 32
local TABLE_NAME    = "shibi_character_abilities"
local SAVE_COOLDOWN = 0.25
local STATE         = "SHIBI_AbilityState"

local function IsValidKey(k)
    return isnumber(k)
        and k >= 1 and k <= 255
        and k ~= MOUSE_LEFT and k ~= MOUSE_RIGHT and k ~= KEY_ESCAPE
end

local function DefaultKey(slot)
    return KEY_1 + slot - 1
end

local function SanitizeKey(key, slot)
    if IsValidKey(key) then return key end
    return DefaultKey(slot)
end

local function IsKnownAbility(id)
    return isstring(id) and #id <= MAX_ID_LEN and A.List[id] ~= nil
end

local function IsKnownCategory(id)
    return isstring(id) and A.Categories[id] ~= nil
end

local function Clamp16(v)
    return math.Clamp(math.floor(tonumber(v) or 0), 0, 65535)
end

local function NewState()
    return { points = 0, categories = {}, unlocked = {}, slots = {} }
end

local function EnsureTable()
    sql.Query([[
        CREATE TABLE IF NOT EXISTS shibi_character_abilities (
            steamid TEXT NOT NULL,
            slot INTEGER NOT NULL,
            data TEXT NOT NULL,
            PRIMARY KEY (steamid, slot)
        )
    ]]
)
end

local function CanPersist(ply)
    if not IsValid(ply) or ply:IsBot() then return false end
    local sid = ply:SteamID64()
    return isstring(sid) and sid ~= "0"
end

local function ReadState(steamid, slot)
    local st = NewState()
    EnsureTable()

    local row = sql.QueryRow("SELECT data FROM " .. TABLE_NAME .. " WHERE steamid = " ..
        sql.SQLStr(steamid) .. " AND slot = " .. slot)
    if not row then return st end

    local raw = util.JSONToTable(row.data or "")
    if not istable(raw) then
        st.loadFailed = true
        SHIBI.LogError("[Abilities] не удалось прочитать способности персонажа " .. steamid .. " слот " .. slot)
        return st
    end

    st.points = math.max(0, math.floor(tonumber(raw.points) or 0))

    if istable(raw.categories) then
        for id, v in pairs(raw.categories) do
            if v == true and IsKnownCategory(id) then st.categories[id] = true end
        end
    end

    if istable(raw.unlocked) then
        for id, v in pairs(raw.unlocked) do
            local def = A.List[id]
            if v == true and def and def.category and st.categories[def.category] then
                st.unlocked[id] = true
            end
        end
    end

    if istable(raw.slots) then
        for i = 1, SLOT_COUNT do
            local s = raw.slots[i]
            if istable(s) and IsKnownAbility(s.id) and st.unlocked[s.id] then
                st.slots[i] = { id = s.id, key = SanitizeKey(tonumber(s.key), i) }
            end
        end
    end

    return st
end

local function WriteState(ply)
    local st   = ply[STATE]
    local slot = ply.SHIBI_ActiveSlot
    if not st or not slot or st.loadFailed or not CanPersist(ply) then return end

    local slots = {}
    for i = 1, SLOT_COUNT do
        local s = st.slots[i]
        slots[i] = s and { id = s.id, key = s.key } or false
    end

    EnsureTable()
    sql.Query("REPLACE INTO " .. TABLE_NAME .. " (steamid, slot, data) VALUES (" ..
        sql.SQLStr(ply:SteamID64()) .. ", " .. math.floor(slot) .. ", " ..
        sql.SQLStr(util.TableToJSON({
            points     = st.points,
            categories = st.categories,
            unlocked   = st.unlocked,
            slots      = slots,
        }, false)) .. ")")
end

function A.HasCategory(ply, id)
    local st = IsValid(ply) and ply[STATE]
    return st ~= nil and st.categories[id] == true
end

function A.IsUnlocked(ply, id)
    local def = A.List[id]
    if not def or not def.category then return false end

    local st = IsValid(ply) and ply[STATE]
    return st ~= nil and st.unlocked[id] == true
end

function A.GetPoints(ply)
    local st = IsValid(ply) and ply[STATE]
    return st and st.points or 0
end

function A.GivePoints(ply, amount)
    local st = IsValid(ply) and ply[STATE]
    if not st then return false end
    st.points = math.max(0, st.points + math.floor(tonumber(amount) or 0))
    WriteState(ply)
    return true
end

function A.SetCategory(ply, id, grant)
    local st = IsValid(ply) and ply[STATE]
    if not st then return false, "nodata" end
    if not IsKnownCategory(id) then return false, "unknown" end

    if grant then
        st.categories[id] = true
    else
        st.categories[id] = nil
        for abilityId, def in pairs(A.List) do
            if def.category == id then
                st.unlocked[abilityId] = nil
            end
        end
        for i = 1, SLOT_COUNT do
            local s = st.slots[i]
            if s and not A.IsUnlocked(ply, s.id) then st.slots[i] = nil end
        end
    end

    WriteState(ply)
    return true
end

function A.Unlock(ply, id)
    local st = IsValid(ply) and ply[STATE]
    if not st then return false, "nodata" end
    if not IsKnownAbility(id) then return false, "unknown" end

    local def = A.List[id]
    if not def.category then return false, "nocategory" end
    if not st.categories[def.category] then return false, "category" end
    if st.unlocked[id] then return false, "owned" end

    local cost = Clamp16(def.unlockCost)
    if st.points < cost then return false, "points" end

    st.points = st.points - cost
    st.unlocked[id] = true
    WriteState(ply)
    return true
end

local function SendLoadout(ply)
    if not IsValid(ply) then return end
    local st = ply[STATE] or NewState()

    local catIds = table.GetKeys(A.Categories)
    table.sort(catIds)
    local catCount = math.min(#catIds, 255)

    local ids = table.GetKeys(A.List)
    table.sort(ids)
    local count = math.min(#ids, MAX_ABILITIES)

    net.Start(NET_LOAD)
        net.WriteUInt(catCount, 8)
        for i = 1, catCount do
            local c = A.Categories[catIds[i]]
            net.WriteString(catIds[i])
            net.WriteString(c.name or catIds[i])
            net.WriteBool(st.categories[catIds[i]] == true)
        end

        net.WriteUInt(count, 8)
        for i = 1, count do
            local id  = ids[i]
            local def = A.List[id]

            net.WriteString(id)
            net.WriteString(def.name or id)
            net.WriteString(def.description or "")
            net.WriteString(isstring(def.icon) and def.icon or "")
            net.WriteString(isstring(def.category) and def.category or "")
            net.WriteFloat(tonumber(def.cooldown) or 0)
            net.WriteUInt(Clamp16(def.cost), 16)
            net.WriteUInt(Clamp16(def.unlockCost), 16)
            net.WriteBool(A.IsUnlocked(ply, id))
        end

        net.WriteUInt(Clamp16(st.points), 16)

        for i = 1, SLOT_COUNT do
            local s  = st.slots[i]
            local ok = istable(s) and IsKnownAbility(s.id) and A.IsUnlocked(ply, s.id)
            net.WriteBool(ok)
            if ok then
                net.WriteString(s.id)
                net.WriteUInt(SanitizeKey(s.key, i), 8)
            end
        end
    net.Send(ply)
end

net.Receive(NET_SAVE, function(_, ply)
    local incoming = {}
    for i = 1, SLOT_COUNT do
        if net.ReadBool() then
            local id  = net.ReadString()
            local key = net.ReadUInt(8)
            if IsKnownAbility(id) and A.IsUnlocked(ply, id) then
                incoming[i] = { id = id, key = SanitizeKey(key, i) }
            end
        end
    end

    if not IsValid(ply) then return end
    local st = ply[STATE]
    if not st then return end

    local now = CurTime()
    if (ply._shibiNextAbilitySave or 0) > now then return end
    ply._shibiNextAbilitySave = now + SAVE_COOLDOWN

    local usedKeys, usedAbilities = {}, {}
    for i = SLOT_COUNT, 1, -1 do
        local s = incoming[i]
        if s then
            if usedKeys[s.key] or usedAbilities[s.id] then
                incoming[i] = nil
            else
                usedKeys[s.key] = true
                usedAbilities[s.id] = true
            end
        end
    end

    st.slots = incoming
    WriteState(ply)
end)

net.Receive(NET_UNLOCK, function(_, ply)
    local id = net.ReadString()
    if not IsValid(ply) then return end

    local now = CurTime()
    if (ply._shibiNextUnlock or 0) > now then return end
    ply._shibiNextUnlock = now + 0.2

    A.Unlock(ply, id)
    SendLoadout(ply)
end)

local function ClearCharacter(ply)
    ply[STATE] = nil
    ply.SHIBI_ActiveSlot = nil
end

function A.UnloadCharacter(ply)
    if not IsValid(ply) then return end
    WriteState(ply)
    ClearCharacter(ply)
    SendLoadout(ply)
end

function A.LoadCharacter(ply, slot)
    if not IsValid(ply) then return end
    if ply.SHIBI_ActiveSlot ~= slot then
        A.UnloadCharacter(ply)
    end
    ply.SHIBI_ActiveSlot = slot
    ply[STATE] = CanPersist(ply) and ReadState(ply:SteamID64(), slot) or NewState()
    SendLoadout(ply)
end

hook.Add("SHIBI::Character::Selected", "SHIBI::Abilities::Load", function(ply, slot)
    A.LoadCharacter(ply, slot)
end)

hook.Add("SHIBI::Character::SlotDeleted", "SHIBI::Abilities::Forget", function(ply, slot)
    if ply.SHIBI_ActiveSlot == slot then
        ClearCharacter(ply)
        SendLoadout(ply)
    end
    if CanPersist(ply) then
        EnsureTable()
        sql.Query("DELETE FROM " .. TABLE_NAME .. " WHERE steamid = " ..
            sql.SQLStr(ply:SteamID64()) .. " AND slot = " .. math.floor(slot))
    end
end)

hook.Add("PlayerDisconnected", "SHIBI::Abilities::Save", function(ply)
    WriteState(ply)
end)

hook.Add("PlayerInitialSpawn", "SHIBI::Abilities::Binds", function(ply)
    timer.Simple(1, function()
        if IsValid(ply) then SendLoadout(ply) end
    end)
end)

A.SendLoadout = SendLoadout

local function Reply(ply, msg)
    if IsValid(ply) then
        ply:PrintMessage(HUD_PRINTCONSOLE, "[Abilities] " .. msg .. "\n")
    else
        print("[Abilities] " .. msg)
    end
end

local function FindTarget(needle)
    if not needle or needle == "" then return nil end
    local lower = string.lower(needle)
    local found, count = nil, 0
    for _, p in ipairs(player.GetAll()) do
        if p:SteamID64() == needle or string.lower(p:Nick()) == lower then
            found = p
            count = count + 1
        end
    end
    if count ~= 1 then return nil end
    return found
end

local function CanAdmin(caller)
    return not IsValid(caller) or caller:IsSuperAdmin()
end

concommand.Add("shibi_ability_points", function(caller, _, args)
    if not CanAdmin(caller) then return end

    local amount = math.floor(tonumber(args[2]) or 0)
    if amount == 0 then
        Reply(caller, "использование: shibi_ability_points <ник|SteamID64> <кол-во>")
        return
    end

    local target = FindTarget(args[1])
    if not IsValid(target) or not target[STATE] then
        Reply(caller, "игрок не найден или персонаж не выбран")
        return
    end

    A.GivePoints(target, amount)
    SendLoadout(target)
    Reply(caller, target:Nick() .. ": очки изменены на " .. amount .. " (всего " .. A.GetPoints(target) .. ")")
end)

concommand.Add("shibi_ability_category", function(caller, _, args)
    if not CanAdmin(caller) then return end

    local catId = args[2]
    local grant = args[3] == "1"
    if not catId or (args[3] ~= "1" and args[3] ~= "0") then
        local ids = table.GetKeys(A.Categories)
        table.sort(ids)
        Reply(caller, "использование: shibi_ability_category <ник|SteamID64> <категория> <1|0>. Категории: " .. table.concat(ids, ", "))
        return
    end

    local target = FindTarget(args[1])
    if not IsValid(target) or not target[STATE] then
        Reply(caller, "игрок не найден или персонаж не выбран")
        return
    end

    local ok, reason = A.SetCategory(target, catId, grant)
    if not ok then
        Reply(caller, "ошибка: " .. tostring(reason))
        return
    end

    SendLoadout(target)
    Reply(caller, target:Nick() .. ": категория " .. catId .. (grant and " выдана" or " снята"))
end)

SHIBI.Log("[AbilitiesBinds] Модуль загружен")

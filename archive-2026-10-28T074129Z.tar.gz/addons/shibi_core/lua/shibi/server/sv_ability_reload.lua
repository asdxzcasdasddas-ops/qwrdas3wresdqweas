local A = SHIBI.Abilities

local REG_FILE    = "shibi/abilities/sh_ability_registry.lua"
local CHECK_DELAY = 1
local TIMER_NAME  = "SHIBI::Abilities::RegistryWatch"

local lastTime = file.Time(REG_FILE, "LUA") or 0

local function SyncCatalog()
    for id, def in pairs(A.List) do
        local meta = A.Catalog[id]
        if meta then
            for k, v in pairs(meta) do def[k] = v end
            def.cooldown = tonumber(def.cooldown) or 0
            def.cost     = tonumber(def.cost) or 0
        else
            A.List[id] = nil
            SHIBI.LogWarning("[Abilities] " .. id .. " удалена из реестра, снята со списка")
        end
    end

    for id in pairs(A.Catalog) do
        if not A.List[id] then
            SHIBI.LogWarning("[Abilities] " .. id .. " есть в реестре, но нет OnCast в list/sv_*.lua")
        end
    end
end

function A.ReloadRegistry()
    local ok, err = pcall(include, REG_FILE)
    if not ok then
        SHIBI.LogError("[Abilities] ошибка реестра, старые данные сохранены: " .. tostring(err))
        return false
    end

    SyncCatalog()

    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) then A.SendLoadout(ply) end
    end

    SHIBI.Log("[Abilities] реестр перезагружен")
    return true
end

timer.Create(TIMER_NAME, CHECK_DELAY, 0, function()
    local t = file.Time(REG_FILE, "LUA")
    if not t or t == 0 or t == lastTime then return end
    lastTime = t
    A.ReloadRegistry()
end)

util.AddNetworkString("SHIBI::Anim::Play")
util.AddNetworkString("SHIBI::Anim::Stop")
local Active = setmetatable({}, {__mode = "k"})

local function ApplyServerAnimation(ply, state)
    ply:AnimResetGestureSlot(SHIBI.Anim.Slot)
    ply:AddVCDSequenceToGestureSlot(SHIBI.Anim.Slot, state.sequence, 0, not state.loop)
    ply:AnimSetGestureWeight(SHIBI.Anim.Slot, SHIBI.Anim.Weight)

    if isfunction(ply.SetLayerPlaybackRate) then
        ply:SetLayerPlaybackRate(SHIBI.Anim.Slot, state.speed)
    end
end

function SHIBI.Anim.Play(ply, seq, speed, loop, targetDuration)
    if not IsValid(ply) or not ply:IsPlayer() or not isstring(seq) or seq == "" or #seq > 128 then
        return false
    end

    speed = tonumber(speed) or 1
    if speed ~= speed or speed == math.huge or speed == -math.huge then speed = 1 end
    speed = math.Clamp(speed, 0.05, 4)
    loop  = loop == true
    targetDuration = tonumber(targetDuration)
    if not targetDuration or targetDuration ~= targetDuration
        or targetDuration == math.huge or targetDuration == -math.huge
        or targetDuration <= 0 then
        targetDuration = nil
    else
        targetDuration = math.Clamp(targetDuration, 0.05, 10)
    end

    local sequence = ply:LookupSequence(seq)
    local serverCanPlay = sequence ~= nil and sequence >= 0
    if not serverCanPlay then
        sequence = nil
    end

    local baseDuration = serverCanPlay and tonumber(ply:SequenceDuration(sequence)) or nil
    local playbackRate = speed
    if targetDuration and baseDuration and baseDuration > 0 then
        playbackRate = math.Clamp(speed * baseDuration / targetDuration, 0.05, 4)
    end
    local duration = math.max(baseDuration or targetDuration or 0.75, 0.01) / playbackRate
    local generation = (ply.SHIBI_AnimGeneration or 0) + 1
    if generation > 2147483646 then generation = 1 end
    ply.SHIBI_AnimGeneration = generation

    local state = {
        name = seq,
        sequence = sequence,
        serverCanPlay = serverCanPlay,
        speed = playbackRate,
        targetDuration = targetDuration,
        loop = loop,
        duration = duration,
        generation = generation,
        endTime = CurTime() + duration,
    }
    Active[ply] = state
    if serverCanPlay then
        ApplyServerAnimation(ply, state)
    end

    net.Start("SHIBI::Anim::Play")
        net.WriteEntity(ply)
        net.WriteString(seq)
        net.WriteFloat(speed)
        net.WriteBool(loop)
        net.WriteUInt(generation, 32)
        net.WriteFloat(targetDuration or 0)
    net.Broadcast()
    return generation
end

function SHIBI.Anim.GetDuration(ply, expectedGeneration)
    local state = Active[ply]
    if not state then return nil end
    if expectedGeneration and state.generation ~= expectedGeneration then return nil end
    return state.duration, state.serverCanPlay
end

function SHIBI.Anim.Stop(ply, expectedGeneration)
    if not IsValid(ply) then return false end
    local state = Active[ply]
    if expectedGeneration and ply.SHIBI_AnimGeneration ~= expectedGeneration then
        return false
    end
    if expectedGeneration and state and state.generation ~= expectedGeneration then
        return false
    end

    local generation = (ply.SHIBI_AnimGeneration or 0) + 1
    if generation > 2147483646 then generation = 1 end
    ply.SHIBI_AnimGeneration = generation
    Active[ply] = nil
    ply:AnimResetGestureSlot(SHIBI.Anim.Slot)

    net.Start("SHIBI::Anim::Stop")
        net.WriteEntity(ply)
        net.WriteUInt(generation, 32)
    net.Broadcast()
    return true
end

hook.Add("PlayerDeath", "SHIBI::Anim::Stop", function(ply)
    SHIBI.Anim.Stop(ply)
end)
hook.Add("PlayerDisconnected", "SHIBI::Anim::Stop", function(ply) SHIBI.Anim.Stop(ply) end)

hook.Add("Think", "SHIBI::Anim::ServerLoop", function()
    local now = CurTime()
    for ply, state in pairs(Active) do
        if not IsValid(ply) then
            Active[ply] = nil
        elseif state.serverCanPlay and state.loop and now >= state.endTime then
            ApplyServerAnimation(ply, state)
            state.endTime = now + state.duration
        elseif not state.loop and now >= state.endTime then
            Active[ply] = nil
        end
    end
end)

SHIBI.Log("[Anim] sv_anim.lua загружен")

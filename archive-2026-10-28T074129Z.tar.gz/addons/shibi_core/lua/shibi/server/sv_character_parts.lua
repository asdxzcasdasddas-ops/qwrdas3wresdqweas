if not SERVER then return end

util.AddNetworkString("SHIBI::Character::Assemble")
util.AddNetworkString("SHIBI::Character::ClearHead")
util.AddNetworkString("SHIBI::Character::FadeIn")
util.AddNetworkString("SHIBI::Character::Activated")
util.AddNetworkString("SHIBI::Character::HairColor")

local VALID_GENDERS = {
    male = "Male",
    female = "Female",
}

local function RemoveHeadEntity(ply)
    if IsValid(ply.SHIBI_HeadEnt) then
        ply.SHIBI_HeadEnt:Remove()
    end
    ply.SHIBI_HeadEnt = nil
end

local function SanitizeColor(value)
    if not IsColor(value) then return Color(255, 255, 255) end
    return Color(
        math.Clamp(math.floor(tonumber(value.r) or 255), 0, 255),
        math.Clamp(math.floor(tonumber(value.g) or 255), 0, 255),
        math.Clamp(math.floor(tonumber(value.b) or 255), 0, 255),
        255
    )
end

function SHIBI.Character.Assemble(ply, gender, clothesIndex, faceIndex, hairStyle, hairColor, eyeStyle, height, flexes)
    if not IsValid(ply) then return false end

    gender = string.lower(tostring(gender or ""))
    local genderKey = VALID_GENDERS[gender]
    if not genderKey then return false end

    local parts = SHIBI.Character.GetParts(gender)
    if not parts or not util.IsValidModel(parts.Body) then return false end

    local bodyModel = parts.Body
    local clothes = SHIBI.Character.Clothes[genderKey] or {}
    local allowedClothes = {}
    for index, item in ipairs(clothes) do
        if item.faction == nil or item.faction == ply.SHIBI_PendingFaction then
            allowedClothes[#allowedClothes + 1] = {index = index, data = item}
        end
    end
    clothesIndex = math.floor(tonumber(clothesIndex) or 0)
    if clothesIndex < 1 or clothesIndex > #allowedClothes then return false end
    local selectedClothes = allowedClothes[clothesIndex]
    if not selectedClothes or not util.IsValidModel(selectedClothes.data.model) then return false end
    bodyModel = selectedClothes.data.model
    hairStyle = math.floor(tonumber(hairStyle) or -1)
    faceIndex = math.floor(tonumber(faceIndex) or 0)
    eyeStyle = math.floor(tonumber(eyeStyle) or -1)
    height = tonumber(height)
    if hairStyle < 0 or faceIndex < 1 or eyeStyle < 0 or not height or height ~= height or height == math.huge or height == -math.huge or height < 1.5 or height > 2.1 then
        return false
    end
    hairColor = SanitizeColor(hairColor)
    flexes = istable(flexes) and flexes or {}
    local headModel, validFaceIndex = SHIBI.Character.GetHeadModel(gender, faceIndex)
    if not headModel or validFaceIndex ~= faceIndex or not util.IsValidModel(headModel) then return false end

    ply:SetModel(bodyModel)
    ply:SetModelScale(height / 1.8, 0)

    RemoveHeadEntity(ply)

    local head = ents.Create("prop_dynamic")
    head:SetModel(headModel)
    head:SetPos(ply:GetPos())
    head:Spawn()
    head:SetParent(ply)
    head:AddEffects(EF_BONEMERGE)
    head:AddEffects(EF_FOLLOWBONE)
    head:SetMoveType(MOVETYPE_NONE)
    head:SetSolid(SOLID_NONE)
    head:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
    local hairVector = Vector(hairColor.r / 255, hairColor.g / 255, hairColor.b / 255)
    head:SetNWVector("SHIBI::HairColor", hairVector)
    head:SetModelScale(height / 1.8, 0)

    local hairGroup
    for i = 0, (head:GetNumBodyGroups() or 0) - 1 do
        if string.lower(head:GetBodygroupName(i) or "") == "hair" then
            hairGroup = i
            break
        end
    end
    if not hairGroup or hairStyle >= head:GetBodygroupCount(hairGroup) then
        head:Remove()
        return false
    end
    if eyeStyle >= (head:SkinCount() or 1) then
        head:Remove()
        return false
    end
    if ply.SHIBI_PendingFaction == "espada" and gender == "male" then
        for i = 0, (head:GetNumBodyGroups() or 0) - 1 do
            if string.lower(head:GetBodygroupName(i) or "") == "torse" and head:GetBodygroupCount(i) > 1 then
                head:SetBodygroup(i, 1)
                break
            end
        end
    end

    local boneIdx = ply:LookupBone("ValveBiped.Bip01_Head1")
    if boneIdx then
        head:SetParent(ply, boneIdx)
    end

    if hairStyle then
        for i = 0, (head:GetNumBodyGroups() or 0) - 1 do
            if string.lower(head:GetBodygroupName(i)) == "hair" then
                head:SetBodygroup(i, math.Clamp(hairStyle, 0, math.max(head:GetBodygroupCount(i) - 1, 0)))
            end
        end
    end

    if eyeStyle then
        head:SetSkin(math.Clamp(eyeStyle, 0, (head:SkinCount() or 1) - 1))
    end

    local appliedFlexes = {}
    local appliedCount = 0
    for name, value in pairs(flexes) do
        if appliedCount >= 32 then break end
        if isstring(name) and #name <= 64 then
            local id = head:GetFlexIDByName(name)
            value = tonumber(value)
            if id and value and value == value and value ~= math.huge and value ~= -math.huge then
                value = math.Clamp(value, 0, 1)
                head:SetFlexWeight(id, value)
                appliedFlexes[name] = value
                appliedCount = appliedCount + 1
            end
        end
    end

    ply.SHIBI_HeadEnt = head
    ply.SHIBI_HeadData = {
        gender = gender,
        clothes = clothesIndex,
        face = validFaceIndex,
        hair = hairStyle,
        hairColor = hairColor,
        eyes = eyeStyle,
        height = height,
        flexes = appliedFlexes,
    }
    net.Start("SHIBI::Character::HairColor")
        net.WriteEntity(head)
        net.WriteEntity(ply)
        net.WriteVector(hairVector)
    net.Broadcast()
    return true
end

function SHIBI.Character.ClearHead(ply, clearData)
    if not IsValid(ply) then return end
    RemoveHeadEntity(ply)
    if clearData then
        ply.SHIBI_HeadData = nil
    end
end

net.Receive("SHIBI::Character::Assemble", function(_, ply)
    local now = CurTime()
    if (ply.SHIBI_NextCharacterAssemble or 0) > now then return end
    ply.SHIBI_NextCharacterAssemble = now + 1

    local gender = net.ReadString()
    local faction = net.ReadString()
    local slot = net.ReadUInt(2)
    local firstName = string.Trim(net.ReadString())
    local lastName = string.Trim(net.ReadString())
    local clothes = net.ReadUInt(8)
    local face = net.ReadUInt(8)
    local hair = net.ReadUInt(8)
    local hairColor = net.ReadColor()
    local eyes = net.ReadUInt(8)
    local height = net.ReadFloat()
    local flexCount = math.min(net.ReadUInt(8), 32)
    local flexes = {}
    for _ = 1, flexCount do
        local name = net.ReadString()
        local value = net.ReadFloat()
        if isstring(name) and #name > 0 and #name <= 64 and value == value and value ~= math.huge and value ~= -math.huge then
            flexes[name] = value
        end
    end

    if not ({espada = true, shinigami = true})[faction] then return end
    if slot < 1 or slot > 3 or (slot == 3 and not (ply:IsAdmin() or ply:IsUserGroup("vip") or ply:IsUserGroup("VIP"))) then return end
    local function ValidName(value)
        local ok, result = pcall(function()
            local length = utf8.len(value)
            if value == "" or value:find("_", 1, true) or length < 5 or length > 24 then return false end
            local capitals = 0
            for _, codepoint in utf8.codes(value) do
                local isLatin = (codepoint >= 65 and codepoint <= 90) or (codepoint >= 97 and codepoint <= 122)
                local isCyrillic = (codepoint >= 0x410 and codepoint <= 0x44F) or codepoint == 0x401 or codepoint == 0x451
                if codepoint ~= 45 and not isLatin and not isCyrillic then return false end
                if (codepoint >= 65 and codepoint <= 90) or (codepoint >= 0x410 and codepoint <= 0x42F) or codepoint == 0x401 then
                    capitals = capitals + 1
                end
            end
            return capitals <= 2
        end)
        return ok and result == true
    end
    if not ValidName(firstName) or not ValidName(lastName) then return end
    local existing = sql.QueryRow("SELECT data FROM shibi_character_slots WHERE steamid = " ..
        sql.SQLStr(ply:SteamID64() or "0") .. " AND slot = " .. slot)
    if existing then return end
    ply.SHIBI_PendingSlot = slot
    ply.SHIBI_PendingFaction = faction
    if not SHIBI.Character.Assemble(ply, gender, clothes, face, hair, hairColor, eyes, height, flexes) then return end
    if not SHIBI.Character.SaveSlot then return end
    local characterData = {
            faction = faction,
            firstName = firstName,
            lastName = lastName,
            gender = gender,
            clothes = clothes,
            face = face,
            hair = hair,
            hairColor = {hairColor.r, hairColor.g, hairColor.b},
            eyes = eyes,
            height = height,
            flexes = flexes,
    }
    local saved = SHIBI.Character.SaveSlot(ply, ply.SHIBI_PendingSlot or 1, characterData, false)
    if not saved then
        return
    end
    ply:SetNWString("SHIBI::Character::FirstName", firstName)
    ply:SetNWString("SHIBI::Character::LastName", lastName)
    ply:SetNWString("SHIBI::Character::Name", firstName .. " " .. lastName)
    SHIBI.Character.Activate(ply, ply.SHIBI_PendingSlot or 1, characterData)
    timer.Simple(0, function()
        if not IsValid(ply) then return end
        ply:Spawn()
        net.Start("SHIBI::Character::Activated")
        net.Send(ply)
    end)
end)

hook.Add("PlayerDeath", "SHIBI::Character::CleanupHead", function(ply)
    SHIBI.Character.ClearHead(ply, false)
end)

hook.Add("PlayerSpawn", "SHIBI::Character::CleanupHead", function(ply)
    local data = ply.SHIBI_HeadData
    SHIBI.Character.ClearHead(ply, false)
    if data then
        timer.Simple(0, function()
            if not IsValid(ply) then return end
            SHIBI.Character.Assemble(ply,
                data.gender,
                data.clothes,
                data.face,
                data.hair,
                data.hairColor,
                data.eyes,
                data.height,
                data.flexes
            )
        end)
    end
end)

hook.Add("PlayerDisconnected", "SHIBI::Character::CleanupHead", function(ply)
    SHIBI.Character.ClearHead(ply, true)
end)

SHIBI.Log("[Character] sv_character_parts.lua загружен")

if not SERVER then return end

util.AddNetworkString("SHIBI::Character::Slots")
util.AddNetworkString("SHIBI::Character::RequestSlots")
util.AddNetworkString("SHIBI::Character::OpenCreator")
util.AddNetworkString("SHIBI::Character::DeleteSlot")
util.AddNetworkString("SHIBI::Character::SelectSlot")

local SLOT_COUNT = 3
local REQUEST_COOLDOWN = 0.5
local DELETE_COOLDOWN = 1

-- антиспам, потому что один умник уже спамил запросами слотов
local function RateLimited(ply, field, delay)
    local now = CurTime()
    if (ply[field] or 0) > now then return true end
    ply[field] = now + delay
    return false
end

local function CanUseVipSlot(ply)
    return IsValid(ply) and (ply:IsAdmin() or ply:IsUserGroup("vip") or ply:IsUserGroup("VIP"))
end

local function EnsureTable()
    sql.Query([[
        CREATE TABLE IF NOT EXISTS shibi_character_slots (
            steamid TEXT NOT NULL,
            slot INTEGER NOT NULL,
            data TEXT NOT NULL,
            PRIMARY KEY (steamid, slot)
        )
    ]]
)
end

local function GetSlots(ply)
    EnsureTable()
    local result = {}
    local steamid = ply:SteamID64() or "0"
    for slot = 1, SLOT_COUNT do
        if slot == 3 and not CanUseVipSlot(ply) then
            result[slot] = {locked = true}
        else
            local row = sql.QueryRow("SELECT data FROM shibi_character_slots WHERE steamid = " ..
                sql.SQLStr(steamid) .. " AND slot = " .. slot)
            local data = row and util.JSONToTable(row.data) or nil
            result[slot] = {locked = false, data = istable(data) and data or nil}
        end
    end
    return result
end

local function SendSlots(ply)
    if not IsValid(ply) then return end
    local slots = GetSlots(ply)
    net.Start("SHIBI::Character::Slots")
        net.WriteUInt(SLOT_COUNT, 2)
        for slot = 1, SLOT_COUNT do
            local info = slots[slot]
            net.WriteBool(info.locked)
            net.WriteBool(info.data ~= nil)
            if info.data then
                net.WriteString(util.TableToJSON(info.data, false) or "{}")
            end
        end
    net.Send(ply)
end

function SHIBI.Character.SendSlots(ply)
    SendSlots(ply)
end

function SHIBI.Character.SaveSlot(ply, slot, data, refreshSlots)
    if not IsValid(ply) or not isnumber(slot) or slot < 1 or slot > SLOT_COUNT then return false end
    if slot == 3 and not CanUseVipSlot(ply) then return false end
    EnsureTable()
    local steamid = ply:SteamID64() or "0"
    sql.Query("REPLACE INTO shibi_character_slots (steamid, slot, data) VALUES (" ..
        sql.SQLStr(steamid) .. ", " .. math.floor(slot) .. ", " .. sql.SQLStr(util.TableToJSON(data, false)) .. ")")
    if refreshSlots ~= false then
        SendSlots(ply)
    end
    return true
end

function SHIBI.Character.Activate(ply, slot, data)
    if not IsValid(ply) or not isnumber(slot) then return end
    hook.Run("SHIBI::Character::Selected", ply, slot)
    ply.SHIBI_ActiveCharacter = data
end

local function DeleteSlot(ply, slot)
    if not IsValid(ply) or not isnumber(slot) or slot < 1 or slot > SLOT_COUNT then return end
    if slot == 3 and not CanUseVipSlot(ply) then return end
    local steamid = ply:SteamID64() or "0"
    sql.Query("DELETE FROM shibi_character_slots WHERE steamid = " ..
        sql.SQLStr(steamid) .. " AND slot = " .. math.floor(slot))
    if ply.SHIBI_PendingSlot == slot then ply.SHIBI_PendingSlot = nil end
    hook.Run("SHIBI::Character::SlotDeleted", ply, slot)
    SendSlots(ply)
end

net.Receive("SHIBI::Character::SelectSlot", function(_, ply)
    if RateLimited(ply, "SHIBI_NextSlotSelect", REQUEST_COOLDOWN) then return end
    local slot = net.ReadUInt(2)
    local info = GetSlots(ply)[slot]
    if not info or info.locked then return end
    ply.SHIBI_PendingSlot = slot
    if info.data then
        local hairColor = info.data.hairColor
        if not istable(hairColor) then return end
        local r = math.floor(tonumber(hairColor[1]) or -1)
        local g = math.floor(tonumber(hairColor[2]) or -1)
        local b = math.floor(tonumber(hairColor[3]) or -1)
        if r < 0 or r > 255 or g < 0 or g > 255 or b < 0 or b > 255 then return end
        SHIBI.Character.Activate(ply, slot, info.data)
        ply.SHIBI_PendingFaction = info.data.faction
        ply:SetNWString("SHIBI::Character::FirstName", tostring(info.data.firstName or ""))
        ply:SetNWString("SHIBI::Character::LastName", tostring(info.data.lastName or ""))
        ply:SetNWString("SHIBI::Character::Name",
            tostring(info.data.firstName or "") .. " " .. tostring(info.data.lastName or ""))
        SHIBI.Character.Assemble(ply, info.data.gender, info.data.clothes, info.data.face,
            info.data.hair, Color(r, g, b),
            info.data.eyes, info.data.height, info.data.flexes)
        timer.Simple(0, function()
            if not IsValid(ply) then return end
            ply:Spawn()
            net.Start("SHIBI::Character::Activated")
            net.Send(ply)
        end)
        return
    end
    net.Start("SHIBI::Character::OpenCreator")
    net.WriteUInt(slot, 2)
    net.Send(ply)
end)

net.Receive("SHIBI::Character::RequestSlots", function(_, ply)
    if RateLimited(ply, "SHIBI_NextSlotsRequest", REQUEST_COOLDOWN) then return end
    SendSlots(ply)
end)

net.Receive("SHIBI::Character::DeleteSlot", function(_, ply)
    if RateLimited(ply, "SHIBI_NextSlotDelete", DELETE_COOLDOWN) then return end
    local slot = net.ReadUInt(2)
    DeleteSlot(ply, slot)
end)

hook.Add("PlayerInitialSpawn", "SHIBI::Character::SendSlots", function(ply)
    timer.Simple(1, function()
        if IsValid(ply) then SendSlots(ply) end
    end)
end)

local C = SHIBI.Cutscene
util.AddNetworkString(C.NET)

local serialCounter = 0
local Active = {}

local function Witnesses(origin, radius)
    local radiusSqr = radius * radius
    local list = {}

    for _, ply in ipairs(player.GetAll()) do
        if IsValid(ply) and ply:GetPos():DistToSqr(origin) <= radiusSqr then
            list[#list + 1] = ply
        end
    end

    return list
end

local function Start(key, origin, index, focusIndex, yaw, id, opts)
    local def = C.Scenes[id]
    if not def then
        SHIBI.LogError("[Cutscene] неизвестная сцена: " .. tostring(id))
        return false
    end

    local radius = tonumber(opts and opts.radius) or C.Radius
    local list = Witnesses(origin, radius)
    if #list == 0 then return false end

    serialCounter = serialCounter + 1
    if serialCounter > 4294967290 then serialCounter = 1 end
    local serial = serialCounter

    Active[key] = { serial = serial }

    net.Start(C.NET)
        net.WriteBool(true)
        net.WriteUInt(serial, 32)
        net.WriteUInt(index, 16)
        net.WriteUInt(focusIndex, 16)
        net.WriteString(id)
        net.WriteVector(origin)
        net.WriteFloat(yaw)
    net.Send(list)

    timer.Simple(def.duration + 0.1, function()
        C.Stop(key)
    end)

    return true
end

function C.Stop(key)
    local rec = Active[key]
    if not rec then return end
    Active[key] = nil

    net.Start(C.NET)
        net.WriteBool(false)
        net.WriteUInt(rec.serial, 32)
    net.Broadcast()
end

function C.Play(anchor, id, opts)
    if not IsValid(anchor) then return false end
    return Start(anchor, anchor:GetPos(), anchor:EntIndex(), 0, 0, id, opts)
end

function C.PlayAt(pos, yaw, id, opts)
    local token = {}
    local focus = opts and opts.focus
    local focusIndex = IsValid(focus) and focus:EntIndex() or 0
    local ok = Start(token, pos, 0, focusIndex, yaw or 0, id, opts)
    return ok, token
end

hook.Add("PlayerDisconnected", "SHIBI::Cutscene", function(ply)
    C.Stop(ply)
end)

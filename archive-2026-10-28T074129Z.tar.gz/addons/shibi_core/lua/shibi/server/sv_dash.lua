if not SERVER then return end

local NET_DASH = "SHIBI::Dash::Request"

-- рывок. ДЭШ. кто дэшил — тот в курсе
util.AddNetworkString(NET_DASH)

local states = setmetatable({}, {__mode = "k"})
local BELL_NORMALIZATION = {[1] = 6, [2] = 30, [3] = 140, [4] = 630}

local function GetSharedConfig()
    local dash = SHIBI.Dash
    local config = dash and dash.Config
    local weaponConfig = config and config.TestWeapon
    if not istable(config) or not istable(weaponConfig) or weaponConfig.Enabled ~= true then
        return nil
    end
    return config, weaponConfig
end

local function GetNumber(tbl, key, fallback, minimum, maximum)
    local value = tonumber(tbl and tbl[key])
    if not value or value ~= value or value == math.huge or value == -math.huge then
        value = fallback
    end
    return math.Clamp(value, minimum, maximum)
end

local function GetState(ply)
    local state = states[ply]
    if state then return state end

    state = {
        nextDash = 0,
        nextDoubleJump = 0,
        doubleJumpAvailable = true,
        airDashAvailable = true,
        dash = nil,
        lastRequest = 0,
    }
    states[ply] = state
    return state
end

local function IsDashWeaponClass(sharedConfig, class)
    if not isstring(class) or class == "" then return false end
    local list = sharedConfig.DashWeaponClasses
    if istable(list) then return list[class] == true end
    return class == sharedConfig.TestWeaponClass
end

local function GetDashWeapon(ply)
    local sharedConfig, weaponConfig = GetSharedConfig()
    if not sharedConfig then return nil end
    local weapon = ply:GetActiveWeapon()
    if not IsValid(weapon) then return nil end
    if not IsDashWeaponClass(sharedConfig, weapon:GetClass()) then return nil end
    return weapon, weaponConfig
end

local function CanMove(ply)
    if not IsValid(ply) or not ply:IsPlayer() or not ply:Alive() then return false end
    if ply:IsBot() or ply:IsFrozen() or ply:IsFlagSet(FL_FROZEN) then return false end
    if ply:InVehicle() or ply:GetMoveType() == MOVETYPE_NOCLIP then return false end
    if ply:WaterLevel() >= 2 then return false end
    if ply:IsFlagSet(FL_ATCONTROLS) then return false end
    if SHIBI.IsStunned and SHIBI.IsStunned(ply) then return false end
    return true
end

local function SpendStamina(ply, cost)
    if cost <= 0 then return true end
    return SHIBI.Stamina
        and isfunction(SHIBI.Stamina.TrySpend)
        and SHIBI.Stamina.TrySpend(ply, cost) == true
end

local function GetDashDirection(ply, code, sharedConfig)
    local selected = sharedConfig.DirectionCodes and sharedConfig.DirectionCodes[code]
    if not istable(selected) then return nil end
    local forwardInput = GetNumber(selected, "forward", 0, -1, 1)
    local sideInput = GetNumber(selected, "side", 0, -1, 1)
    local animation = selected.animation
    if math.abs(forwardInput) < 0.5 and math.abs(sideInput) < 0.5 then return nil end
    if not isstring(animation) or animation == "" then return nil end

    local yaw = Angle(0, ply:EyeAngles().y, 0)
    local forward = yaw:Forward()
    local right = yaw:Right()
    local direction = forward * forwardInput + right * sideInput
    direction.z = 0
    if direction:LengthSqr() <= 0 then return nil end
    direction:Normalize()

    return direction, animation
end

local function StartDash(ply, directionCode)
    local weapon, config = GetDashWeapon(ply)
    if not weapon or not CanMove(ply) then return end

    local state = GetState(ply)
    local now = CurTime()
    if state.dash then return end

    local sharedConfig = SHIBI.Dash.Config
    local onGround = ply:OnGround()
    local movement = config.Movement or {}
    local cooldown = onGround
        and GetNumber(movement, "GroundCooldown", 0.9, 0.2, 5)
        or GetNumber(movement, "AirCooldown", 0.65, 0.2, 5)
    if now < state.nextDash then return end
    if not onGround and movement.OneAirDash ~= false and not state.airDashAvailable then return end

    local direction, animationKey = GetDashDirection(ply, directionCode, sharedConfig)
    if not direction then return end

    local animations = config.Animations or {}
    local animationConfig = config.Animation or {}
    local defaultSpeed = GetNumber(animationConfig, "DashSpeed", 1, 0.05, 4)
    local animation, animationSpeed, animationDuration = SHIBI.Anim.Resolve(animations[animationKey], defaultSpeed)
    if not animation then return end
    local duration = GetNumber(movement, "Duration", 0.38, 0.12, 0.8)
    local averageSpeed = GetNumber(movement, "AverageSpeed", 530, 200, 1000)
    local animationOneShot = animationConfig.OneShot ~= false
    if not isfunction(ply.SetAnim) then return end
    local staminaConfig = config.Stamina or {}
    local staminaCost = GetNumber(staminaConfig, "DashCost", 18, 0, 120)
    if not SpendStamina(ply, staminaCost) then return end

    local curveName = movement.Curve
    if curveName ~= "smoothstep" and curveName ~= "smooth_bell" then curveName = "ue5" end
    local maxPeakSpeed = GetNumber(movement, "MaxPeakSpeed", 1100, 250, 1600)
    local attack = GetNumber(movement, "AttackFraction", 0.12, 0.05, 0.4)
    local exitSpeed = GetNumber(movement, "ExitSpeed", 260, 0, averageSpeed)
    local currentVelocity = ply:GetVelocity()
                                                                                   
    local entrySpeed = math.Clamp(currentVelocity:Dot(direction), 0, averageSpeed)
                                                                                   
    local peak = (averageSpeed - attack * entrySpeed / 3 - (1 - attack) * 2 * exitSpeed / 3) / ((1 + attack) / 3)
    peak = math.Clamp(peak, math.max(averageSpeed, entrySpeed, exitSpeed), maxPeakSpeed)

    local air = config.Air or {}
    local ground = config.Ground or {}
    state.dash = {
        direction = direction,
        averageSpeed = averageSpeed,
        started = now,
        duration = duration,
        animationOneShot = animationOneShot,
        curve = curveName,
        smoothness = math.floor(GetNumber(movement, "Smoothness", 2, 1, 4) + 0.5),
        maxPeakSpeed = maxPeakSpeed,
        attack = attack,
        entrySpeed = entrySpeed,
        exitSpeed = exitSpeed,
        peak = peak,
        compensateFriction = movement.CompensateFriction ~= false,
                                                                 
        airControl = not onGround,
        vz = math.Clamp(currentVelocity.z,
            -GetNumber(air, "MaxFall", 250, 0, 2000),
            GetNumber(air, "MaxRise", 40, 0, 500)),
        gravityStart = GetNumber(air, "GravityScale", 0.25, 0, 1),
        snapToGround = ground.SnapToGround ~= false,
        snapDistance = GetNumber(ground, "SnapDistance", 18, 0, 64),
    }
    state.nextDash = now + cooldown
    if not onGround and movement.OneAirDash ~= false then
        state.airDashAvailable = false
    end

    ply:SetNW2Bool("SHIBI::Dash::Active", true)

    local generation = ply:SetAnim(animation, animationSpeed, not animationOneShot, animationDuration)
    if not generation then
        state.dash = nil
        state.nextDash = now
        if not ply:OnGround() then state.airDashAvailable = true end
        if SHIBI.Stamina and SHIBI.Stamina.Add then SHIBI.Stamina.Add(ply, staminaCost) end
        ply:SetNW2Bool("SHIBI::Dash::Active", false)
        return
    end
    state.dash.animationGeneration = generation

    local entry = animations[animationKey]
    local lock = istable(entry) and tonumber(entry.lock) or nil
    if not lock then
        local clipDuration = SHIBI.Anim.GetDuration and SHIBI.Anim.GetDuration(ply, generation)
        lock = (clipDuration or duration) + GetNumber(animationConfig, "TurnLockExtra", 0.05, 0, 1)
    end
    local lockMin = GetNumber(animationConfig, "TurnLockMin", 0.7, 0, 3)
    lock = math.Clamp(math.max(lock, duration, lockMin), 0, GetNumber(animationConfig, "TurnLockMax", 2, 0.1, 5))
    ply:SetNW2Float("SHIBI::Dash::TurnLockUntil", now + lock)
end

net.Receive(NET_DASH, function(_, ply)
    local directionCode = net.ReadUInt(3)
    if directionCode < 0 or directionCode > 7 then return end
    if not IsValid(ply) then return end
    local state = GetState(ply)
    local now = CurTime()
    local sharedConfig = GetSharedConfig()
    if not sharedConfig then return end
    local security = sharedConfig.Security or {}
    local requestGuard = GetNumber(security, "RequestGuard", 0.12, 0.12, 1)
    if now - state.lastRequest < requestGuard then return end
    state.lastRequest = now

    StartDash(ply, directionCode)
end)

local cvGravity = GetConVar("sv_gravity")
local cvFriction = GetConVar("sv_friction")
local JUMP_AND_MOVE = bit.bor(IN_FORWARD, IN_BACK, IN_MOVELEFT, IN_MOVERIGHT, IN_JUMP)

local function EaseOutQuad(x) return 1 - (1 - x) * (1 - x) end

local function DashSpeedAt(dash, progress)
    if dash.curve == "smoothstep" then
        return dash.averageSpeed * 6 * progress * (1 - progress)
    elseif dash.curve == "smooth_bell" then
        local power = math.Clamp(dash.smoothness or 2, 1, 4)
        return dash.averageSpeed * BELL_NORMALIZATION[power] * progress ^ power * (1 - progress) ^ power
    end

    local a = dash.attack
    if progress < a then
        return dash.entrySpeed + (dash.peak - dash.entrySpeed) * EaseOutQuad(progress / a)
    end
    local u = (progress - a) / (1 - a)
    return dash.exitSpeed + (dash.peak - dash.exitSpeed) * (1 - u) * (1 - u)
end

local function GetGravity(ply)
    local scale = ply:GetGravity()
    if not scale or scale == 0 then scale = 1 end
    return (cvGravity and cvGravity:GetFloat() or 600) * scale
end

local function EndDash(ply, state, dash, cancelled)
    if cancelled and dash.animationGeneration then
        ply:ResetAnim(dash.animationGeneration)
    elseif not dash.animationOneShot and dash.animationGeneration then
        ply:ResetAnim(dash.animationGeneration)
    end
    state.dash = nil
                                                                                  
    state.jumpLatch = ply:KeyDown(IN_JUMP)
    ply:SetNW2Bool("SHIBI::Dash::Active", false)
    if cancelled then ply:SetNW2Float("SHIBI::Dash::TurnLockUntil", 0) end
end

hook.Add("SetupMove", "SHIBI::Dash::Movement", function(ply, move)
    if not IsValid(ply) then return end
    local state = states[ply]
    if not state then return end

    if ply:OnGround() then
        state.doubleJumpAvailable = true
        state.airDashAvailable = true
    end

    if state.jumpLatch then
        if move:KeyDown(IN_JUMP) then
            move:SetButtons(bit.band(move:GetButtons(), bit.bnot(IN_JUMP)))
        else
            state.jumpLatch = nil
        end
    end

    local dash = state.dash
    if not dash then return end

    if not CanMove(ply) or not GetDashWeapon(ply) then
        EndDash(ply, state, dash, true)
        return
    end

    local progress = math.Clamp((CurTime() - dash.started) / dash.duration, 0, 1)
    if progress >= 1 then
                                                                               
        EndDash(ply, state, dash, false)
        return
    end

    local dt = FrameTime()
    local onGround = ply:OnGround()
    dash.tickOnGround = onGround

    if onGround and dash.airControl then dash.airControl = false end

    local dashSpeed = math.min(DashSpeedAt(dash, progress), dash.maxPeakSpeed or 1100)

    if onGround and dash.compensateFriction then
        local friction = (cvFriction and cvFriction:GetFloat() or 8) * math.max(ply:GetFriction(), 0)
        local keep = 1 - friction * dt
        if keep > 0.25 then dashSpeed = dashSpeed / keep end
    end

    local velocity = move:GetVelocity()
    local horizontal = dash.direction * dashSpeed
    local vz = velocity.z

    if dash.airControl then

        local gravity = GetGravity(ply)
        local scale = Lerp(progress * progress, dash.gravityStart, 1)
        dash.vz = dash.vz - gravity * scale * dt
        dash.gravity = gravity

        vz = dash.vz + 0.5 * gravity * dt
    end

    move:SetVelocity(Vector(horizontal.x, horizontal.y, vz))
    move:SetButtons(bit.band(move:GetButtons(), bit.bnot(JUMP_AND_MOVE)))
end)

hook.Add("FinishMove", "SHIBI::Dash::Vertical", function(ply, move)
    local state = states[ply]
    local dash = state and state.dash
    if not dash then return end

    local velocity = move:GetVelocity()

    if dash.airControl and dash.vz then
                                                                     
        velocity.z = dash.vz
        move:SetVelocity(velocity)
        return
    end

    if dash.tickOnGround and velocity.z > 0 then
        velocity.z = 0
        move:SetVelocity(velocity)

        if dash.snapToGround and dash.snapDistance > 0 then
            local origin = move:GetOrigin()
            local mins, maxs
            if ply:Crouching() then mins, maxs = ply:GetHullDuck() else mins, maxs = ply:GetHull() end
            local tr = util.TraceHull({
                start = origin,
                endpos = origin - Vector(0, 0, dash.snapDistance),
                mins = mins,
                maxs = maxs,
                filter = ply,
                mask = MASK_PLAYERSOLID,
            })
            if tr.Hit and not tr.StartSolid and tr.HitNormal.z >= 0.7 then
                move:SetOrigin(tr.HitPos)
                if IsValid(tr.Entity) or tr.HitWorld then
                    ply:SetGroundEntity(tr.Entity)
                end
            end
        end
    end
end)

hook.Add("KeyPress", "SHIBI::Dash::DoubleJump", function(ply, key)
    if key ~= IN_JUMP or not CanMove(ply) or ply:OnGround() then return end
    if not GetDashWeapon(ply) then return end

    local state = GetState(ply)
    local now = CurTime()
    if not state.doubleJumpAvailable or now < state.nextDoubleJump then return end
    if state.dash then return end

    local _, config = GetDashWeapon(ply)
    if not config then return end
    local doubleJump = config.DoubleJump or {}
    if doubleJump.Enabled == false then return end
    local animations = config.Animations or {}
    local animationConfig = config.Animation or {}
    local defaultJumpSpeed = GetNumber(animationConfig, "DoubleJumpSpeed", 1, 0.05, 4)
    local jumpEntry = animations.double_jump or doubleJump.Animation or config.DoubleJumpAnimation or "h_jump"
    local jumpAnimation, jumpSpeed, jumpDuration = SHIBI.Anim.Resolve(jumpEntry, defaultJumpSpeed)
    if not jumpAnimation or not isfunction(ply.SetAnim) then return end
    local cost = GetNumber(doubleJump, "StaminaCost", 25, 0, 120)
    if not SpendStamina(ply, cost) then return end

    local velocity = ply:GetVelocity()
    local jumpVelocity = GetNumber(doubleJump, "Velocity", 450, 250, 700)
    local generation = ply:SetAnim(jumpAnimation, jumpSpeed, false, jumpDuration)
    if not generation then
        if SHIBI.Stamina and SHIBI.Stamina.Add then SHIBI.Stamina.Add(ply, cost) end
        return
    end
    ply:SetVelocity(Vector(0, 0, math.max(jumpVelocity - velocity.z, 0)))

    state.doubleJumpAvailable = false
    state.nextDoubleJump = now + GetNumber(doubleJump, "Cooldown", 0.25, 0.15, 1)
end)

hook.Add("PlayerSpawn", "SHIBI::Dash::Reset", function(ply)
    states[ply] = {
        nextDash = 0,
        nextDoubleJump = 0,
        doubleJumpAvailable = true,
        airDashAvailable = true,
        dash = nil,
        lastRequest = 0,
        jumpLatch = nil,
    }
    ply:SetNW2Bool("SHIBI::Dash::Active", false)
    ply:SetNW2Float("SHIBI::Dash::TurnLockUntil", 0)
end)

hook.Add("PlayerDeath", "SHIBI::Dash::Clear", function(ply)
    local state = states[ply]
    if state then state.dash = nil end
    if IsValid(ply) then
        ply:SetNW2Bool("SHIBI::Dash::Active", false)
        ply:SetNW2Float("SHIBI::Dash::TurnLockUntil", 0)
    end
end)

hook.Add("PlayerDisconnected", "SHIBI::Dash::Cleanup", function(ply)
    states[ply] = nil
end)

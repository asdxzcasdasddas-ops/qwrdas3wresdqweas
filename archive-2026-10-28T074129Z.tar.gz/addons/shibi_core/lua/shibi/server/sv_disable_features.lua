if not GM then
    GM = GAMEMODE or {}
end

function GM:PlayerSpray()
    return false
end

function GM:PlayerShouldTaunt(ply, actId)
    return false
end

function GM:CanDrive(ply, ent)
    return false
end

for id, entry in pairs(SHIBI.FontFiles) do
    if file.Exists(entry.path, "GAME") then
        resource.AddSingleFile(entry.path)
        SHIBI.Log("[Fonts] Раздаём шрифт '" .. id .. "': " .. entry.path)
    else
        SHIBI.LogWarning("[Fonts] Файл шрифта не найден: " .. entry.path)
    end
end

local HM   = SHIBI.HitMarkers
local TYPE = HM.TYPE

util.AddNetworkString(HM.NET)

HM.ServerConfig = HM.ServerConfig or {
    OnlyCombatTargets = true,
    AbilityIsSpecial  = true,
    ShowSelfDamage    = false,
    MinDamage         = 1,
}
local cfg = HM.ServerConfig

local Queue = setmetatable({}, { __mode = "k" })
local dirty = false

local function IsCombatTarget(ent)
    return ent:IsPlayer() or ent:IsNPC() or ent:IsNextBot()
end

local function AnchorPos(ent, out)
    out:Set(ent:GetPos())
    out.z = out.z + ent:OBBMaxs().z
    return out
end

function HM.Send(attacker, victim, amount, hitType, pos)
    if not (IsValid(attacker) and attacker:IsPlayer()) then return false end

    amount = math.Clamp(math.Round(tonumber(amount) or 0), 0, HM.MAX_DAMAGE)
    if amount < cfg.MinDamage then return false end

    local q = Queue[attacker]
    if not q then
        q = { count = 0 }
        Queue[attacker] = q
    end
    if q.count >= HM.MAX_PER_FLUSH then return false end

    local i = q.count + 1
    q.count = i

    local e = q[i]
    if not e then
        e = { pos = Vector() }
        q[i] = e
    end

    e.ent    = IsValid(victim) and victim or NULL
    e.amount = amount
    e.type   = hitType or TYPE.NORMAL

    if isvector(pos) then
        e.pos:Set(pos)
    elseif IsValid(victim) then
        AnchorPos(victim, e.pos)
    else
        e.pos:Set(attacker:GetPos())
    end

    dirty = true
    return true
end

local function ResolveType(attacker, victim, dmg)
    local hitType = HM.CustomToType[dmg:GetDamageCustom()]

    if hitType == nil and cfg.AbilityIsSpecial
        and SHIBI.Abilities and SHIBI.Abilities.IsCasting
        and SHIBI.Abilities.IsCasting(attacker) then
        hitType = TYPE.SPECIAL
    end

    hitType = hitType or TYPE.NORMAL

    local override = hook.Run("SHIBI.HitMarker.Resolve", attacker, victim, dmg, hitType)
    if override == false then return nil end
    return override or hitType
end

hook.Add("PostEntityTakeDamage", "SHIBI::HitMarker::Collect", function(victim, dmg, took)
    if not took or not IsValid(victim) then return end

    local attacker = dmg:GetAttacker()
    if not (IsValid(attacker) and attacker:IsPlayer()) then return end
    if victim == attacker and not cfg.ShowSelfDamage then return end
    if cfg.OnlyCombatTargets and not IsCombatTarget(victim) then return end

    local hitType = ResolveType(attacker, victim, dmg)
    if hitType == nil then return end

    HM.Send(attacker, victim, dmg:GetDamage(), hitType)
end)

hook.Add("Think", "SHIBI::HitMarker::Flush", function()
    if not dirty then return end
    dirty = false

    for ply, q in pairs(Queue) do
        if q.count > 0 then
            if IsValid(ply) then
                net.Start(HM.NET)
                    net.WriteUInt(q.count, 6)
                    for i = 1, q.count do
                        local e = q[i]
                        net.WriteEntity(e.ent)
                        net.WriteUInt(e.amount, HM.DAMAGE_BITS)
                        net.WriteUInt(e.type, HM.TYPE_BITS)
                        net.WriteVector(e.pos)
                        e.ent = NULL
                    end
                net.Send(ply)
            end
            q.count = 0
        end
    end
end)

hook.Add("PlayerDisconnected", "SHIBI::HitMarker::Cleanup", function(ply)
    Queue[ply] = nil
end)

concommand.Add("shibi_hitmarker_test", function(ply)
    if not IsValid(ply) or not ply:IsSuperAdmin() then return end

    local target = SHIBI.FindAimTarget(ply, 1500, 12, 0.8)
    local pos = not IsValid(target) and ply:GetEyeTrace().HitPos or nil

    local seq = {
        { 0.00, 124,   TYPE.NORMAL },
        { 0.12, 131,   TYPE.NORMAL },
        { 0.24, 118,   TYPE.NORMAL },
        { 0.45, 587,   TYPE.CRIT },
        { 0.90, 12450, TYPE.SPECIAL },
    }
    for _, s in ipairs(seq) do
        timer.Simple(s[1], function()
            if IsValid(ply) then HM.Send(ply, target, s[2], s[3], pos) end
        end)
    end
end)

SHIBI.Log("[HitMarkers] Серверная часть загружена")

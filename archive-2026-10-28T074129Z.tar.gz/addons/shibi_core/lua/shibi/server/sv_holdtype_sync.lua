if not SERVER then return end

local MOVE_EPSILON = 8
local UPDATE_EPSILON = 0.5
local PROFILE_NET = "SHIBI::HoldType::Profile"

util.AddNetworkString(PROFILE_NET)

concommand.Remove("shibi_holdtype_rate")
concommand.Remove("shibi_holdtype_sequence")

local function EncodeProfile(profile)
    local encoded = {
        playback_rate = profile.playback_rate,
        speed_scale = profile.speed_scale,
        states = {},
    }
    for _, state in ipairs({
        "idle", "walk", "run", "sprint", "jump", "land", "crouch_idle", "crouch_walk",
    }) do
        local data = profile[state]
        if istable(data) then
            local sequences = {}
            for _, name in ipairs(data) do sequences[#sequences + 1] = name end
            encoded.states[state] = {
                sequences = sequences,
                playback_rate = data.playback_rate,
            }
        end
    end
    return encoded
end

local function SendProfile(name, profile, recipient)
    local payload = util.TableToJSON(EncodeProfile(profile), false)
    if not payload or #payload > 60000 then
        SHIBI.LogWarning("[HoldType] Профиль слишком большой для синхронизации: " .. tostring(name))
        return false
    end

    net.Start(PROFILE_NET)
        net.WriteString(name)
        net.WriteString(payload)
    if IsValid(recipient) then
        net.Send(recipient)
    else
        net.Broadcast()
    end
    return true
end

SHIBI.HoldType.SyncProfile = SendProfile

hook.Add("PlayerInitialSpawn", "SHIBI::HoldType::SendProfiles", function(ply)
    timer.Simple(2, function()
        if not IsValid(ply) then return end
        for name, profile in pairs(SHIBI.HoldType.Registry) do
            SendProfile(name, profile, ply)
        end
    end)
end)

local function UpdateVisualYaw(ply)
    if not IsValid(ply) or not ply:Alive() then return end

    local velocity = ply:GetVelocity()
    local yaw = ply:EyeAngles().y
    local dashing = SHIBI.HoldType.IsBodyTurnBlocked(ply)
    if not dashing and velocity:Length2D() > MOVE_EPSILON and ply:OnGround() then
        yaw = velocity:Angle().y
    end

    local previous = ply:GetNW2Float("SHIBI::HoldType::VisualYaw", yaw)
    if math.abs(math.AngleDifference(previous, yaw)) < UPDATE_EPSILON then return end

    ply:SetNW2Float("SHIBI::HoldType::VisualYaw", math.NormalizeAngle(yaw))
end

hook.Add("Think", "SHIBI::HoldType::NetworkVisualYaw", function()
    for _, ply in ipairs(player.GetAll()) do
        UpdateVisualYaw(ply)
    end
end)

hook.Add("PlayerSpawn", "SHIBI::HoldType::ResetVisualYaw", function(ply)
    ply:SetNW2Float("SHIBI::HoldType::VisualYaw", ply:EyeAngles().y)
end)

SHIBI.DMG_CUSTOM = SHIBI.DMG_CUSTOM or {}
SHIBI.DMG_CUSTOM.OWNED_VIA_ENTITY = SHIBI.DMG_CUSTOM.OWNED_VIA_ENTITY or 424243
SHIBI.DMG_CUSTOM.ABILITY = SHIBI.DMG_CUSTOM.ABILITY or 424244

function SHIBI.DealDamage(victim, amount, attacker, opt)
    if not IsValid(victim) or victim:Health() <= 0 then return 0 end
    if victim:IsPlayer() and (not victim:Alive() or victim:HasGodMode()) then return 0 end
    amount = tonumber(amount)
    if not amount or amount ~= amount or amount <= 0 or amount == math.huge then return 0 end

    attacker = IsValid(attacker) and attacker or game.GetWorld()

    local before = victim:Health()
    victim:TakeDamage(math.ceil(amount), attacker)
    return math.max(0, before - victim:Health())
end

function SHIBI.DealDamageNoKnock(victim, amount, attacker, opt)
    if not IsValid(victim) or victim:Health() <= 0 then return 0 end
    if victim:IsPlayer() and (not victim:Alive() or victim:HasGodMode()) then return 0 end
    amount = tonumber(amount)
    if not amount or amount ~= amount or amount <= 0 or amount == math.huge then return 0 end

    attacker = IsValid(attacker) and attacker or game.GetWorld()
    opt = opt or {}

    local before   = victim:Health()
    local oldVel   = victim:GetVelocity()
    local oldGround = victim.GetGroundEntity and victim:GetGroundEntity() or nil
    local hadFlag  = victim.IsEFlagSet and victim:IsEFlagSet(EFL_NO_DAMAGE_FORCES) or false

    if victim.AddEFlags then victim:AddEFlags(EFL_NO_DAMAGE_FORCES) end

    local pos = opt.pos
    if not isvector(pos) then
        pos = IsValid(attacker) and attacker.WorldSpaceCenter and attacker:WorldSpaceCenter()
            or victim:WorldSpaceCenter()
    end

    local di = DamageInfo()
    di:SetDamage(math.ceil(amount))
    di:SetAttacker(attacker)
    di:SetDamageType(opt.type or DMG_CLUB)
    di:SetDamageCustom(opt.custom or SHIBI.DMG_CUSTOM.ABILITY)
    di:SetReportedPosition(pos)
    di:SetDamagePosition(pos)
    di:SetDamageForce(vector_origin)

    victim:TakeDamageInfo(di)

    if not hadFlag and victim.RemoveEFlags then victim:RemoveEFlags(EFL_NO_DAMAGE_FORCES) end
    if victim:GetVelocity() ~= oldVel then
        if victim:IsPlayer() then
            victim:SetVelocity(oldVel - victim:GetVelocity())
        else
            victim:SetVelocity(oldVel)
        end
    end
    if IsValid(oldGround) and victim.SetGroundEntity then victim:SetGroundEntity(oldGround) end

    return math.max(0, before - victim:Health())
end

function takedamage(ply, amount, attacker)
    if not IsValid(ply) then return 0 end
    local fn = SHIBI and SHIBI.DealDamageNoKnock
    if not isfunction(fn) then return 0 end
    return fn(ply, amount, attacker)
end

SHIBI.Stun = SHIBI.Stun or {}

function SHIBI.StunPlayer(ply, time, opt)
    if not IsValid(ply) or not ply:IsPlayer() then return nil end
    time = tonumber(time) or 1
    if time <= 0 then return nil end

    local token = {}
    SHIBI.Stun[ply] = SHIBI.Stun[ply] or {}
    local list = SHIBI.Stun[ply]

    local entry = {
        token = token,
        expires = CurTime() + time,
        opt = opt or {},
    }
    list[token] = entry

    timer.Create("SHIBI_Stun_" .. ply:EntIndex() .. "_" .. tostring(token), time, 1, function()
        if not IsValid(ply) then return end
        local cur = SHIBI.Stun[ply]
        if not cur or not cur[token] then return end
        cur[token] = nil
        if next(cur) == nil then SHIBI.Stun[ply] = nil end
    end)

    return token
end

function SHIBI.UnstunPlayer(ply, token)
    if not IsValid(ply) or not ply:IsPlayer() then return false end
    local list = SHIBI.Stun[ply]
    if not list then return false end

    local function clearOne(tok)
        list[tok] = nil
        timer.Remove("SHIBI_Stun_" .. ply:EntIndex() .. "_" .. tostring(tok))
    end

    if token ~= nil then
        if not list[token] then return false end
        clearOne(token)
    else
        for tok in pairs(list) do clearOne(tok) end
    end

    if next(list) == nil then SHIBI.Stun[ply] = nil end
    return true
end

function SHIBI.IsStunned(ply)
    if not IsValid(ply) or not ply:IsPlayer() then return false end
    local list = SHIBI.Stun[ply]
    if not list then return false end
    local now = CurTime()
    local any = false
    for tok, entry in pairs(list) do
        if entry.expires and entry.expires <= now then
            list[tok] = nil
        else
            any = true
        end
    end
    if next(list) == nil then SHIBI.Stun[ply] = nil end
    return any
end

hook.Add("SetupMove", "SHIBI.Stun.BlockMove", function(ply, mv, cmd)
    if not IsValid(ply) or not SHIBI.IsStunned(ply) then return end
    mv:SetForwardSpeed(0)
    mv:SetSideSpeed(0)
    mv:SetUpSpeed(0)
    mv:SetMaxSpeed(0)
    mv:SetMaxClientSpeed(0)
    if mv.SetButtons then mv:SetButtons(bit.band(mv:GetButtons(), bit.bnot(IN_JUMP))) end
    if mv.SetImpulse then mv:SetImpulse(0) end
    ply:SetVelocity(vector_origin)
end)

hook.Add("PlayerDeath", "SHIBI.Stun.ClearOnDeath", function(ply) SHIBI.UnstunPlayer(ply) end)
hook.Add("PlayerDisconnected", "SHIBI.Stun.ClearOnLeave", function(ply) SHIBI.UnstunPlayer(ply) end)

function SHIBI.GetMissSound()
    return "default_miss.wav"
end

function SHIBI.GetHitSound()
    return "default_hit.wav"
end

function SHIBI.GetHitParticles()
    return "default_hit_particles"
end

function SHIBI.GetHitAnimation()
    return "default_hit_animation"
end

function SHIBI.GetDashSound()
    return "default_dash.wav"
end

function SHIBI.GetBlockParticles()
    return "default_block_particles"
end

function SHIBI.ConeDamage(ent, tick, delay, radius, coneAngle, coneDistance, damage, callback, angle_dmg)
    if not IsValid(ent) then return end
    local targets = {}
    local owner = ent:IsPlayer() and ent or ent:GetOwner()
    for i = 1, tick do
        timer.Simple(i * delay, function()
            if not IsValid(ent) then return end

            local startPos = ent:GetPos()
            local aim = angle_dmg or (ent:IsPlayer() and ent:GetAimVector() or ent:GetForward())
            local entities = ents.FindInSphere(startPos, radius)

            for _, entity in ipairs(entities) do
                if IsValid(entity) and (entity:IsPlayer() or entity:IsNPC() or entity:IsNextBot()) and entity ~= owner then
                    local direction = (entity:GetPos() - startPos):GetNormalized()
                    local dotProduct = aim:Dot(direction)
                    local angle = math.deg(math.acos(dotProduct))

                    if angle <= coneAngle then
                        SHIBI.DealDamage(entity, damage or 10, owner)
                        table.insert(targets, entity)
                    end
                end
            end

            if i == tick and callback then
                callback(targets)
            end
        end)
    end
end

function SHIBI.PushTarget(target, owner, maxDistance, strength, totalTime, currentStrength, step, duration, effect)
    if not IsValid(target) or not IsValid(owner) then return end

    local startTime = CurTime()
    timer.Create("SmoothPush_" .. target:EntIndex(), step, 0, function()
        if not IsValid(target) then
            timer.Remove("SmoothPush_" .. target:EntIndex())
            return
        end

        local elapsedTime = CurTime() - startTime
        if elapsedTime >= totalTime then
            currentStrength = strength
        else
            currentStrength = Lerp(elapsedTime / totalTime, 0, strength)
        end

        local direction = (target:GetPos() - owner:GetPos()):GetNormalized()
        direction.z = 0
        direction:Normalize()
        local velocity = direction * currentStrength
        target:SetVelocity(velocity)
        local traveledDistance = target:GetPos():Distance(target:GetPos())
        if traveledDistance >= maxDistance or elapsedTime >= duration then
            target:SetLocalVelocity(Vector(0, 0, 0))
            timer.Remove("SmoothPush_" .. target:EntIndex())
        end
    end)

    timer.Simple(duration, function()
        if IsValid(target) and effect then
            ParticleEffectAttach(effect and effect or "[19]_rock_smash_main", 1, target, 1)
        end
    end)
end

function SHIBI.SphereDamage(ply, tick, delay, damageRadius, posSphere, damagePosition, damage, callback)
    if not IsValid(ply) then return end
    local targets = {}
    local owner = ply:IsPlayer() and ply or ply:GetOwner()
    for i = 1, tick do
        timer.Simple(i * delay, function()
            local players = ents.FindInSphere(posSphere, damageRadius)
            for _, pply in ipairs(players) do
                if IsValid(pply) and pply ~= owner and (pply:IsPlayer() or pply:IsNPC() or pply:IsNextBot()) then
                    if pply:GetPos():Distance(damagePosition) <= damageRadius then
                        SHIBI.DealDamage(pply, damage, owner)
                        table.insert(targets, pply)
                    end
                end
            end

            if i == tick and callback then
                callback(targets, ply)
            end
        end)
    end
end

function SHIBI.HitEffect(target, effect)
    if not IsValid(target) then return end
    local attachment = target:GetAttachment(2)
    if not attachment or not attachment.Pos then return end
    local attachPos = attachment.Pos
    local offset = Vector(5, 0, -20)
    local newPos = attachPos + offset
    ParticleEffect(effect or "", newPos, target:GetAngles(), target)
end

function SHIBI.SoundPlay(ply, sound, level, pitch, volume, chan)
    level = level and level or 75
    pitch = pitch and pitch or 100
    volume = volume and volume or 1
    chan = chan and chan or CHAN_AUTO
    ply:EmitSound(sound, level, pitch, volume, chan)
end

function SHIBI.FindAimTarget(ply, maxDist, aimRadius, minDot)
    if not IsValid(ply) then return nil end
    maxDist = maxDist or 600
    aimRadius = aimRadius or 8
    minDot = minDot or 0.85
    local startPos = ply:EyePos()
    local dir = ply:GetAimVector()
    local tr = util.TraceHull({
        start = startPos,
        endpos = startPos + dir * maxDist,
        mins = Vector(-aimRadius, -aimRadius, -aimRadius),
        maxs = Vector(aimRadius, aimRadius, aimRadius),
        mask = MASK_SHOT,
        filter = function(ent)
            if not IsValid(ent) or ent == ply then return false end
            if ent:IsPlayer() or ent:IsNPC() or ent:IsNextBot() then return true end
            return false
        end
    })

    local tgt = tr.Entity
    if IsValid(tgt) and (tgt:IsPlayer() or tgt:IsNPC() or tgt:IsNextBot()) then return tgt end
    local probeRadius = math.max(aimRadius * 8, 64)
    local probeCenter = startPos + dir * (maxDist * 0.5)
    local probe = ents.FindInSphere(probeCenter, probeRadius)
    local best, bestDot = nil, minDot
    for _, ent in ipairs(probe) do
        if IsValid(ent) and (ent:IsPlayer() or ent:IsNPC() or ent:IsNextBot()) and ent ~= ply then
            local to = (ent:WorldSpaceCenter() - startPos):GetNormalized()
            local d = dir:Dot(to)
            if d > bestDot then best, bestDot = ent, d end
        end
    end
    return best
end

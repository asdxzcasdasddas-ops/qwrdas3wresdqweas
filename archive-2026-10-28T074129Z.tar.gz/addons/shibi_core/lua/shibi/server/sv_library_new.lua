-- тут вся боль: OmniSlash, Repulse, CylDamage и прочая магия
SHIBI.InvertControls = SHIBI.InvertControls or {}
SHIBI.InvertControls.DEFAULTS = SHIBI.InvertControls.DEFAULTS or {
    ramp_in = 0.25,
    ramp_out = 0.35,
    curve = "smootherstep",
    mode = "invert",
    intensity = 1,
    angle_deg = 0,
    base_angle_deg = 0,
    osc_amp_deg = 45,
    osc_freq = 0.6,
    jitter_prob = 0.25,
    jitter_strength = 1,
    stutter_period = 0.6,
    stutter_duty = 0.4,
    lag_alpha = 0.25,
    k_alpha = 14.0,
}

SHIBI.InvertControls.NET = SHIBI.InvertControls.NET or "SHIBI::Invert::State"
SHIBI.InvertControls.PRED_KEY = SHIBI.InvertControls.PRED_KEY or "SHIBI::Invert::Predicted"

SHIBI.InvertControls._order = SHIBI.InvertControls._order or {
    "start","expires","ramp_in","ramp_out","curve","mode","intensity",
    "angle_deg","base_angle_deg","osc_amp_deg","osc_freq",
    "jitter_prob","jitter_strength","stutter_period","stutter_duty","lag_alpha","k_alpha"
}

SHIBI.InvertControls.WriteState = SHIBI.InvertControls.WriteState or function(rec)
    for _, k in ipairs(SHIBI.InvertControls._order) do
        local v = rec[k]
        local def = SHIBI.InvertControls.DEFAULTS[k]
        if k == "curve" or k == "mode" then
            net.WriteString(tostring(v ~= nil and v or def or ""))
        else
            net.WriteFloat(tonumber(v ~= nil and v or def or 0))
        end
    end
end

SHIBI.InvertControls.ReadState = SHIBI.InvertControls.ReadState or function(out)
    out = out or {}
    for _, k in ipairs(SHIBI.InvertControls._order) do
        if k == "curve" or k == "mode" then
            out[k] = net.ReadString()
        else
            out[k] = net.ReadFloat()
        end
    end

    out._lagf, out._lags = nil, nil
    out.k_curr = 1
    return out
end

SHIBI.InvertControls.TransformAxes = SHIBI.InvertControls.TransformAxes or function(f, s, rec, now)
    local mode = rec.mode or SHIBI.InvertControls.DEFAULTS.mode
    local k = SHIBI.InvertControls._kfactor and SHIBI.InvertControls._kfactor(now, rec.start, rec.expires, rec.ramp_in, rec.ramp_out, rec.curve) or 1
    local of, os = f, s

    if mode == "invert" then
        f, s = f * k, s * k
    elseif mode == "invert_forward" then
        f = f * k
    elseif mode == "invert_side" then
        s = s * k
    elseif mode == "swap" then
        f, s = s, f
    elseif mode == "rotate" then
        f, s = SHIBI.InvertControls._rot and SHIBI.InvertControls._rot(f, s, tonumber(rec.angle_deg) or SHIBI.InvertControls.DEFAULTS.angle_deg) or f, s
    elseif mode == "drunk" then
        local base = tonumber(rec.base_angle_deg) or SHIBI.InvertControls.DEFAULTS.base_angle_deg
        local amp  = tonumber(rec.osc_amp_deg)    or SHIBI.InvertControls.DEFAULTS.osc_amp_deg
        local freq = tonumber(rec.osc_freq)       or SHIBI.InvertControls.DEFAULTS.osc_freq
        local angle = base + amp * math.sin(now * math.pi * 2 * freq)
        f, s = SHIBI.InvertControls._rot and SHIBI.InvertControls._rot(f, s, angle) or f, s
    elseif mode == "jitter" then
        local p   = tonumber(rec.jitter_prob)     or SHIBI.InvertControls.DEFAULTS.jitter_prob
        local str = tonumber(rec.jitter_strength) or SHIBI.InvertControls.DEFAULTS.jitter_strength
        if math.Rand(0, 1) < p then f = -f * str + f * (1 - str) end
        if math.Rand(0, 1) < p then s = -s * str + s * (1 - str) end
        f, s = f * ((k + 1) / 2 * 2 - 1), s * ((k + 1) / 2 * 2 - 1)
    elseif mode == "stutter" then
        local T    = math.max(0.05, tonumber(rec.stutter_period) or SHIBI.InvertControls.DEFAULTS.stutter_period)
        local duty = math.Clamp(tonumber(rec.stutter_duty) or SHIBI.InvertControls.DEFAULTS.stutter_duty, 0, 1)
        local phase = (now - rec.start) % T
        local on = (phase / T) > duty
        if not on then f, s = 0, 0 end
        f, s = f * ((k + 1) / 2 * 2 - 1), s * ((k + 1) / 2 * 2 - 1)
    elseif mode == "lag" then
        rec._lagf = rec._lagf or f
        rec._lags = rec._lags or s
        local a = math.Clamp(tonumber(rec.lag_alpha) or SHIBI.InvertControls.DEFAULTS.lag_alpha, 0, 1)
        rec._lagf = rec._lagf + (f - rec._lagf) * a
        rec._lags = rec._lags + (s - rec._lags) * a
        f, s = rec._lagf * ((k + 1) / 2 * 2 - 1), rec._lags * ((k + 1) / 2 * 2 - 1)
    else
        f, s = f * k, s * k
    end

    local intensity = math.Clamp(tonumber(rec.intensity) or SHIBI.InvertControls.DEFAULTS.intensity, 0, 1)
    f = of + (f - of) * intensity
    s = os + (s - os) * intensity
    return f, s, k
end

local INV = SHIBI.InvertControls
util.AddNetworkString(INV.NET)
INV.Active = INV.Active or {}

local function applyDefaults(rec, opts)
    opts = opts or {}
    for k, v in pairs(INV.DEFAULTS) do
        if rec[k] == nil then rec[k] = v end
        if opts[k] ~= nil then rec[k] = opts[k] end
    end
end

function INV:Apply(ply, duration, opts)
    if not (IsValid(ply) and ply:IsPlayer()) then return false end
    duration = math.max(0.1, tonumber(duration) or 3)
    local now = CurTime()
    local rec = self.Active[ply]
    if rec then
        rec.expires = math.max(rec.expires or now, now + duration)
    else
        rec = {}
        self.Active[ply] = rec
        rec.start = now
        rec.expires = now + duration
    end

    applyDefaults(rec, opts)
    net.Start(INV.NET)
    net.WriteBool(true)
    INV.WriteState(rec)
    net.Send(ply)
    ply:SetPrivateBool(INV.PRED_KEY, true)
    return true
end

function INV:Clear(ply)
    if not (IsValid(ply) and ply:IsPlayer()) then return end
    if not self.Active[ply] then return end
    self.Active[ply] = nil
    net.Start(INV.NET)
    net.WriteBool(false)
    net.Send(ply)
    ply:SetPrivateBool(INV.PRED_KEY, false)
end

hook.Add("Think", "SHIBI::Think::Invert", function()
    if not next(INV.Active) then return end
    local now = CurTime()
    for ply, rec in pairs(INV.Active) do
        if (not IsValid(ply)) or (now >= (rec.expires or 0)) then INV:Clear(ply) end
    end
end)

hook.Add("StartCommand", "SHIBI::StartCommand::Invert", function(ply, cmd)
    local rec = INV.Active[ply]
    if not rec then return end
    local predicted = ply:IsPlayer() and not ply:IsBot() and ply:GetPrivateBool(INV.PRED_KEY, false)
    if predicted then return end
    local f = cmd:GetForwardMove()
    local s = cmd:GetSideMove()
    local nf, ns = INV.TransformAxes(f, s, rec, CurTime())
    cmd:SetForwardMove(nf)
    cmd:SetSideMove(ns)
end)

hook.Add("PlayerDisconnected", "SHIBI::PlayerDisconnected::Invert", function(ply) INV.Active[ply] = nil end)
hook.Add("PlayerDeath", "SHIBI::PlayerDeath::Invert", function(victim) INV:Clear(victim) end)

SHIBI.Vignette = SHIBI.Vignette or {}
local VIG = SHIBI.Vignette
util.AddNetworkString("SHIBI.Vignette.Set")

function VIG:Apply(ply, opts)
    if not (IsValid(ply) and ply:IsPlayer()) then return false end
    opts = opts or {}
    local duration = math.max(0.05, tonumber(opts.duration) or 2.0)
    local strength = math.Clamp(tonumber(opts.strength) or 1.0, 0, 1)
    local fadeIn = math.max(0, tonumber(opts.fadeIn) or 0.25)
    local fadeOut = math.max(0, tonumber(opts.fadeOut) or 0.45)
    local color = opts.color or Color(0, 0, 0, 255)
    net.Start("SHIBI.Vignette.Set")
    net.WriteBool(true)
    net.WriteFloat(duration)
    net.WriteFloat(strength)
    net.WriteFloat(fadeIn)
    net.WriteFloat(fadeOut)
    net.WriteColor(color, true)
    net.Send(ply)
    return true
end

function VIG:Clear(ply, fadeOut)
    if not (IsValid(ply) and ply:IsPlayer()) then return end
    net.Start("SHIBI.Vignette.Set")
    net.WriteBool(false)
    net.WriteFloat(0)
    net.WriteFloat(0)
    net.WriteFloat(0)
    net.WriteFloat(tonumber(fadeOut) or -1)
    net.WriteColor(Color(0, 0, 0, 255), true)
    net.Send(ply)
end

SHIBI.OmniSlash = SHIBI.OmniSlash or {}
SHIBI._omni = SHIBI._omni or {}
SHIBI.OmniSlash.DEFAULTS = {
    radius = 900,
    max_duration = 4.0,
    hop_interval = 0.20,
    damage = 45,
    damage_radius = 0,
    hits_per_target = 2,
    target_icd = 0.75,
    hop_dist_min = 60,
    hop_dist_max = 120,
    face_target = true,
    lock_to_ground = true,
    respect_pvp = true,
    invulnerable = true,
    nocollide = true,
    keep_velocity_zero = true,
    stop_on_no_targets = true,
    require_los = true,
    effect_blink_out = "omni_blink_out",
    effect_blink_in = "omni_blink_in",
    effect_slash = "omni_slash",
    effect_trail = "omni_trail",
    sound_slash = nil,
}

local PLAYER_HULL_STAND_MINS = Vector(-16, -16, 0)
local PLAYER_HULL_STAND_MAXS = Vector(16, 16, 72)
local function get_player_hull(ply)
    return PLAYER_HULL_STAND_MINS, PLAYER_HULL_STAND_MAXS
end

local function trace_ground(worldPos)
    if SHIBI.TraceGround then return SHIBI.TraceGround(worldPos) end
    return util.TraceLine({
        start = worldPos + Vector(0, 0, 32),
        endpos = worldPos + Vector(0, 0, -32768),
        mask = MASK_SOLID_BRUSHONLY
    })
end

local function is_space_free_for_player(ply, pos)
    local mins, maxs = get_player_hull(ply)
    local tr = util.TraceHull({
        start = pos,
        endpos = pos,
        mins = mins,
        maxs = maxs,
        mask = MASK_PLAYERSOLID,
        filter = function(e)
            if e == ply then return false end
            local cls = e.GetClass and e:GetClass() or ""
            if cls == "gmod_hands" or cls == "predicted_viewmodel" then return false end
            return true
        end
    })
    return not tr.Hit
end

local function snap_to_ground(pos)
    local tr = trace_ground(pos)
    return (tr and tr.Hit) and tr.HitPos or pos
end

local function find_safe_exit_pos(ply, seed)
    local base = Vector(seed) + Vector(0, 0, 2)
    if is_space_free_for_player(ply, base) then return snap_to_ground(base) end
    local rings = {0, 24, 48, 72, 96, 128}
    local ups = {0, 12, 24, 36, 48}
    for _, up in ipairs(ups) do
        for _, r in ipairs(rings) do
            local step = (r <= 48) and 45 or 30
            for yaw = 0, 360 - step, step do
                local rad = math.rad(yaw)
                local pos = Vector(base.x + math.cos(rad) * r, base.y + math.sin(rad) * r, base.z + up)
                if is_space_free_for_player(ply, pos) then return snap_to_ground(pos) end
            end
        end
    end
    return snap_to_ground(seed)
end

local function random_ring_point(center, minR, maxR)
    local yaw = math.rad(math.Rand(0, 360))
    local r = math.Rand(minR, maxR)
    return center + Vector(math.cos(yaw) * r, math.sin(yaw) * r, 0)
end

local function get_head_pos(ent)
    if SHIBI.GetHeadPos then
        local p = SHIBI.GetHeadPos(ent)
        if p then return p end
    end

    if ent.EyePos then return ent:EyePos() end
    return ent:GetPos() + Vector(0, 0, 64)
end

local function has_los_to_target(att, target)
    local start = att.EyePos and att:EyePos() or (att.GetPos and att:GetPos() + Vector(0, 0, 64)) or att:GetPos()
    local finish = get_head_pos(target)
    local tr = util.TraceLine({
        start = start,
        endpos = finish,
        mask = MASK_VISIBLE_AND_NPCS,
        filter = function(e)
            if e == att then return true end
            local cls = e.GetClass and e:GetClass() or ""
            if cls == "gmod_hands" or cls == "predicted_viewmodel" then return true end
            return false
        end
    })
    return (tr.Entity == target) or (not tr.Hit) or (tr.HitNonWorld and tr.Entity == target)
end

local function has_los_point_from_target(target, point)
    local start = get_head_pos(target)
    local tr = util.TraceLine({
        start = start,
        endpos = point + Vector(0, 0, 10),
        mask = MASK_SOLID_BRUSHONLY
    })
    return not tr.Hit
end

local function is_hostile(att, tgt, respect_pvp)
    if not (IsValid(att) and IsValid(tgt)) then return false end
    local okType = tgt:IsPlayer() or tgt:IsNPC() or tgt:IsNextBot()
    if not okType then return false end
    if att == tgt then return false end
    if respect_pvp and SHIBI.SameFraction(att, tgt) and not SHIBI.PVP:CheckMode(att, tgt) then return false end
    if SHIBI.IsHostile then return SHIBI.IsHostile(att, tgt) end
    return okType
end

local function collect_targets(att, center, radius, respect_pvp)
    local raw = ents.FindInSphere(center, radius)
    local out = {}
    for _, e in ipairs(raw) do
        if is_hostile(att, e, respect_pvp) and (e:IsPlayer() and e:Alive()) or (e.Health and e:Health() > 0) then table.insert(out, e) end
    end
    return out
end

local function face_pos(ply, pos)
    local ang = (pos - (ply:EyePos() or ply:GetPos())):Angle()
    ang.p = 0
    ang.r = 0
    ply:SetEyeAngles(ang)
end

local function play_fx(ent, pfx)
    if not (IsValid(ent) and pfx and pfx ~= "") then return end
    if SHIBI.CreateParticleOnPlayer then SHIBI.CreateParticleOnPlayer(ent, pfx, "attach", 6, 0.6) end
end

local function play_sound(ent, snd)
    if not (IsValid(ent) and snd and snd ~= "") then return end
    if SHIBI.SoundPlay then SHIBI.SoundPlay(ent, snd) end
end

local function do_damage(attacker, centerEnt, amount, radius)
    if radius and radius > 0 then
        local center = centerEnt:GetPos()
        local list = ents.FindInSphere(center, radius)
        for _, tgt in ipairs(list) do
            if is_hostile(attacker, tgt, true) then
                local di = DamageInfo()
                di:SetAttacker(attacker)
                di:SetInflictor(attacker)
                di:SetDamage(amount)
                di:SetDamageType(DMG_CLUB)
                di:SetReportedPosition(center)
                tgt:TakeDamageInfo(di)
            end
        end
    else
        if IsValid(centerEnt) then
            local di = DamageInfo()
            di:SetAttacker(attacker)
            di:SetInflictor(attacker)
            di:SetDamage(amount)
            di:SetDamageType(DMG_CLUB)
            di:SetReportedPosition(centerEnt:GetPos())
            centerEnt:TakeDamageInfo(di)
        end
    end
end

local function safe_setpos_grounded(ply, aroundPos, lock_to_ground, st)
    local dest = Vector(aroundPos)
    if lock_to_ground then dest = snap_to_ground(dest) end
    ply:SetPos(dest)
    if is_space_free_for_player(ply, dest) then st.last_safe_pos = Vector(dest) end
end

local function cleanup(att, reason)
    local st = SHIBI._omni[att]
    if not st then return end
    if st.timer then timer.Remove(st.timer) end
    local exitSeed = st.last_safe_pos or att:GetPos()
    local safePos = find_safe_exit_pos(att, exitSeed)
    if st.god and att.GodDisable then att:GodDisable() end
    if st.restore_move then
        att:SetMoveType(st.prev_movetype or MOVETYPE_WALK)
        if att.SetGroundEntity then att:SetGroundEntity(NULL) end
    end

    att:SetLocalVelocity(vector_origin)
    if st.nocollide then att:SetCollisionGroup(st.prev_collision or COLLISION_GROUP_PLAYER) end
    att:SetPos(safePos)
    local gz = trace_ground(safePos)
    if gz and gz.Hit then
        local posOnGround = gz.HitPos + Vector(0, 0, 0.1)
        if is_space_free_for_player(att, posOnGround) then att:SetPos(posOnGround) end
    end

    SHIBI._omni[att] = nil
    if st.on_end then pcall(st.on_end, att, reason or "done") end
end

local function pick_next_target(att, st)
    local center = att:GetPos()
    st.candidates = collect_targets(att, center, st.radius, st.respect_pvp)
    if #st.candidates == 0 then return nil end
    local best, bestDist2
    local tnow = CurTime()
    for _, e in ipairs(st.candidates) do
        local idx = e:EntIndex()
        local last = st.hit_at[idx] or 0
        local hits = st.hits[idx] or 0
        if (tnow - last) >= st.target_icd and hits < st.hits_per_target and (not st.require_los) or has_los_to_target(att, e) then
            local d2 = e:GetPos():DistToSqr(center)
            if not best or d2 < bestDist2 then best, bestDist2 = e, d2 end
        end
    end
    return best
end

local function hop_to(att, st, target)
    if not (IsValid(att) and IsValid(target)) then return false end
    if st.require_los and not has_los_to_target(att, target) then return false end
    local around
    local attempts = 8
    for i = 1, attempts do
        local try = random_ring_point(target:GetPos(), st.hop_dist_min, st.hop_dist_max)
        if is_space_free_for_player(att, try) and has_los_point_from_target(target, try) then
            around = try
            break
        end
    end

    if not around then
        for i = 1, attempts do
            local try = random_ring_point(target:GetPos(), st.hop_dist_min, st.hop_dist_max)
            if is_space_free_for_player(att, try) then
                around = try
                break
            end
        end
    end

    if not around then return false end
    play_fx(att, st.effect_blink_out)
    if st.keep_velocity_zero then att:SetLocalVelocity(vector_origin) end
    safe_setpos_grounded(att, around, st.lock_to_ground, st)
    if st.face_target then face_pos(att, target:GetPos()) end
    play_fx(att, st.effect_blink_in)
    if st.effect_trail then play_fx(att, st.effect_trail) end
    if st.effect_slash then play_fx(target, st.effect_slash) end
    if st.sound_slash then play_sound(att, st.sound_slash) end
    do_damage(att, target, st.damage, st.damage_radius)
    local idx = target:EntIndex()
    st.hit_at[idx] = CurTime()
    st.hits[idx] = (st.hits[idx] or 0) + 1
    if st.on_hit then pcall(st.on_hit, att, target) end
    return true
end

local function process(att)
    local st = SHIBI._omni[att]
    if not st then return end
    if not IsValid(att) or not att:Alive() then
        cleanup(att, "lost")
        return
    end

    if CurTime() >= st.ends_at then
        cleanup(att, "timeout")
        return
    end

    local tgt = pick_next_target(att, st)
    if not IsValid(tgt) then
        if st.stop_on_no_targets then cleanup(att, "no_targets") end
        return
    end

    hop_to(att, st, tgt)
end

function SHIBI.OmniSlash.IsActive(ply)
    return SHIBI._omni[ply] ~= nil
end

function SHIBI.OmniSlash.Start(att, opts)
    if not (IsValid(att) and att:IsPlayer()) then return false end
    if SHIBI._omni[att] then return false end
    local d = table.Copy(SHIBI.OmniSlash.DEFAULTS)
    opts = opts or {}
    for k, v in pairs(opts) do
        d[k] = v
    end

    local st = {
        radius = tonumber(d.radius) or 900,
        max_duration = math.max(0.1, tonumber(d.max_duration) or 4.0),
        hop_interval = math.max(0.01, tonumber(d.hop_interval) or 0.20),
        damage = tonumber(d.damage) or 45,
        damage_radius = math.max(0, tonumber(d.damage_radius) or 0),
        hits_per_target = math.max(1, math.floor(tonumber(d.hits_per_target) or 2)),
        target_icd = math.max(0, tonumber(d.target_icd) or 0.75),
        hop_dist_min = math.max(16, tonumber(d.hop_dist_min) or 60),
        hop_dist_max = math.max(32, tonumber(d.hop_dist_max) or 120),
        face_target = d.face_target ~= false,
        lock_to_ground = d.lock_to_ground ~= false,
        respect_pvp = d.respect_pvp ~= false,
        invulnerable = d.invulnerable ~= false,
        nocollide = d.nocollide ~= false,
        keep_velocity_zero = d.keep_velocity_zero ~= false,
        stop_on_no_targets = d.stop_on_no_targets ~= false,
        require_los = d.require_los ~= false,
        effect_blink_out = d.effect_blink_out,
        effect_blink_in = d.effect_blink_in,
        effect_slash = d.effect_slash,
        effect_trail = d.effect_trail,
        sound_slash = d.sound_slash,
        on_start = opts.on_start,
        on_hit = opts.on_hit,
        on_end = opts.on_end,
        candidates = {},
        hit_at = {},
        hits = {},
        prev_movetype = att:GetMoveType(),
        prev_collision = att:GetCollisionGroup(),
        restore_move = true,
        ends_at = CurTime() + math.max(0.05, tonumber(d.max_duration) or 4.0),
        last_safe_pos = Vector(att:GetPos())
    }

    if st.hop_dist_max < st.hop_dist_min then st.hop_dist_max = st.hop_dist_min + 1 end
    att:Freeze(false)
    if st.invulnerable and att.GodEnable then
        att:GodEnable()
        st.god = true
    end

    if st.nocollide then att:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE) end
    att:SetMoveType(MOVETYPE_WALK)
    if st.keep_velocity_zero then att:SetLocalVelocity(vector_origin) end
    play_fx(att, st.effect_blink_in)
    if SHIBI.CreateParticleOnPlayer and st.effect_trail then SHIBI.CreateParticleOnPlayer(att, st.effect_trail, "attach", 6, st.max_duration) end
    local tname = ("SHIBI::OmniSlash:%d"):format(att:EntIndex())
    st.timer = tname
    timer.Remove(tname)
    timer.Create(tname, st.hop_interval, 0, function() process(att) end)
    SHIBI._omni[att] = st
    if st.on_start then pcall(st.on_start, att) end
    return true
end

function SHIBI.OmniSlash.Stop(att, reason)
    if not IsValid(att) then return end
    cleanup(att, reason or "stop")
end

hook.Add("EntityRemoved", "SHIBI::EntityRemoved::OmniSlash", function(ent)
    local st = SHIBI._omni[ent]
    if st then cleanup(ent, "removed") end
end)

hook.Add("PlayerDeath", "SHIBI::PlayerDeath::OmniSlash", function(ply) if SHIBI._omni[ply] then cleanup(ply, "death") end end)

SHIBI.Repulse = SHIBI.Repulse or {}
local function _is_playerlike(ent)
    return IsValid(ent) and (ent:IsPlayer() or ent:IsNPC() or ent:IsNextBot())
end

local function _falloff(scaleType, t)
    if scaleType == "linear" then
        return 1 - t
    elseif scaleType == "quad" then
        return (1 - t) * (1 - t)
    else
        local s = 3 * t * t - 2 * t * t * t
        return 1 - s
    end
end

local function _passes_cone(source, srcAng, targetPos, cone)
    if not cone or (not cone.yaw and not cone.pitch) then return true end
    local dir = (targetPos - source):GetNormalized()
    local fwd = srcAng:Forward()
    local up = srcAng:Up()
    if cone.yaw then
        local yaw_deg = math.deg(math.acos(math.Clamp(fwd:Dot(dir), -1, 1)))
        if yaw_deg > cone.yaw then return false end
    end

    if cone.pitch then
        local pitch_deg = math.deg(math.acos(math.Clamp(up:Dot(dir), -1, 1))) - 90
        if math.abs(pitch_deg) > cone.pitch then return false end
    end
    return true
end

local function _has_los(fromPos, toEnt, mask, ignore)
    local tr = util.TraceLine({
        start = fromPos,
        endpos = toEnt:WorldSpaceCenter(),
        mask = mask or MASK_SOLID_BRUSHONLY,
        filter = ignore
    })
    return (not tr.Hit) or (tr.Entity == toEnt)
end

local function _apply_to_playerlike(ent, impulse, maxImpulse)
    local imp = impulse
    if maxImpulse and maxImpulse > 0 and imp:LengthSqr() > (maxImpulse * maxImpulse) then imp = imp:GetNormalized() * maxImpulse end
    if ent.SetGroundEntity then ent:SetGroundEntity(NULL) end
    ent:SetVelocity(imp)
end

local function _apply_to_prop(ent, impulse, scale)
    local phys = ent:GetPhysicsObject()
    if not IsValid(phys) then return end
    phys:Wake()
    phys:ApplyForceCenter(impulse * (scale or 1))
end

function SHIBI.Repulse.PushFrom(source, radius, force, opts)
    if not (source and isnumber(radius) and isnumber(force)) then return {} end
    opts = opts or {}
    local srcPos, srcAng, owner
    if IsEntity(source) then
        if not IsValid(source) then return {} end
        srcPos = source:WorldSpaceCenter()
        srcAng = (source.EyeAngles and source:EyeAngles()) or source:GetAngles() or Angle(0, 0, 0)
        owner = opts.owner or (source:IsPlayer() and source or source:GetOwner())
    elseif isvector(source) then
        srcPos = Vector(source)
        srcAng = Angle(0, 0, 0)
        owner = opts.owner
    else
        return {}
    end

    if not IsValid(owner) then owner = IsEntity(source) and source or nil end
    local includePlayers = opts.players ~= false
    local includeNPCs = opts.npcs ~= false
    local includeNextBots = opts.nextbots ~= false
    local includeProps = opts.props or false
    local respectFactions = opts.respect_factions ~= false
    local filterFn = opts.filter
    local needLOS = opts.los or false
    local cone = opts.cone
    local zScale = (opts.z_scale ~= nil) and opts.z_scale or 0.35
    local upBoost = tonumber(opts.up_boost) or 0
    local falloffType = opts.falloff or "smooth"
    local minScale = tonumber(opts.min_scale) or 0.0
    local maxImpulse = tonumber(opts.max_vel) or 1200
    local propForceScale = tonumber(opts.prop_force_scale) or 1
    local onHit = opts.on_hit
    local affected = {}
    local around = ents.FindInSphere(srcPos, radius)
    local pull = opts.pull == true
    for _, ent in ipairs(around) do
        if IsValid(ent) then
            local skip = false
            if ent == owner or ent == source then skip = true end
            local isPlayer = ent:IsPlayer()
            local isNPC = ent:IsNPC()
            local isNextBot = ent:IsNextBot()
            local phys = ent.GetPhysicsObject and ent:GetPhysicsObject() or nil
            local isProp = IsValid(phys) and (ent:GetMoveType() == MOVETYPE_VPHYSICS)
            if isPlayer and not includePlayers then skip = true end
            if isNPC and not includeNPCs then skip = true end
            if isNextBot and not includeNextBots then skip = true end
            if isProp and not includeProps then skip = true end
            if not isPlayer and not isNPC and not isNextBot and not isProp then skip = true end
            if not skip and filterFn and (filterFn(ent) == false) then skip = true end
            if not skip and respectFactions and IsValid(owner) and ent:IsPlayer() and SHIBI.SameFraction(owner, ent) and not SHIBI.PVP:CheckMode(owner, ent) then skip = true end
            if not skip and cone and IsEntity(source) then
                local tgtPosCone = ent:WorldSpaceCenter()
                if not _passes_cone(srcPos, srcAng, tgtPosCone, cone) then skip = true end
            end

            if not skip and needLOS and (not _has_los(srcPos, ent, {owner, source})) then skip = true end
            if not skip then
                local tgtPos = ent:WorldSpaceCenter()
                local dir = pull and (srcPos - tgtPos) or (tgtPos - srcPos)
                dir.z = dir.z * zScale
                local dist = dir:Length()
                if dist >= 1e-3 then
                    dir:Normalize()
                    local t = math.Clamp(dist / radius, 0, 1)
                    local scale = _falloff(falloffType, t)
                    scale = math.max(minScale, scale)
                    local impulse = dir * (force * scale)
                    if upBoost ~= 0 then impulse.z = impulse.z + upBoost * scale end
                    if _is_playerlike(ent) then
                        _apply_to_playerlike(ent, impulse, maxImpulse)
                    elseif isProp and includeProps then
                        _apply_to_prop(ent, impulse, propForceScale)
                    end

                    affected[#affected + 1] = ent
                    if onHit then pcall(onHit, ent, impulse, scale) end
                end
            end
        end
    end
    return affected
end

function SHIBI.Repulse.FromPlayer(ply, radius, force, opts)
    if not IsValid(ply) then return {} end
    opts = opts or {}
    opts.owner = opts.owner or ply
    return SHIBI.Repulse.PushFrom(ply, radius, force, opts)
end

function SHIBI.Repulse.FromEntity(ent, radius, force, opts)
    if not IsValid(ent) then return {} end
    opts = opts or {}
    opts.owner = opts.owner or (ent.GetOwner and ent:GetOwner())
    return SHIBI.Repulse.PushFrom(ent, radius, force, opts)
end

function SHIBI.Repulse.FromPoint(pos, radius, force, opts)
    if not isvector(pos) then return {} end
    return SHIBI.Repulse.PushFrom(pos, radius, force, opts or {})
end

function SHIBI.Repulse.PullFrom(source, radius, force, opts)
    opts = opts or {}
    opts.pull = true
    return SHIBI.Repulse.PushFrom(source, radius, force, opts)
end

function SHIBI.Repulse.PullFromPlayer(ply, radius, force, opts)
    if not IsValid(ply) then return {} end
    opts = opts or {}
    opts.owner = opts.owner or ply
    opts.pull = true
    return SHIBI.Repulse.PushFrom(ply, radius, force, opts)
end

function SHIBI.Repulse.PullFromEntity(ent, radius, force, opts)
    if not IsValid(ent) then return {} end
    opts = opts or {}
    opts.owner = opts.owner or (ent.GetOwner and ent:GetOwner())
    opts.pull = true
    return SHIBI.Repulse.PushFrom(ent, radius, force, opts)
end

function SHIBI.Repulse.PullFromPoint(pos, radius, force, opts)
    if not isvector(pos) then return {} end
    opts = opts or {}
    opts.pull = true
    return SHIBI.Repulse.PushFrom(pos, radius, force, opts)
end

function SHIBI.Repulse.PushOne(source, target, force, opts)
    if not (IsValid(source) and IsValid(target)) then return false end
    local isPlayerlike = target:IsPlayer() or target:IsNPC() or target:IsNextBot()
    if not isPlayerlike then return false end
    opts = opts or {}
    local onlyTarget = target
    local userFilter = opts.filter
    opts.filter = function(ent)
        if ent ~= onlyTarget then return false end
        if userFilter then return userFilter(ent) ~= false end
        return true
    end

    opts.players = true
    opts.npcs = true
    opts.nextbots = true
    opts.props = false
    opts.respect_factions = opts.respect_factions ~= false
    opts.z_scale = (opts.z_scale ~= nil) and opts.z_scale or 0.35
    opts.up_boost = (opts.up_boost ~= nil) and opts.up_boost or 0
    opts.max_vel = opts.max_vel or 1200
    opts.falloff = opts.falloff or "smooth"
    opts.min_scale = opts.min_scale or 0.0
    opts.los = opts.los or false
    local radius = opts.radius or 96
    local affected = SHIBI.Repulse.PushFrom(source, radius, force, opts)
    return affected and #affected > 0
end

SHIBI.CylDamage = SHIBI.CylDamage or {}

local function _collect_targets(centerPos, radius, height, owner, opts)
    local list = {}
    opts = opts or {}
    local includePlayers = opts.players ~= false
    local includeNPCs = opts.npcs ~= false
    local includeNextBots = opts.nextbots ~= false
    local respectF = opts.respect_factions ~= false
    local requireLOS = opts.require_los or false
    local losMask = opts.los_mask or MASK_SOLID_BRUSHONLY
    local filterFn = opts.filter
    local radSqr = radius * radius
    local minZ = centerPos.z
    local maxZ = centerPos.z + height
    for _, ent in ipairs(ents.FindInSphere(centerPos, radius)) do
        if not IsValid(ent) then continue end
        local isP, isN, isNB = ent:IsPlayer(), ent:IsNPC(), ent:IsNextBot()
        if isP then
            if (not includePlayers) or (not ent:Alive()) then continue end
            if respectF and IsValid(owner) and owner ~= ent and SHIBI.SameFraction(owner, ent) and not SHIBI.PVP:CheckMode(owner, ent) then continue end
        elseif isN then
            if not includeNPCs then continue end
        elseif isNB then
            if not includeNextBots then continue end
        else
            continue
        end

        if filterFn and (filterFn(ent) == false) then continue end
        local pos = ent:WorldSpaceCenter()
        if pos.z < minZ or pos.z > maxZ then continue end
        local dx, dy = pos.x - centerPos.x, pos.y - centerPos.y
        if (dx * dx + dy * dy) > radSqr then continue end
        if requireLOS and (not _has_los(centerPos, ent, losMask, {owner})) then continue end
        list[#list + 1] = ent
    end
    return list
end

local function _damage_per_tick(mode, baseDamage, duration, interval)
    local ticks = math.max(1, math.floor(duration / math.max(0.001, interval) + 0.5))
    if mode == "per_tick" then
        return baseDamage, ticks
    elseif mode == "total" then
        return baseDamage / ticks, ticks
    else
        return baseDamage * interval, ticks
    end
end

function SHIBI.CylDamage.Start(center, radius, height, opts)
    if not (center and isnumber(radius) and isnumber(height)) then return nil end
    opts = opts or {}
    local owner = opts.owner
    if not IsValid(owner) and IsEntity(center) then owner = center:IsPlayer() and center or center:GetOwner() end
    if not IsValid(owner) and IsEntity(center) then owner = center end
    local duration = tonumber(opts.duration) or 2.0
    local interval = math.max(0.01, tonumber(opts.interval) or 0.25)
    local baseDmg = tonumber(opts.damage) or 10
    local mode = opts.mode or "dps"
    local dmgType = tonumber(opts.dmg_type) or DMG_GENERIC
    local custom = tonumber(opts.custom_flag) or (SHIBI.DMG_CUSTOM and SHIBI.DMG_CUSTOM.OWNED_VIA_ENTITY) or 424243
    local limit = tonumber(opts.max_hits_per_target)
    local onTick = isfunction(opts.on_tick) and opts.on_tick or nil
    local onHit = isfunction(opts.on_hit) and opts.on_hit or nil
    local onFinish = isfunction(opts.on_finish) and opts.on_finish or nil
    local trackOff = opts.track_offset or vector_origin
    local dmgPerTick, _ = _damage_per_tick(mode, baseDmg, duration, interval)
    local started = CurTime()
    local hitsLeft = {}
    local dealtSum = {}
    local function getCenterPos()
        if isvector(center) then
            return center
        elseif IsEntity(center) and IsValid(center) then
            return center:WorldSpaceCenter() + trackOff
        else
            return nil
        end
    end

    local idOwner = IsValid(owner) and (owner.SteamID and owner:SteamID() or tostring(owner)) or "noowner"
    local id = ("SHIBI::CylDamage::%s_%d"):format(idOwner, isentity(center) and center:EntIndex() or math.random(1000, 9999))
    local ticksDone = 0
    timer.Create(id, interval, 0, function()
        if (CurTime() - started) >= duration then
            timer.Remove(id)
            if onFinish then
                local summary = {}
                for ent, sum in pairs(dealtSum) do
                    if IsValid(ent) then
                        summary[#summary + 1] = {
                            target = ent,
                            total = sum
                        }
                    end
                end

                pcall(onFinish, summary)
            end
            return
        end

        local cpos = getCenterPos()
        if not cpos then
            timer.Remove(id)
            return
        end

        local targets = _collect_targets(cpos, radius, height, owner, opts) or {}
        for _, ent in ipairs(targets) do
            local skip = false
            if IsValid(owner) and ent == owner and opts.hurt_owner ~= true then skip = true end
            if not skip and IsValid(owner) and ent.GetOwner and ent:GetOwner() == owner and opts.hurt_owner ~= true then skip = true end
            if not skip and limit and limit >= 0 then
                hitsLeft[ent] = hitsLeft[ent] or 0
                if hitsLeft[ent] >= limit then skip = true end
            end

            if not skip then
                local di = DamageInfo()
                di:SetDamage(dmgPerTick)
                di:SetAttacker(IsValid(owner) and owner or (IsEntity(center) and center or game.GetWorld()))
                di:SetInflictor(IsEntity(center) and center or (IsValid(owner) and owner or game.GetWorld()))
                di:SetDamageType(dmgType)
                di:SetDamageCustom(custom)
                ent:TakeDamageInfo(di)
                dealtSum[ent] = (dealtSum[ent] or 0) + dmgPerTick
                if limit and limit >= 0 then hitsLeft[ent] = (hitsLeft[ent] or 0) + 1 end
                if onHit then pcall(onHit, ent, dmgPerTick) end
            end
        end

        if onTick then pcall(onTick, targets) end
        ticksDone = ticksDone + 1
    end)
    return id
end

function SHIBI.CylDamage.Stop(id)
    if not isstring(id) then return end
    timer.Remove(id)
end

SHIBI.ExplosiveClones = SHIBI.ExplosiveClones or {}
local function GetRagdollCenter(rag)
    if not IsValid(rag) then return nil end
    local sum, n = Vector(0, 0, 0), 0
    for i = 0, rag:GetPhysicsObjectCount() - 1 do
        local po = rag:GetPhysicsObjectNum(i)
        if IsValid(po) then
            sum = sum + po:GetPos()
            n = n + 1
        end
    end
    return (n > 0) and (sum / n) or rag:GetPos()
end

local function DoExplosionFX(rag, pos, attacker, opt)
    opt = opt or {}
    local fx = opt.fx or {}
    local mode = fx.mode
    if mode == "particle" then
        local particle = fx.particle
        if isstring(particle) and particle ~= "" then
            local targetEnt = (IsValid(fx.entity) and fx.entity) or rag
            local attachType = fx.attach_type or "effect"
            local attachId = fx.attach_id
            local duration = fx.duration
            local offset = fx.offset or Vector(0, 0, 0)
            local ang = fx.angle or Angle(0, 0, 0)
            if attachType == "effect" then
                local fake = ents.Create("info_target")
                if IsValid(fake) then
                    fake:SetPos(pos)
                    fake:Spawn()
                    SHIBI.CreateParticleOnPlayer(fake, particle, "effect", nil, duration, offset, ang)
                    if duration then
                        SafeRemoveEntityDelayed(fake, math.max(0.05, duration + 0.05))
                    else
                        SafeRemoveEntity(fake)
                    end
                else
                    SHIBI.CreateParticleOnPlayer(targetEnt, particle, "effect", nil, duration, offset, ang)
                end
            else
                SHIBI.CreateParticleOnPlayer(targetEnt, particle, "attach", attachId, duration, offset, ang)
            end
            return
        end
    elseif mode == "entity" then
        local ang = fx.angle or Angle(0, 0, 0)
        local spawnPos = pos + (fx.spawn_offset or Vector(0, 0, 0))
        local ent = SHIBI.SpawnEntity(nil, "Invisible", attacker, fx.timed or 2, fx.scale or 1, fx.pfx or "", spawnPos, ang, nil, fx.callback, fx.delete ~= false, fx.prop or "prop_dynamic", fx.parent)
        if IsValid(ent) and fx.on_spawn then pcall(fx.on_spawn, ent, rag, attacker) end
        return
    end

    local ef = EffectData()
    ef:SetOrigin(pos)
    ef:SetMagnitude(1)
    util.Effect("Explosion", ef, true, true)
    sound.Play("BaseExplosionEffect.Sound", pos, 90, 100, 1)
end

function SHIBI.ExplosiveClones:Explode(rag, attacker, opt)
    if not IsValid(rag) then return end
    opt = opt or {}
    local radius = tonumber(opt.radius) or 140
    local damage = tonumber(opt.damage) or 45
    local dmg_ticks = math.max(1, tonumber(opt.dmg_ticks) or 1)
    local dmg_tick_delay = math.max(0, tonumber(opt.dmg_tick_delay) or 0)
    local pos = GetRagdollCenter(rag) or rag:GetPos()
    DoExplosionFX(rag, pos, attacker, opt)
    SHIBI.SphereDamage(attacker or rag, dmg_ticks, dmg_tick_delay, radius, pos, pos, damage, opt.on_damage)
    SafeRemoveEntity(rag)
end

function SHIBI.ExplosiveClones:Spawn(ply, opts)
    if not IsValid(ply) then return {} end
    opts = opts or {}
    local count = math.max(1, tonumber(opts.count) or 6)
    local step_time = math.max(0.01, tonumber(opts.step_time) or 0.15)
    local rag_life = tonumber(opts.rag_life) or 3.0
    local explode_after = tonumber(opts.explode_after) or 0.7
    local explode_jitter = tonumber(opts.explode_jitter) or 0
    local dmg = tonumber(opts.dmg) or 45
    local radius = tonumber(opts.radius) or 140
    local force = tonumber(opts.force) or 22000
    local shake = tonumber(opts.shake) or 5
    local copy_pose = opts.copy_pose ~= false
    local follow = opts.follow == true
    local snap_to_floor = opts.snap_to_floor == true
    local bump_up = tonumber(opts.bump_up) or 0
    local face_mode = opts.face_mode or "player_yaw"
    local fixed_yaw = tonumber(opts.fixed_yaw) or 0
    local function chooseAngles(yaw_now)
        if face_mode == "fixed" then
            return Angle(0, fixed_yaw, 0)
        elseif face_mode == "look_move" then
            local vel = ply.GetVelocity and ply:GetVelocity() or vector_origin
            if vel:LengthSqr() > 1 then
                local v = Vector(vel.x, vel.y, 0)
                if v:LengthSqr() > 1 then return v:Angle() end
            end
            return Angle(0, yaw_now, 0)
        else
            return Angle(0, yaw_now, 0)
        end
    end

    local rags, timers = {}, {}
    local owner_eid = ply:EntIndex()
    local function spawn_one()
        if not IsValid(ply) then return end
        local pos_now = ply:GetPos()
        local yaw_now = ply:EyeAngles().y
        local place = Vector(pos_now)
        if snap_to_floor then
            local tr = TraceFloorAt(place)
            if tr.Hit then place.z = tr.HitPos.z + bump_up end
        end

        local ang = chooseAngles(yaw_now)
        local rag = SHIBI.RagdollSpawn(ply, rag_life, place, ang, copy_pose, ply, {
            follow = follow,
            collision_group = COLLISION_GROUP_DEBRIS
        })

        if not IsValid(rag) then return end
        for i = 0, rag:GetPhysicsObjectCount() - 1 do
            local po = rag:GetPhysicsObjectNum(i)
            if IsValid(po) then po:EnableMotion(false) end
        end

        rags[#rags + 1] = rag
        local boomDelay = math.max(0.01, explode_after + math.Rand(-explode_jitter, explode_jitter))
        local tname_boom = ("SHIBI::ExplClones::Boom_%d_%d_%d"):format(owner_eid, rag:EntIndex(), math.random(1000, 9999))
        timer.Create(tname_boom, boomDelay, 1, function()
            if IsValid(rag) then
                SHIBI.ExplosiveClones:Explode(rag, ply, {
                    radius = radius,
                    damage = dmg,
                    force = force,
                    shake = shake,
                    fx = opts.fx
                })
            end
        end)

        timers[#timers + 1] = tname_boom
    end

    for i = 1, count do
        local delay = (i - 1) * step_time
        local tname_spawn = ("SHIBI::ExplClones::Spawn_%d_%d"):format(owner_eid, math.random(100000))
        timer.Create(tname_spawn, delay, 1, spawn_one)
        timers[#timers + 1] = tname_spawn
    end

    local cleanupID = "SHIBI::ExplClones::Cleanup_" .. owner_eid .. "_" .. math.random(1000, 9999)
    hook.Add("EntityRemoved", cleanupID, function(ent)
        if ent == ply then
            for _, tn in ipairs(timers) do
                timer.Remove(tn)
            end

            hook.Remove("EntityRemoved", cleanupID)
        end
    end)
    return rags
end

util.AddNetworkString("SHIBI::ScreenShake")

function SHIBI.ScreenShake(plyOrList, amp, freq, dur, opts)
    local recipients = {}
    if istable(plyOrList) then
        for _, pl in ipairs(plyOrList) do
            if IsValid(pl) and pl:IsPlayer() then table.insert(recipients, pl) end
        end
    elseif IsValid(plyOrList) and plyOrList:IsPlayer() then
        recipients = {plyOrList}
    else
        return
    end

    amp = math.Clamp(tonumber(amp) or 0.5, 0, 10)
    freq = math.Clamp(tonumber(freq) or 6.0, 0.01, 50)
    dur = math.max(tonumber(dur) or 0.35, 0)
    local hasOpts = istable(opts)
    net.Start("SHIBI::ScreenShake")
    net.WriteFloat(amp)
    net.WriteFloat(freq)
    net.WriteFloat(dur)
    net.WriteBool(hasOpts)
    if hasOpts then
        local ax = istable(opts.ax) and opts.ax or {}
        net.WriteFloat(tonumber(opts.roll) or 0.25)
        net.WriteFloat(tonumber(opts.pos) or 0.15)
        net.WriteFloat(tonumber(ax.x) or 1)
        net.WriteFloat(tonumber(ax.y) or 1)
        net.WriteFloat(tonumber(ax.z) or 1)
        net.WriteFloat(tonumber(opts.seed) or math.random() * 1000)
    end

    net.Send(recipients)
end

function SHIBI.ScreenShakeAt(pos, amp, freq, dur, radius)
    if not isvector(pos) then return end
    amp = math.Clamp(tonumber(amp) or 2, 0, 25)
    freq = math.Clamp(tonumber(freq) or 5, 0.01, 50)
    dur = math.max(tonumber(dur) or 0.5, 0)
    radius = math.max(tonumber(radius) or 512, 0)
    util.ScreenShake(pos, amp, freq, dur, radius)
end

SHIBI.HitLib = SHIBI.HitLib or {}
local DEFAULTS = {
    allowNPC = true,
    allowNext = true,
    allowPly = true,
    teamCheck = true,
    withLagComp = true,
    zClamp = false,
    debug = true,
}

local function IsCombatTarget(ent)
    return IsValid(ent) and (ent:IsPlayer() or ent:IsNPC() or ent:IsNextBot())
end

local function SameTeamBlocked(att, vic)
    if not (SHIBI.SameFraction and SHIBI.PVP and SHIBI.PVP.CheckMode) then return false end
    return SHIBI.SameFraction(att, vic) and not SHIBI.PVP:CheckMode(att, vic)
end

local function IsVisible(fromPos, toPos, filter, target)
    local tr = util.TraceLine({
        start = fromPos,
        endpos = toPos,
        filter = filter,
        mask = MASK_SHOT_HULL
    })

    return not tr.Hit or tr.Entity == target
end

local function CanHitTarget(attacker, target, fromPos)
    if not IsValid(attacker) or not IsValid(target) then return false end

    local filter = {attacker}
    if attacker.GetActiveWeapon and IsValid(attacker:GetActiveWeapon()) then
        table.insert(filter, attacker:GetActiveWeapon())
    end

    local targetPos = target:WorldSpaceCenter()

    local points = {
        targetPos,
        targetPos + Vector(0, 0, 15),
        targetPos + Vector(0, 0, -15),
        target:GetPos() + Vector(0, 0, 35)
    }

    for _, point in ipairs(points) do
        if IsVisible(fromPos, point, filter, target) then
            return true
        end
    end

    return false
end

local function EachTargetInSphere(center, radius, fn)
    local entsIn = ents.FindInSphere(center, radius)
    for _, e in ipairs(entsIn) do
        fn(e)
    end
end

local function ApplyHit(attacker, victim, damage, opt)
    opt = opt or {}
    if not IsValid(attacker) or not IsValid(victim) then return end
    if opt.teamCheck ~= false and SameTeamBlocked(attacker, victim) then return end

    if opt.checkVisibility ~= false then
        local fromPos = opt.attackOrigin or attacker:EyePos()
        if not CanHitTarget(attacker, victim, fromPos) then
            return
        end
    end

    local dealt = SHIBI.DealDamageNoKnock(victim, damage or 10, attacker, opt.dmg)
    if dealt <= 0 then return end
    if opt.knock and opt.knock.force == true then
        local knock = opt.knock
        local power = knock.power or 0
        local up = knock.up or 0
        if power ~= 0 then
            local dir = (victim:GetPos() - attacker:GetPos()):GetNormalized()
            dir.z = dir.z + up
            victim:SetVelocity(dir * power)
        end
    end

    if opt.on_hit then
        local ok, err = pcall(opt.on_hit, attacker, victim, dealt, opt)
        if not ok then ErrorNoHalt("[HitLib] on_hit error: ", err, "\n") end
    end
end

local function StartLagComp(attacker, on)
    if not IsValid(attacker) then return end
    if on and attacker.StartLagCompensation then attacker:StartLagCompensation() end
    if (on == false) and attacker.EndLagCompensation then attacker:EndLagCompensation() end
end

local function SendHB(owner, kind, data, opt)
    if opt and opt.debug == false then return end
    if not SHIBI or not SHIBI.Debug or not SHIBI.Debug.SendHitbox then return end
    SHIBI.Debug:SendHitbox(owner, kind, data)
end

function SHIBI.HitLib.Cone(ent, ticks, tick_delay, startPos, aim, angle, distance, radius, damage, opt)
    if not IsValid(ent) then return end
    opt = table.Merge(table.Copy(DEFAULTS), opt or {})
    local attacker = ent:IsPlayer() and ent or ent:GetOwner()
    if not IsValid(attacker) then attacker = ent end

    opt.attackOrigin = startPos

    local start = startPos or ent:GetPos()
    local dir = aim and aim:GetNormalized() or (ent:IsPlayer() and ent:GetAimVector() or ent:GetForward())
    local rad = radius or distance or 150
    local ang = math.max(0, angle or 60)
    local dist = distance or rad

    SendHB(attacker, "cone", {
        startPos = start,
        aim = dir,
        radius = rad,
        angle = ang,
        distance = dist
    }, opt)

    if opt.withLagComp then StartLagComp(attacker, true) end

    EachTargetInSphere(start, rad, function(target)
        if not IsCombatTarget(target) then return end
        if target == attacker then return end
        local to = target:GetPos() - start
        local plan = Vector(to.x, to.y, opt.zClamp and 0 or to.z)
        if plan:Length() > dist then return end
        local d = plan:GetNormalized()
        local dp = math.Clamp(d:Dot(dir), -1, 1)
        local deg = math.deg(math.acos(dp))
        if deg <= ang then
            ApplyHit(attacker, target, damage or 10, opt)
        end
    end)

    if opt.withLagComp then StartLagComp(attacker, false) end
    if opt.on_done then opt.on_done() end
end

function SHIBI.HitLib.Sphere(ent, ticks, tick_delay, radius, pos, damage, opt)
    if not IsValid(ent) then return end
    opt = table.Merge(table.Copy(DEFAULTS), opt or {})
    local attacker = ent:IsPlayer() and ent or ent:GetOwner()
    if not IsValid(attacker) then attacker = ent end
    pos = pos or ent:GetPos()

    opt.attackOrigin = pos

    local rad = radius or 120

    SendHB(attacker, "sphere", {
        pos = pos,
        radius = rad
    }, opt)

    if opt.withLagComp then StartLagComp(attacker, true) end

    EachTargetInSphere(pos, rad, function(target)
        if not IsCombatTarget(target) then return end
        if target == attacker then return end
        ApplyHit(attacker, target, damage or 10, opt)
    end)

    if opt.withLagComp then StartLagComp(attacker, false) end
    if opt.on_done then opt.on_done() end
end

function SHIBI.HitLib.Ray(ent, ticks, tick_delay, origin, dir, dist, thickness, damage, opt)
    if not IsValid(ent) then return end
    opt = table.Merge(table.Copy(DEFAULTS), opt or {})
    local attacker = ent:IsPlayer() and ent or ent:GetOwner()
    if not IsValid(attacker) then attacker = ent end
    dir = dir and dir:GetNormalized() or (ent:IsPlayer() and ent:GetAimVector() or ent:GetForward())
    origin = origin or (ent.EyePos and ent:EyePos() or ent:GetPos())
    dist = dist or 200
    thickness = thickness or 8

    opt.attackOrigin = origin

    SendHB(attacker, "ray", {
        origin = origin,
        dir = dir,
        dist = dist,
        thickness = thickness
    }, opt)

    if opt.withLagComp then StartLagComp(attacker, true) end

    local tr = util.TraceHull({
        start = origin,
        endpos = origin + dir * dist,
        mins = Vector(-thickness, -thickness, -thickness),
        maxs = Vector(thickness, thickness, thickness),
        filter = attacker
    })

    if IsValid(tr.Entity) and IsCombatTarget(tr.Entity) and tr.Entity ~= attacker then
        ApplyHit(attacker, tr.Entity, damage or 10, opt)
    end

    if opt.withLagComp then StartLagComp(attacker, false) end
    if opt.on_done then opt.on_done() end
end

function SHIBI.HitLib.Box(ent, ticks, tick_delay, center, extents, damage, opt)
    if not IsValid(ent) then return end
    opt = table.Merge(table.Copy(DEFAULTS), opt or {})
    local attacker = ent:IsPlayer() and ent or ent:GetOwner()
    if not IsValid(attacker) then attacker = ent end
    center = center or ent:GetPos()
    extents = extents or Vector(60, 60, 60)

    opt.attackOrigin = center

    local mins = center - extents
    local maxs = center + extents
    local dmg = damage or 10

    SendHB(attacker, "box", {
        center = center,
        extents = extents
    }, opt)

    if opt.withLagComp then StartLagComp(attacker, true) end

    local candidates = ents.FindInBox(mins, maxs)
    for _, target in ipairs(candidates) do
        if target ~= attacker and IsCombatTarget(target) and not (opt.teamCheck ~= false and SameTeamBlocked(attacker, target)) then
            ApplyHit(attacker, target, dmg, opt)
        end
    end

    if opt.withLagComp then StartLagComp(attacker, false) end
    if opt.on_done then opt.on_done() end
end

util.AddNetworkString("SHIBI::Particle::Aura")
util.AddNetworkString("SHIBI::Particle::Beam")
util.AddNetworkString("SHIBI::Particle::Effect")
util.AddNetworkString("SHIBI::Particle::Stop")

function SHIBI.ParticleAura(ply, particle, time, attach)
    if not IsValid(ply) then return end
    attach = attach or 4
    time = time or 1
    net.Start("SHIBI::Particle::Aura")
    net.WriteEntity(ply)
    net.WriteString(particle)
    net.WriteFloat(time)
    net.WriteUInt(attach, 8)
    net.Broadcast()
end

function SHIBI.ParticleBeam(ply, target, particle, time)
    if not IsValid(ply) or not IsValid(target) then return end
    time = time or 1
    net.Start("SHIBI::Particle::Beam")
    net.WriteEntity(ply)
    net.WriteEntity(target)
    net.WriteString(particle)
    net.WriteFloat(time)
    net.Broadcast()
end

function SHIBI.ParticleEffectOnPos(ply, particle, pos, ang, time)
    if not IsValid(ply) then return end
    pos = pos or ply:GetPos()
    ang = ang or Angle(0, 0, 0)
    time = time or 0.5
    net.Start("SHIBI::Particle::Effect")
    net.WriteEntity(ply)
    net.WriteString(particle)
    net.WriteVector(pos)
    net.WriteAngle(ang)
    net.WriteFloat(time)
    net.Broadcast()
end

function SHIBI.ParticleStop(ply)
    if not IsValid(ply) then return end
    net.Start("SHIBI::Particle::Stop")
    net.WriteEntity(ply)
    net.Broadcast()
end

function SHIBI.HitEffectParticle(target, particle, duration, offset)
    if not IsValid(target) then return end
    duration = duration or 0.5
    offset = offset or Vector(0, 0, 30)
    local pos = target:WorldSpaceCenter() + offset
    SHIBI.ParticleEffectOnPos(target, particle, pos, Angle(0, 0, 0), duration)
end

function SHIBI.HitEffectNet(target, particle, duration)
    if not IsValid(target) then return end
    duration = duration or 0.5
    local attach = target:GetAttachment(2)
    local pos
    if attach and attach.Pos then
        pos = attach.Pos + Vector(5, 0, -20)
    else
        pos = target:WorldSpaceCenter() + Vector(0, 0, 30)
    end
    SHIBI.ParticleEffectOnPos(target, particle, pos, target:GetAngles(), duration)
end

SHIBI.Character = SHIBI.Character or {}

function SHIBI.Character.AssembleModels(ply, bodyModel, headModel)
    if not IsValid(ply) then return end
    if not isstring(bodyModel) or not isstring(headModel) then return end
    if not util.IsValidModel(bodyModel) or not util.IsValidModel(headModel) then return end
    ply:SetModel(bodyModel)
    if IsValid(ply.SHIBI_HeadEnt) then
        ply.SHIBI_HeadEnt:Remove()
        ply.SHIBI_HeadEnt = nil
    end

    local head = ents.Create("prop_dynamic")
    head:SetModel(headModel)
    head:SetPos(ply:GetPos())
    head:Spawn()
    head:SetParent(ply)
    head:AddEffects(EF_BONEMERGE)
    head:SetMoveType(MOVETYPE_NONE)
    head:SetSolid(SOLID_NONE)
    head:SetCollisionGroup(COLLISION_GROUP_IN_VEHICLE)
    local headBone = ply:LookupBone("ValveBiped.Bip01_Head1")
    if headBone then
        head:SetParent(ply, headBone)
        head:AddEffects(EF_FOLLOWBONE)
    end

    ply.SHIBI_HeadEnt = head

    SHIBI.Log("[Character] Собран: " .. bodyModel .. " + " .. headModel)
end

function SHIBI.Character.HideBodyHead(ply)
    if not IsValid(ply) then return end
    local headBone = ply:LookupBone("ValveBiped.Bip01_Head1")
    if not headBone then return end
    for i = 0, (ply:GetNumBodyGroups() or 0) - 1 do
        local name = ply:GetBodygroupName(i)
        if name and string.find(string.lower(name), "head") then
            ply:SetBodygroup(i, 0)
        end
    end
end

if not SERVER then return end

SHIBI.Stamina = SHIBI.Stamina or {}

local MAX_MANA = 120
local REGEN_DELAY = 2
local REGEN_PER_SECOND = 5

local function SafeNumber(value, fallback)
    value = tonumber(value)
    if not value or value ~= value or value == math.huge or value == -math.huge then return fallback end
    return value
end

local function Sync(ply)
    if not IsValid(ply) then return end
    ply:SetNWFloat("SHIBI::Mana", math.Clamp(SafeNumber(ply.SHIBI_Mana, MAX_MANA), 0, MAX_MANA))
    ply:SetNWFloat("SHIBI::MaxMana", MAX_MANA)
end

function SHIBI.Stamina.Set(ply, value)
    if not IsValid(ply) then return false end
    ply.SHIBI_Mana = math.Clamp(SafeNumber(value, 0), 0, MAX_MANA)
    Sync(ply)
    return true
end

function SHIBI.Stamina.Add(ply, amount)
    if not IsValid(ply) then return false end
    return SHIBI.Stamina.Set(ply, (ply.SHIBI_Mana or 0) + SafeNumber(amount, 0))
end

function SHIBI.Stamina.TrySpend(ply, amount)
    amount = SafeNumber(amount, -1)
    if not IsValid(ply) or amount < 0 or (ply.SHIBI_Mana or 0) < amount then return false end
    local success = SHIBI.Stamina.Set(ply, ply.SHIBI_Mana - amount)
    if success then ply.SHIBI_NextManaRegen = CurTime() + REGEN_DELAY end
    return success
end

hook.Add("PlayerInitialSpawn", "SHIBI::Stamina::Initialize", function(ply)
    ply.SHIBI_Mana = MAX_MANA
    Sync(ply)
end)

hook.Add("PlayerSpawn", "SHIBI::Stamina::Reset", function(ply)
    timer.Simple(0, function()
        if not IsValid(ply) then return end
        ply.SHIBI_Mana = MAX_MANA
        Sync(ply)
    end)
end)

timer.Create("SHIBI::Stamina::Sync", 0.1, 0, function()
    for _, ply in ipairs(player.GetAll()) do
        if (ply.SHIBI_Mana or MAX_MANA) < MAX_MANA and CurTime() >= (ply.SHIBI_NextManaRegen or 0) then
            ply.SHIBI_Mana = math.min(MAX_MANA, (ply.SHIBI_Mana or 0) + REGEN_PER_SECOND)
        end
        Sync(ply)
    end
end)

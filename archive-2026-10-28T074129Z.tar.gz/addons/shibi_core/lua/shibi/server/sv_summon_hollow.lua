if not SERVER then return end

local S = SHIBI.Summon or {}
SHIBI.Summon = S

util.PrecacheModel("models/evo/summons/hollow/evo_fs2wj3jqv1s0/evo_0p4elh8ixozh106.mdl")

local CFG = {
    model        = "models/evo/summons/hollow/evo_fs2wj3jqv1s0/evo_0p4elh8ixozh106.mdl",
    anim         = "debut",
    height       = 220,
    landAt       = 0.45,
    landParticle = "[*]_stunning_effect",
    landTime     = 1.5,
    scene        = "hollow_debut",
    sceneRadius  = 1200,
    cleanupDelay = 1.0,
}

local function GroundBelow(pos)
    local tr = util.TraceLine({
        start  = pos + Vector(0, 0, 64),
        endpos = pos - Vector(0, 0, 8192),
        mask   = MASK_SOLID_BRUSHONLY,
    })
    return tr.HitPos
end

function S.Hollow(pos, ang)
    ang = ang or angle_zero
    local landPos = GroundBelow(pos)
    local yaw = Angle(0, ang.y, 0)

    local mon = ents.Create("prop_dynamic")
    if not IsValid(mon) then return false end
    mon:SetModel(CFG.model)
    mon:SetPos(landPos + Vector(0, 0, CFG.height))
    mon:SetAngles(yaw)
    mon:Spawn()

    local seq = mon:LookupSequence(CFG.anim)
    if seq and seq >= 0 then
        mon:ResetSequence(seq)
        mon:SetCycle(0)
    end

    local timerName = "SHIBI::Summon::Fall::" .. mon:EntIndex()
    local started = CurTime()
    timer.Create(timerName, 0, 0, function()
        if not IsValid(mon) then
            timer.Remove(timerName)
            return
        end

        local t = CurTime() - started
        if t >= CFG.landAt then
            timer.Remove(timerName)
            mon:SetPos(landPos)
            SHIBI.ParticleEffectOnPos(mon, CFG.landParticle, landPos, angle_zero, CFG.landTime)
            return
        end

        local k = (t / CFG.landAt) ^ 2
        mon:SetPos(landPos + Vector(0, 0, CFG.height * (1 - k)))
    end)

    local started = SHIBI.Cutscene.PlayAt(landPos, ang.y, CFG.scene, { radius = CFG.sceneRadius, focus = mon })
    if not started then
        print("[Summon] hollow: рядом нет зрителей, сцена не запущена")
    end

    local sceneLength = SHIBI.Cutscene.Scenes[CFG.scene].duration
    timer.Simple(sceneLength + CFG.cleanupDelay, function()
        if IsValid(mon) then mon:Remove() end
    end)

    return true
end

concommand.Add("shibi_summon_hollow", function(ply)
    if IsValid(ply) and not ply:IsSuperAdmin() then return end
    if not IsValid(ply) then return end

    local tr = ply:GetEyeTrace()
    local pos = tr.HitPos
    local ok = S.Hollow(pos, Angle(0, ply:EyeAngles().y + 180, 0))
    ply:PrintMessage(HUD_PRINTCONSOLE, "[Summon] hollow: " .. (ok and "ok" or "не удалось") .. "\n")
end)

util.AddNetworkString("SHIBI::Action::Start")
util.AddNetworkString("SHIBI::Action::Stop")

local meta = FindMetaTable("Player")

function meta:StartTimeAction(time)
    time = tonumber(time) or 0
    if time ~= time or time == math.huge or time == -math.huge then return end
    time = math.Clamp(math.floor(time), 0, 3600)
    net.Start("SHIBI::Action::Start")
    net.WriteInt(time, 32)
    net.Send(self)
end

function meta:RemoveTimeAction()
    net.Start("SHIBI::Action::Stop")
    net.Send(self)
end

SHIBI.Log("[Util] Серверные утилиты загружены")

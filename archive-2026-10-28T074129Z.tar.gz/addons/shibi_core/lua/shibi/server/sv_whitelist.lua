if not SERVER then return end

-- богдан я думаю ты сам понимаешь как этим пользоваться
SHIBI.Config.Whitelist = {
    "STEAM_0:1:573918740", -- Тамик
    "STEAM_0:0:237705477", -- Митсу
    "STEAM_0:0:534145593", -- Хикан
    "STEAM_0:0:423135493", -- Хакари владосикс
}

local allowed = {}

local function ToSteamID64(id)
    id = string.Trim(id)
    if id:match("^%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d$") then
        return id
    end

    if id:match("^STEAM_%d:%d:%d+$") then
        local sid64 = util.SteamIDTo64(id)
        if isstring(sid64) and sid64 ~= "" and sid64 ~= "0" then
            return sid64
        end
    end

    return nil
end

for _, id in ipairs(SHIBI.Config.Whitelist) do
    local sid64 = ToSteamID64(tostring(id))

    if sid64 then
        allowed[sid64] = true
    else
        SHIBI.LogWarning("[Whitelist] кривой SteamID: " .. tostring(id))
    end
end

local count = table.Count(allowed)

if count == 0 then
    SHIBI.LogError("[Whitelist] список пуст — пускаю всех, чтобы не залочить сервер")
else
    SHIBI.Log("[Whitelist] загружено SteamID: " .. count)
end

hook.Add("CheckPassword", "SHIBI::Whitelist", function(steamid64, _, _, _, name)
    if count == 0 then return end
    if allowed[steamid64] then return end
    local steamID = util.SteamIDFrom64(steamid64)
    SHIBI.LogWarning("[Whitelist] отказ: " .. tostring(name) .. " (" .. steamid64 .. " / " .. steamID .. ")")
    return false, "Тебя нет в вайтлисте этого сервера. Твой SteamID: " .. steamID
end)

local IsValid = IsValid
local isstring = isstring
local isnumber = isnumber
local tonumber = tonumber
local FindMetaTable = FindMetaTable

local hook_Add = hook.Add
local string_gsub = string.gsub
local system_IsWindows = system.IsWindows
local concommand_Remove = concommand.Remove
local constraint_RemoveAll = constraint.RemoveAll

local meta = FindMetaTable("Player")
local aid = meta.AccountID

if system_IsWindows() then
    local osDate = os.date
    local replace = function(txt)
        if txt == "%%" then return txt end
        return ""
    end

    function os.date(format, time, ...)
        if isstring(format) or isnumber(format) then
            format = string_gsub(format, "%%[^aAbBcdHIjmMpSUwWxXyYz]", replace)
        elseif format ~= nil then
            argError(Val, 1, "string")
        end

        if not (time == nil or isnumber(time)) and (not isstring(time) or tonumber(time) == nil) then argError(Val, 2, "number") end
        return osDate(format, time, ...)
    end
end

if SERVER then
    local sid64 = meta.SteamID64
    function meta:SteamID64(...)
        return sid64(self, ...) or "0"
    end
end

function meta:AccountID(...)
    return aid(self, ...) or 0
end

concommand_Remove("gm_save")
hook_Add("PropBreak", "SHIBI.AntiConstraintCrash", function(attacker, ent) if IsValid(ent) and IsValid(ent:GetPhysicsObject()) then constraint_RemoveAll(ent) end end)
hook_Add("PlayerSwitchFlashlight", "BlockFlashLight", function(ply, enabled) return SHIBI.Config.FlashlightOn end)

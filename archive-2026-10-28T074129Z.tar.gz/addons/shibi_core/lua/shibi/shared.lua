_G.SHIBI = _G.SHIBI or {}
SHIBI.Config = SHIBI.Config or {
    Language = "ru",
    LogPrefixCol = Color(52, 168, 235),
    LogMessageCol = Color(255, 255, 255),
    LogWarningCol = Color(242, 141, 24),
    LogErrorCol = Color(230, 60, 60),
    FlashlightOn = false,
    VoiceWhenDead = false,
    EnableDecalCleaner = true,
    FirstPersonDeathView = true,
}

SHIBI.Config.Database = {
    EnableMySQL = false,
    Host = "127.0.0.1",
    Username = "root",
    Password = nil,
    Database = "shibi",
    Port = 3306,
}

SHIBI.Languages = SHIBI.Languages or {}
SHIBI.Util = SHIBI.Util or {}
SHIBI.InvertControls = SHIBI.InvertControls or {}
SHIBI.Entities = SHIBI.Entities or {}
SHIBI.DMG_CUSTOM = SHIBI.DMG_CUSTOM or {}
SHIBI.DMG_CUSTOM.OWNED_VIA_ENTITY = SHIBI.DMG_CUSTOM.OWNED_VIA_ENTITY or 424243

SHIBI.Version = "1.0.0"
SHIBI._refreshState = SHIBI._refreshState or {
    BootCount = 0,
    LastBootTime = os.clock(),
}

SHIBI.BootCount = SHIBI._refreshState.BootCount + 1
SHIBI._refreshState.BootCount = SHIBI.BootCount
SHIBI._refreshState.LastBootTime = SHIBI.BootTime
SHIBI.BootComplete = false

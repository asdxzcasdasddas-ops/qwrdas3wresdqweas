if SERVER then
    AddCSLuaFile()
end

SWEP.PrintName = "SHIBI HoldType Test"
SWEP.Author = "SHIBI"
SWEP.Category = "SHIBI"
SWEP.Spawnable = true
SWEP.AdminOnly = true

SWEP.UseHands = true
SWEP.ViewModel = "models/weapons/c_arms.mdl"
SWEP.WorldModel = ""
SWEP.DrawAmmo = false
SWEP.DrawCrosshair = false

SWEP.Slot = 0
SWEP.SlotPos = 1

SWEP.Primary = {
    ClipSize = -1,
    DefaultClip = -1,
    Automatic = false,
    Ammo = "none",
}

SWEP.Secondary = {
    ClipSize = -1,
    DefaultClip = -1,
    Automatic = false,
    Ammo = "none",
}

SWEP.ShibiHoldType = "test"

function SWEP:Initialize()
    self:SetHoldType("normal")
end

function SWEP:PrimaryAttack()
end

function SWEP:SecondaryAttack()
end

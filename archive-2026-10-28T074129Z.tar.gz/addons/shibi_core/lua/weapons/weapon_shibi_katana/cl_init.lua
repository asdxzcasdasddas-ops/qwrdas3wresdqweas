include("shared.lua")

function SWEP:DrawWorldModel()
    local ply = self:GetOwner()
    if not IsValid(ply) or ply:GetActiveWeapon() ~= self then
        self:RemoveKatanaModel()
        return
    end

    local mdl = self.KatanaClientside
    if not IsValid(mdl) then
        mdl = ClientsideModel(self.KatanaModel, RENDERGROUP_OPAQUE)
        if not IsValid(mdl) then return end
        mdl:SetParent(ply)
        mdl:AddEffects(EF_BONEMERGE)
        mdl:SetNoDraw(true)
        self.KatanaClientside = mdl
    end

    if mdl:GetParent() ~= ply then
        mdl:SetParent(ply)
    end
    mdl:DrawModel()
end

function SWEP:RemoveKatanaModel()
    if IsValid(self.KatanaClientside) then
        self.KatanaClientside:Remove()
    end
    self.KatanaClientside = nil
end

function SWEP:Holster()
    self:RemoveKatanaModel()
    return true
end

function SWEP:OnRemove()
    self:RemoveKatanaModel()
end

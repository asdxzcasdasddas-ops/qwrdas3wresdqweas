-- тички. тоже всё.
AddCSLuaFile("cl_init.lua")
AddCSLuaFile("shared.lua")

include("shared.lua")

local K = SHIBI.Katana
local NW, MODE = K.NW, K.MODE

K.Juggled = K.Juggled or {}
K.StunTokens = K.StunTokens or setmetatable({}, {__mode = "k"})

local function SetAir(ent, mode, untilTime, partner, isVictim)
    ent:SetNW2Vector(NW.ENTRY, ent:GetVelocity())
    ent:SetNW2Int(NW.MODE, mode)
    ent:SetNW2Float(NW.SINCE, CurTime())
    ent:SetNW2Float(NW.UNTIL, untilTime)
    ent:SetNW2Float(NW.STOP, 0)
    ent:SetNW2Float(NW.BUMP, 0)
    ent:SetNW2Entity(NW.PARTNER, partner)
    ent:SetNW2Bool(NW.VICTIM, isVictim)
    ent:SetGroundEntity(NULL)
    K.Juggled[ent] = true
end

function K.Clear(ent, forceUnstun)
    if not IsValid(ent) then return end

    K.Juggled[ent] = nil
    local wasAirVictim = ent:GetNW2Bool(NW.VICTIM, false)
    ent:SetNW2Int(NW.MODE, MODE.NONE)
    ent:SetNW2Entity(NW.PARTNER, NULL)
    ent:SetNW2Bool(NW.VICTIM, false)
    ent:SetNW2Float(NW.STOP, 0)
    ent:SetNW2Float(NW.UNTIL, 0)
    ent:SetNW2Float(NW.BUMP, 0)
    ent:SetNW2Vector(NW.ENTRY, vector_origin)
    if ent:IsPlayer() and ent:GetMoveType() == MOVETYPE_NONE then
        ent:SetMoveType(MOVETYPE_WALK)
    end
    ent.SHIBI_NoFallUntil = CurTime() + 1.5

    if ent:IsPlayer() then
        local token = K.StunTokens[ent]
        if token then
            SHIBI.UnstunPlayer(ent, token)
        end
        if forceUnstun or wasAirVictim then

            SHIBI.UnstunPlayer(ent)
        end
        if forceUnstun then
            ent:Freeze(false)
            if ent:GetMoveType() == MOVETYPE_NONE then
                ent:SetMoveType(MOVETYPE_WALK)
            end
        end
        K.StunTokens[ent] = nil
    end
end

local function ApplyAirStun(victim, duration)
    if not (IsValid(victim) and victim:IsPlayer()) then return end
    local token = SHIBI.StunPlayer(victim, duration)
    if token then K.StunTokens[victim] = token end
end

function K.Release(ent)
    if not IsValid(ent) then return end
    local partner = ent:GetNW2Entity(NW.PARTNER)
    if IsValid(partner) then
        local isVictim = ent:GetNW2Bool(NW.VICTIM, false)
        local attacker = isVictim and partner or ent
        local victim = isVictim and ent or partner
        K.NudgeApart(attacker, victim)
    end
    K.Clear(ent, true)
    K.Clear(partner, true)
end

local function Punch(ent, p, y, r)
    if not (IsValid(ent) and ent:IsPlayer()) then return end
    ent:ViewPunch(Angle(
        p * math.Rand(0.8, 1.2),
        y * math.Rand(0.8, 1.2),
        (r or 0) * math.Rand(0.8, 1.2)
    ))
end

local function PunchT(ent, t)
    if t then Punch(ent, t[1], t[2], t[3]) end
end

local function PlayVictimAnim(victim, seq, time)
    if IsValid(victim) and victim:IsPlayer() and isstring(seq) then
        SHIBI.Anim.Play(victim, seq, 1, false, time)
    end
end

local function HitSide(ply, victim)
    local toVictim = victim:GetPos() - ply:GetPos()
    toVictim.z = 0
    if toVictim:LengthSqr() < 1 then return "f" end

    local dot = ply:EyeAngles():Right():Dot(toVictim:GetNormalized())
    if dot > 0.35 then return "l" end
    if dot < -0.35 then return "r" end
    return "f"
end

local function IsFriendly(ply, victim)
    if not (SHIBI.SameFraction and SHIBI.PVP and SHIBI.PVP.CheckMode) then return false end
    return SHIBI.SameFraction(ply, victim) and not SHIBI.PVP:CheckMode(ply, victim)
end

local function IsAliveTarget(ent)
    if not IsValid(ent) or ent:Health() <= 0 then return false end
    if ent:IsPlayer() then return ent:Alive() end
    return ent:IsNPC() or ent:IsNextBot()
end

local function HitFX(ply, victim, cfg)
    SHIBI.HitEffectParticle(victim, cfg.HitParticle, cfg.ParticleTime, vector_origin)
    SHIBI.SoundPlay(ply, SHIBI.GetHitSound(), 80, math.random(95, 110))
end

function SWEP:Schedule(delay, fn)
    self.Pending = {at = CurTime() + delay, fn = fn}
end

function SWEP:RunPending()
    local p = self.Pending
    if not p or CurTime() < p.at then return end
    self.Pending = nil
    local ok, err = pcall(p.fn)
    if not ok then SHIBI.LogError("[Katana] " .. tostring(err)) end
end

function SWEP:GetComboStep()
    if #self.Combo == 0 then return nil end

    local now = CurTime()
    if now < (self.GroundComboUntil or 0) then return nil end
    if now - (self.LastAttack or 0) > self.ComboReset then
        self.ComboIndex = 1
    end
    self.LastAttack = now

    local index = math.Clamp(self.ComboIndex or 1, 1, #self.Combo)
    if index == #self.Combo then
        self.ComboIndex = 1
        self.GroundComboUntil = now + self.GroundComboCooldown
        self:SetNextPrimaryFire(math.max(self:GetNextPrimaryFire(), self.GroundComboUntil))
    else
        self.ComboIndex = index + 1
    end
    return self.Combo[index]
end

function SWEP:GroundAttack(ply)
    if SHIBI.IsStunned(ply) then return end
    local step = self:GetComboStep()
    if not step then
        self:SetNextPrimaryFire(math.max(self:GetNextPrimaryFire(), self.GroundComboUntil or 0))
        return
    end

    ply:SetAnim(step.seq, 1, false, self.HitAnimTime)
    self:SetNW2Float(self.NWComboUntil, CurTime() + self.ComboReset)

    self:Schedule(self.HitTime, function()
        if not ply:Alive() then return end

        local origin = ply:WorldSpaceCenter()
        local aim = ply:GetAimVector()
        aim.z = 0
        aim:Normalize()

        local landed = false
        SHIBI.HitLib.Cone(ply, 1, 0, origin, aim, step.angle or 50, step.range, step.range, step.damage, {
            debug = false,
            zClamp = true,
            on_hit = function(_, victim)
                landed = true
                PlayVictimAnim(victim, self.HitAnims[HitSide(ply, victim)] or self.HitAnims.f, self.HitAnimTime)
                Punch(victim, 3, math.Rand(-2, 2), math.Rand(-2, 2))
                HitFX(ply, victim, self.Air)
            end,
        })

        if landed then
            PunchT(ply, step.punch)
        else
            SHIBI.SoundPlay(ply, SHIBI.GetMissSound(), 70)
        end
    end)
end

function SWEP:TryLaunch(ply)
    local cfg = self.Air
    local now = CurTime()

    if now < (self.NextLaunch or 0) then return end

    if ply:InVehicle() or ply:GetMoveType() == MOVETYPE_NOCLIP or SHIBI.IsStunned(ply) then return end
    if K.GetMode(ply) ~= MODE.NONE or IsValid(self.AirTarget) then return end

    local victim = SHIBI.FindAimTarget(ply, cfg.Range, 10, 0.8)
    if not IsAliveTarget(victim) or IsFriendly(ply, victim) then return end
    if K.GetMode(victim) ~= MODE.NONE then return end
    if victim:IsPlayer() and (victim:InVehicle() or victim:GetMoveType() == MOVETYPE_NOCLIP) then return end
    if not SHIBI.Stamina.TrySpend(ply, cfg.StaminaCost) then return end

    self.NextLaunch = now + cfg.Cooldown
    ply:SetAnim(cfg.LaunchSeq, 1, false, cfg.LaunchAnimTime)
    Punch(ply, 1.5, 0, 0)

    self:Schedule(cfg.LaunchDelay, function()
        if not ply:Alive() or not IsAliveTarget(victim) then return end
        if K.GetMode(victim) ~= MODE.NONE then return end
        if ply:GetPos():DistToSqr(victim:GetPos()) > (cfg.Range + 60) ^ 2 then return end

        if SHIBI.DealDamageNoKnock(victim, cfg.LaunchDamage, ply) <= 0 then return end
        if not IsAliveTarget(victim) then return end

        local untilTime = CurTime() + cfg.RiseTime + cfg.HangTime
        SetAir(ply, MODE.AIR, untilTime, victim, false)
        SetAir(victim, MODE.AIR, untilTime, ply, true)

        ApplyAirStun(victim, cfg.MaxAirTime + 0.5)

        self.AirTarget = victim
        self.AirHits   = 0
        self.AirStart  = CurTime()
        self.LastAirHit = self.AirStart
        self.AirEnding = false
        self.Slamming  = false
        self:SetNW2Float(self.NWAirUntil, untilTime)

        PlayVictimAnim(victim, self.HitAnims.f, cfg.RiseTime + 0.3)
        HitFX(ply, victim, cfg)
        Punch(ply, -6, math.Rand(-1, 1), 0)
        Punch(victim, -9, math.Rand(-3, 3), math.Rand(-4, 4))
        SHIBI.ScreenShake(ply, 1.2, 8, 0.25)
    end)
end

function SWEP:TryAirGrab(ply)
    if not IsValid(ply) or not ply:Alive() or self.AirEnding or self.Slamming then return end
    if not IsValid(self.AirTarget) or K.GetMode(ply) ~= MODE.AIR then return end

    local cfg = self.Air
    local victim = SHIBI.FindAimTarget(ply, cfg.Range, 10, 0.8)
    if not IsAliveTarget(victim) or victim == self.AirTarget or IsFriendly(ply, victim) then return end
    if K.GetMode(victim) ~= MODE.NONE then return end
    if victim:IsPlayer() and (victim:InVehicle() or victim:GetMoveType() == MOVETYPE_NOCLIP) then return end

    if SHIBI.DealDamageNoKnock(victim, cfg.LaunchDamage, ply) <= 0 then return end
    if not IsAliveTarget(victim) then return end

    K.Clear(self.AirTarget)
    local untilTime = math.max(ply:GetNW2Float(NW.UNTIL, 0), CurTime() + cfg.ExtendPerHit)
    SetAir(victim, MODE.AIR, untilTime, ply, true)
    ApplyAirStun(victim, cfg.MaxAirTime + 0.5)

    self.AirTarget = victim
    self.LastAirHit = CurTime()
    self.AirStart = math.min(self.AirStart or CurTime(), CurTime())
    self:SetNW2Float(self.NWAirUntil, untilTime)
    PlayVictimAnim(victim, self.HitAnims.f, cfg.RiseTime + 0.3)
    HitFX(ply, victim, cfg)
    Punch(ply, -2, math.Rand(-1, 1), 0)
    Punch(victim, -4, math.Rand(-3, 3), math.Rand(-4, 4))
end

function SWEP:AirValid(ply)
    return not self.AirEnding and IsValid(ply) and ply:Alive()
        and ply:GetActiveWeapon() == self
        and K.GetMode(ply) ~= MODE.NONE
        and not SHIBI.IsStunned(ply)
        and IsAliveTarget(self.AirTarget)
end

function SWEP:AirAttack(ply)
    if not self:AirValid(ply) or self.Slamming then return end

    local cfg = self.Air
    self.AirHits = (self.AirHits or 0) + 1
    if self.AirHits > #cfg.Hits then
        self:StartSlam(ply)
        return
    end

    local hit = cfg.Hits[self.AirHits]
    local victim = self.AirTarget
    ply:SetAnim(hit.seq, 1, false, hit.time)

    self:Schedule(cfg.HitDelay, function()
        if not self:AirValid(ply) then return end
        if ply:GetPos():DistToSqr(victim:GetPos()) > cfg.AirRange ^ 2 then
            SHIBI.SoundPlay(ply, SHIBI.GetMissSound(), 70)
            return
        end
        local dealt = SHIBI.DealDamageNoKnock(victim, hit.damage, ply)
        if dealt <= 0 then return end

        if not IsAliveTarget(victim) or not IsValid(ply) or not ply:Alive() then
            self:EndAir()
            return
        end

        local now = CurTime()
        self.LastAirHit = now
        local untilTime = math.min(
            self.AirStart + cfg.MaxAirTime,
            math.max(ply:GetNW2Float(NW.UNTIL, 0), now + cfg.ExtendPerHit)
        )

        ply:SetNW2Float(NW.UNTIL, untilTime)
        victim:SetNW2Float(NW.UNTIL, untilTime)
        self:SetNW2Float(self.NWAirUntil, untilTime)

        PlayVictimAnim(victim, self.HitAnims[HitSide(ply, victim)] or self.HitAnims.f, 0.4)
        HitFX(ply, victim, cfg)
                                                                                           
        PunchT(ply, hit.punch)
        Punch(victim, 4, math.Rand(-3, 3), math.Rand(-5, 5))
    end)
end

function SWEP:StartSlam(ply)
    if not self:AirValid(ply) or self.Slamming then return end

    local cfg = self.Air
    local victim = self.AirTarget
    self.Slamming = true

    ply:SetAnim(cfg.SlamSeq, 1, false, cfg.SlamAnimTime)
    Punch(ply, -3, 0, 0)

    local hold = CurTime() + cfg.SlamDelay + 0.1
    for _, ent in ipairs({ply, victim}) do
        ent:SetNW2Float(NW.UNTIL, math.max(ent:GetNW2Float(NW.UNTIL, 0), hold))
    end

    self:Schedule(cfg.SlamDelay, function()
        if not self:AirValid(ply) then self:EndAir() return end

        SHIBI.DealDamageNoKnock(victim, cfg.SlamDamage, ply)

        if not IsAliveTarget(victim) or not IsValid(ply) or not ply:Alive() then
            if IsValid(ply) and ply:Alive() then

                local vel = ply:GetVelocity()
                vel.z = math.min(vel.z, -self.Air.SlamSpeed)
                ply:SetVelocity(vel - ply:GetVelocity())
            end
            self:EndAir()
            return
        end

        local now = CurTime()
        local stop = now + cfg.HitStop * 1.6
        for _, ent in ipairs({ply, victim}) do
            ent:SetNW2Vector(NW.ENTRY, ent:GetVelocity())
            ent:SetNW2Int(NW.MODE, MODE.SLAM)
            ent:SetNW2Float(NW.SINCE, now)
            ent:SetNW2Float(NW.STOP, stop)
            ent:SetNW2Float(NW.UNTIL, now + cfg.SlamTimeout)
        end

        self.SlamUntil = now + math.max(cfg.SlamTimeout, 3.0)

        HitFX(ply, victim, cfg)
        Punch(ply, 6, 0, math.Rand(-3, 3))
        Punch(victim, 10, math.Rand(-4, 4), math.Rand(-6, 6))
    end)
end

function SWEP:Impact(ply)
    local cfg = self.Air
    local victim = self.AirTarget
    local pos = victim:GetPos()

    K.NudgeApart(ply, victim)
    self:EndAir()

    SHIBI.HitLib.Sphere(ply, 1, 0, cfg.SplashRadius, pos + Vector(0, 0, 30), cfg.SplashDamage, {
        debug = false,
        checkVisibility = false,
        on_hit = function(_, hitEnt)
            Punch(hitEnt, 8, math.Rand(-4, 4), math.Rand(-6, 6))
        end,
    })

    if victim:IsPlayer() then
        ApplyAirStun(victim, cfg.SlamStun)
        PlayVictimAnim(victim, cfg.KnockdownSeq, cfg.SlamStun)
    end

    SHIBI.ParticleEffectOnPos(ply, cfg.LandParticle, pos, angle_zero, cfg.ParticleTime)
    SHIBI.ScreenShakeAt(pos, 6, 12, 0.45, 450)
    SHIBI.SoundPlay(victim, SHIBI.GetHitSound(), 90, 70)
    Punch(ply, 8, 0, math.Rand(-4, 4))

end

function SWEP:EndAir()
    local hadAirCombo = IsValid(self.AirTarget)
    local ply = self:GetOwner()
    if IsValid(ply) then K.Clear(ply, true) end
    K.Clear(self.AirTarget, true)

    if hadAirCombo then
        self.NextLaunch = math.max(self.NextLaunch or 0, CurTime() + self.Air.Cooldown)
    end

    self.AirTarget = nil
    self.AirHits   = 0
    self.LastAirHit = nil
    self.AirEnding = false
    self.Slamming  = false
    self.Pending   = nil
    self:SetNW2Float(self.NWAirUntil, 0)
end

function SWEP:Think()
    self:RunPending()
    if not self.AirTarget then return end

    local ply = self:GetOwner()
    if not IsValid(ply) or not ply:Alive() or ply:GetActiveWeapon() ~= self
        or not IsAliveTarget(self.AirTarget) then
        self:EndAir()
        return
    end
    if not self.AirEnding and SHIBI.IsStunned(ply) then
        self:EndAir()
        return
    end

    local now = CurTime()
    if self.Slamming and K.GetMode(self.AirTarget) == MODE.SLAM then
        if K.IsLanded(self.AirTarget) then
            self:Impact(ply)
        elseif now > (self.SlamUntil or 0) then
                                                                                 
            self:EndAir()
        end
    elseif not self.Slamming and not self.AirEnding
        and now - (self.LastAirHit or self.AirStart or now) >= self.Air.IdleTimeout then
                                                                                      
        self.AirEnding = true
        self.NextLaunch = math.max(self.NextLaunch or 0, now + self.Air.Cooldown)
        local releaseAt = now
        for _, ent in ipairs({ply, self.AirTarget}) do
            if IsValid(ent) then ent:SetNW2Float(NW.UNTIL, releaseAt) end
        end
        self:SetNW2Float(self.NWAirUntil, releaseAt)
    elseif self.AirEnding and now > ply:GetNW2Float(NW.UNTIL, 0) + self.Air.ExitBlend then
        self:EndAir()
    elseif not self.Slamming and not self.AirEnding
        and now > ply:GetNW2Float(NW.UNTIL, 0) + self.Air.ExitBlend then
        self:EndAir()
    end
end

function SWEP:Holster()
    self:EndAir()
    return true
end

function SWEP:OnRemove()
    self:EndAir()
end

hook.Add("Think", "SHIBI::Katana::AirThink", function()
    local now = CurTime()
    for ent in pairs(K.Juggled) do
        if not IsValid(ent) then
            K.Juggled[ent] = nil
        elseif K.GetMode(ent) == MODE.NONE then
            K.Juggled[ent] = nil
        elseif ent:IsPlayer() and not ent:Alive() then
            K.Release(ent)
        elseif K.GetMode(ent) ~= MODE.NONE and not IsValid(ent:GetNW2Entity(NW.PARTNER)) then
            K.Release(ent)
        elseif IsValid(ent:GetNW2Entity(NW.PARTNER))
            and not IsAliveTarget(ent:GetNW2Entity(NW.PARTNER)) then
            K.Release(ent)
        elseif now > ent:GetNW2Float(NW.UNTIL, 0) + 1 then
            K.Release(ent)
        elseif not ent:IsPlayer() then
            local vel = K.ComputeVelocity(ent, ent.SHIBI_AirVel or vector_origin, now)
            if vel then
                local pos, newVel = K.Step(ent, ent:GetPos(), vel, engine.TickInterval())
                ent:SetPos(pos)
                ent.SHIBI_AirVel = newVel
            end
        end
    end
end)

hook.Add("GetFallDamage", "SHIBI::Katana::NoFallDamage", function(ply)
    if K.GetMode(ply) ~= MODE.NONE or CurTime() < (ply.SHIBI_NoFallUntil or 0) then return 0 end
end)

hook.Add("SHIBI.Ability.CanCast", "SHIBI::Katana::BlockInAir", function(ply)
    if K.GetMode(ply) ~= MODE.NONE then return false end
end)

hook.Add("PlayerDeath", "SHIBI::Katana::Air", function(dead)
    local partner = dead:GetNW2Entity(NW.PARTNER)
    local isVictim = dead:GetNW2Bool(NW.VICTIM, false)
    local attacker = isVictim and partner or dead

    if IsValid(attacker) and attacker:IsPlayer() then
        local wep = attacker:GetWeapon("weapon_shibi_katana")
        if IsValid(wep) and wep.AirTarget == dead and wep.EndAir then
            wep:EndAir()
        end
    end

    if IsValid(partner) and partner:IsPlayer() then
        K.Clear(partner, true)
        partner:SetVelocity(vector_origin)
    end
    K.Release(dead)
    K.Clear(dead, true)
end)
hook.Add("PlayerSpawn", "SHIBI::Katana::Air", function(ply) K.Release(ply); K.Clear(ply) end)
hook.Add("PlayerDisconnected", "SHIBI::Katana::Air", function(ply) K.Release(ply) end)
hook.Add("PlayerEnteredVehicle", "SHIBI::Katana::Air", function(ply) K.Release(ply) end)
hook.Add("EntityRemoved", "SHIBI::Katana::Air", function(ent)
    if K.Juggled[ent] then K.Release(ent) end
end)

function SWEP:Deploy()
    local ply = self:GetOwner()
    if not IsValid(ply) then return true end
    self.PrimaryBlock = CurTime() + .25
    ply:SetAnim('')
    return true
end

function SWEP:Holster()
    local ply = self:GetOwner()
    if not IsValid(ply) then return true end
    ply:SetAnim('evo_1gn95bkqijik2kxo4')
    return true
end

if SERVER then AddCSLuaFile() end

SWEP.Base = "weapon_base"
SWEP.PrintName = "Саи"
SWEP.Author    = "SHIBI"
SWEP.Category  = "SHIBI"

SWEP.Spawnable = true
SWEP.AdminOnly = false

SWEP.Slot    = 0
SWEP.SlotPos = 2

SWEP.Hands       = "models/weapons/c_arms.mdl"
SWEP.KatanaModel = "models/evo/weapons/hakuda/divers/evo_1562zdeopkhregff/evo_1562zdeopkhregff.mdl"

SWEP.UseHands      = true
SWEP.ViewModel     = SWEP.Hands
SWEP.WorldModel    = SWEP.KatanaModel
SWEP.ViewModelFOV  = 70
SWEP.DrawAmmo      = false
SWEP.DrawCrosshair = false

SWEP.Primary = {
    ClipSize = -1,
    DefaultClip = -1,
    Automatic = true,
    Ammo = "none",
}

SWEP.Secondary = {
    ClipSize = -1,
    DefaultClip = -1,
    Automatic = false,
    Ammo = "none",
}

SWEP.HoldType      = "melee"
SWEP.ShibiHoldType = "sai"

SWEP.Combo = {
    {seq = "kb_shigaraki_attack1", damage = 25, range = 85, angle = 50, punch = {-1.2,  1.6, -1.0}},
    {seq = "kb_shigaraki_attack2", damage = 25, range = 85, angle = 50, punch = {-1.2, -1.6,  1.0}},
    {seq = "m_attack_chainsickle_attract", damage = 40, range = 95, angle = 55, punch = { 2.5,  0.0,  2.0}},
}

SWEP.ComboReset  = 1.5
SWEP.HitTime     = 0.12
SWEP.HitDelay    = 0.44
SWEP.GroundComboCooldown = 0.9
SWEP.HitAnimTime = 0.8

SWEP.HitAnims = {
    f = "enmu_a_p1011_v00_c00_dmg01_f",
    r = "enmu_a_p1011_v00_c00_dmg01_r",
    l = "enmu_a_p1011_v00_c00_dmg01_l",
}

SWEP.Air = {
              
    Range          = 110,
    Cooldown       = 3,
    StaminaCost    = 20,
    LaunchSeq      = "attack_hyuga_11",
    LaunchAnimTime = 0.75,
    LaunchDelay    = 0.12,
    LaunchDamage   = 15,

    RiseTime     = 0.50,
    EntryBlend   = 0.16,
    ExitBlend    = 0.28,
    SlamBlend    = 0.12,
    BumpBlend    = 0.06,
    RiseSpeed    = 820,
    HangTime     = 1.2,
    IdleTimeout  = 2.0,
    ExtendPerHit = 0.55,
    MaxAirTime   = 3.2,
    HangFall     = 0,
    AirDrag      = 10,
    MagnetDist   = 55,
    MagnetSpeed  = 500,
    MinAirGap    = 42,
    SeparateSpeed = 240,

    HitStop   = 0.07,
    BumpTime  = 0.20,
    BumpSpeed = 140,

    HitInterval = 0.30,
    HitDelay    = 0.10,
    AirRange    = 170,
    Hits = {
        {seq = "lanran1_0_battle_attack1_1_base", time = 0.75, damage = 18, punch = {-2.2,  3.0, -3.0}},
        {seq = "lanran1_0_battle_attack1_4_base", time = 0.75, damage = 18, punch = {-2.2, -3.0,  3.0}},
    },

    SlamSeq      = "m_attack_aerial_armhammer",
    SlamAnimTime = 0.75,
    SlamDelay    = 0.15,
    SlamDamage   = 35,
    SlamSpeed    = 1500,
    SlamTimeout  = 1.2,
    SlamGravity  = 1200,
    SlamMaxSpeed = 1800,
    SplashRadius = 120,
    SplashDamage = 20,
    SlamStun     = 0.9,
    KnockdownSeq = "enmu_a_p1011_v00_c00_dmg01_f",

    HitParticle  = "[*]_sword_hit_effect",
    LandParticle = "[*]_stunning_effect",
    ParticleTime = 0.6,
}

SWEP.NWComboUntil = "SHIBI_Katana_ComboUntil"
SWEP.NWAirUntil   = "SHIBI_Katana_AirUntil"

SHIBI.Katana = SHIBI.Katana or {}
local K = SHIBI.Katana

K.Config = SWEP.Air
K.MODE = {NONE = 0, AIR = 1, SLAM = 2}
K.NW = {
    MODE    = "SHIBI::Air::Mode",
    ENTRY   = "SHIBI::Air::EntryVelocity",
    SINCE   = "SHIBI::Air::Since",
    UNTIL   = "SHIBI::Air::Until",
    STOP    = "SHIBI::Air::StopUntil",
    BUMP    = "SHIBI::Air::BumpUntil",
    PARTNER = "SHIBI::Air::Partner",
    VICTIM  = "SHIBI::Air::IsVictim",
}
local NW, MODE = K.NW, K.MODE

function K.GetMode(ent)
    return IsValid(ent) and ent:GetNW2Int(NW.MODE, 0) or 0
end

local function SmoothStep(t)
    t = math.Clamp(t, 0, 1)
    return t * t * (3 - 2 * t)
end

function K.GetPairSeparationVelocity(ent)
    local cfg = K.Config
    local partner = ent:GetNW2Entity(NW.PARTNER)
    if not IsValid(partner) then return vector_origin end

    local away = ent:GetPos() - partner:GetPos()
    away.z = 0
    local dist = away:Length()
    if dist >= cfg.MinAirGap then return vector_origin end
    if dist < 0.01 then
        away = Vector(ent:EntIndex() % 2 == 0 and 1 or -1, 0, 0)
    else
        away:Normalize()
    end
    local strength = (cfg.MinAirGap - dist) / cfg.MinAirGap
    return away * (cfg.SeparateSpeed * strength)
end

function K.ComputeVelocity(ent, vel, now)
    local cfg = K.Config
    local mode = ent:GetNW2Int(NW.MODE, 0)
    if mode == MODE.NONE then return nil end
    if now < ent:GetNW2Float(NW.STOP, 0) then return Vector(0, 0, 0) end

    local dt = engine.TickInterval()
    local since = ent:GetNW2Float(NW.SINCE, now)
    local entryVel = ent:GetNW2Vector(NW.ENTRY, vel)

    if mode == MODE.SLAM then
        local blend = SmoothStep((now - since) / math.max(cfg.SlamBlend, dt))
        local targetDown = -math.min(cfg.SlamSpeed + math.max(now - since - cfg.SlamBlend, 0) * cfg.SlamGravity, cfg.SlamMaxSpeed)
        local slamVel = LerpVector(blend, entryVel, Vector(0, 0, targetDown))
        slamVel = slamVel + K.GetPairSeparationVelocity(ent)
        return slamVel
    end

    local untilTime = ent:GetNW2Float(NW.UNTIL, 0)
    if now > untilTime then
                                                                                   
        local exitProgress = (now - untilTime) / math.max(cfg.ExitBlend, dt)
        if exitProgress >= 1 then return nil end
        local gravity = GetConVar("sv_gravity")
        gravity = gravity and gravity:GetFloat() or 600
        local naturalVel = Vector(vel.x, vel.y, math.max(vel.z - gravity * dt, -2000))
        return LerpVector(SmoothStep(exitProgress), vel, naturalVel)
    end

    local drag = math.exp(-cfg.AirDrag * dt)
    local out = Vector(vel.x * drag, vel.y * drag, 0)
    local t = now - since

    if t < cfg.RiseTime then

        local riseProgress = math.Clamp(t / cfg.RiseTime, 0, 1)
        out.z = 3 * cfg.RiseSpeed * riseProgress * (1 - riseProgress)
    else

        out.z = 0
    end

    if not ent:GetNW2Bool(NW.VICTIM, false) then
        local partner = ent:GetNW2Entity(NW.PARTNER)
        if IsValid(partner) then
            local to = partner:GetPos() - ent:GetPos()
            to.z = 0
            local dist = to:Length()
            if dist > cfg.MagnetDist then
                to:Normalize()
                out = out + to * math.min(cfg.MagnetSpeed, (dist - cfg.MagnetDist) * 12)
            end
        end
    end

    local entryBlend = SmoothStep((now - since) / math.max(cfg.EntryBlend, dt))
    out = LerpVector(entryBlend, entryVel, out)

    out = out + K.GetPairSeparationVelocity(ent)
    return out
end

local function GetHullFor(ent)
    if ent:IsPlayer() then
        if ent:Crouching() then return ent:GetHullDuck() end
        return ent:GetHull()
    end
    return ent:OBBMins(), ent:OBBMaxs()
end

local function Hull(ent, from, to, mins, maxs)
    return util.TraceHull({
        start = from, endpos = to, mins = mins, maxs = maxs,
        mask = MASK_PLAYERSOLID,
        filter = {ent, ent:GetNW2Entity(NW.PARTNER)},
    })
end

function K.NudgeApart(attacker, victim)
    if not (IsValid(attacker) and attacker:IsPlayer() and attacker:Alive()
        and IsValid(victim)) then return false end

    local gap = K.Config.MinAirGap
    local away = attacker:GetPos() - victim:GetPos()
    away.z = 0
    local dist = away:Length()
    if dist >= math.min(gap, 28) then return false end

    if dist < 0.01 then
        away = attacker:EyeAngles():Right()
        away.z = 0
        if away:LengthSqr() < 0.01 then away = Vector(1, 0, 0) end
    end
    away:Normalize()

    local mins, maxs = GetHullFor(attacker)
    local filter = {attacker, victim}
    if victim:IsPlayer() then
        local ragdoll = victim:GetRagdollEntity()
        if IsValid(ragdoll) then filter[#filter + 1] = ragdoll end
    end

    local candidates = {away, attacker:EyeAngles():Right(), -attacker:EyeAngles():Right()}
    for _, dir in ipairs(candidates) do
        dir.z = 0
        if dir:LengthSqr() > 0.001 then
            dir:Normalize()
            local tr = util.TraceHull({
                start = attacker:GetPos(),
                endpos = attacker:GetPos() + dir * 32,
                mins = mins,
                maxs = maxs,
                mask = MASK_PLAYERSOLID,
                filter = filter,
            })
            if not tr.StartSolid and not tr.Hit then
                attacker:SetVelocity(dir * 72)
                return true
            end
        end
    end
    return false
end

function K.Step(ent, origin, vel, dt)
    local mins, maxs = GetHullFor(ent)
    local target = origin + vel * dt
    local tr = Hull(ent, origin, target, mins, maxs)
    if tr.StartSolid then return origin, vel end
    if not tr.Hit then return tr.HitPos, vel end

    local n = tr.HitNormal
    vel = vel - n * vel:Dot(n)
    local rest = target - tr.HitPos
    rest = rest - n * rest:Dot(n)
    return Hull(ent, tr.HitPos, tr.HitPos + rest, mins, maxs).HitPos, vel
end

function K.IsLanded(ent)
    local mins, maxs = GetHullFor(ent)
    local pos = ent:GetPos()
    local tr = Hull(ent, pos, pos - Vector(0, 0, 6), mins, maxs)
    return tr.Hit and tr.HitNormal.z > 0.7
end

hook.Add("Move", "SHIBI::Katana::AirMove", function(ply, mv)
    if ply:GetNW2Int(NW.MODE, 0) == MODE.NONE then return end
    local vel = K.ComputeVelocity(ply, mv:GetVelocity(), CurTime())
    if not vel then return end

    local pos, newVel = K.Step(ply, mv:GetOrigin(), vel, FrameTime())
    mv:SetOrigin(pos)
    mv:SetVelocity(newVel)
    return true
end)

hook.Add("SetupMove", "SHIBI::Katana::SpaceLock", function(ply, mv)
    if ply:GetMoveType() == MOVETYPE_NOCLIP then return end

    local busy = ply:GetNW2Int(NW.MODE, 0) ~= MODE.NONE
    if not busy then
        local wep = ply:GetActiveWeapon()
        if not IsValid(wep) or wep:GetClass() ~= "weapon_shibi_katana" then return end
        local now = CurTime()
        busy = ply:KeyDown(IN_ATTACK)
            or wep:GetNW2Float("SHIBI_Katana_ComboUntil", 0) > now
            or wep:GetNW2Float("SHIBI_Katana_AirUntil", 0) > now
    end
    if not busy then return end

    mv:SetButtons(bit.band(mv:GetButtons(), bit.bnot(IN_JUMP)))
end)

function SWEP:Initialize()
    self:SetHoldType(self.HoldType)
    self.ComboIndex = 1
    self.ComboHits  = 0
    self.LastAttack = 0
    self.AirHits    = 0
end

function SWEP:Deploy()
    self:SetHoldType(self.HoldType)
    self.ComboIndex = 1
    self.ComboHits  = 0
    self.LastAttack = 0
    if SERVER then self:EndAir() end
    return true
end

local function CanAct(ply)
                                       
    return IsValid(ply) and ply:Alive() and not ply:GetNW2Bool(NW.VICTIM, false)
end

function SWEP:PrimaryAttack()
    local ply = self:GetOwner()
    if not CanAct(ply) then return end

    local inAir = K.GetMode(ply) == MODE.AIR
                                                                                        
    self:SetNextPrimaryFire(CurTime() + (inAir and self.Air.HitInterval or self.HitDelay))
    if CLIENT then return end

    if inAir then self:AirAttack(ply) else self:GroundAttack(ply) end
end

function SWEP:SecondaryAttack()
    local ply = self:GetOwner()
    if not CanAct(ply) then return end

    local inAir = K.GetMode(ply) == MODE.AIR
    self:SetNextSecondaryFire(CurTime() + (inAir and self.Air.HitInterval or 0.3))
    if CLIENT then return end

    if inAir then self:StartSlam(ply) else self:TryLaunch(ply) end
end

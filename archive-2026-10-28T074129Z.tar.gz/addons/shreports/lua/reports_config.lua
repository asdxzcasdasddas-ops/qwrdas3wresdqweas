   
                       
   


SH_REPORTS.Usergroups = {
	["admin"] = true,
	["superadmin"] = true,
	["moderateur"] = true,
	["animateur"] = true,
}


SH_REPORTS.UsergroupsPerformance = {
	["superadmin"] = true,
	["owner"] = true,
}



SH_REPORTS.ReportReasons = {
	"Freekill",
	"NoRP",
	"Bug",
	"NoFear/NoPain",
	"Question",
}


SH_REPORTS.MaxReportsPerPlayer = 1


SH_REPORTS.NewReportSound = {
	enabled = true,
	path = Sound("buttons/button16.wav"),
}



SH_REPORTS.UseServerLog = true


SH_REPORTS.StaffCanReport = true


SH_REPORTS.StaffCanBeReported = true


SH_REPORTS.CanDeleteWhenUnclaimed = true


SH_REPORTS.NotifyAdminsOnConnect = true



SH_REPORTS.CanReportOther = true


SH_REPORTS.UseULXCommands = false


SH_REPORTS.ReportKey = KEY_F9


SH_REPORTS.ReportsKey = KEY_F11


SH_REPORTS.AskRating = false


SH_REPORTS.NotifyRating = true


SH_REPORTS.TeleportPlayersBack = false


SH_REPORTS.PendingReportsDispNumber = 3



SH_REPORTS.ClaimNoTeleport = false



SH_REPORTS.UseWorkshop = false

   
                       
   



SH_REPORTS.AdminCommands = {
	["/reports"] = true,
	["/reportlist"] = true,
}



SH_REPORTS.ReportCommands = {
	["/report"] = true,
	["///"] = true,
}





SH_REPORTS.EnableQuickReport = true

   
                                   
   





SH_REPORTS.DatabaseMode = "sqlite"



SH_REPORTS.PerformanceFrequency = "weekly"










SH_REPORTS.PerformanceWeekDay = 1


SH_REPORTS.AdminReportsCount = false

   
                       
   





SH_REPORTS.StoreCompletedReports = "sqlite"





SH_REPORTS.StorageExpiryTime = 86400 * 7

   
                        
                        
   

SH_REPORTS.MaxCommentLength = 2048

SH_REPORTS.DateFormat = "%Y/%m/%d"

SH_REPORTS.TimeFormat = "%Y/%m/%d %H:%M:%S"




SH_REPORTS.ReasonAutoTarget = {
	["RDM"] = "killer",
	["RDA"] = "arrester",
}

   
                     
   


SH_REPORTS.Font = "Circular Std Medium"


SH_REPORTS.FontBold = "Circular Std Bold"


SH_REPORTS.Style = {
	header = Color(52, 152, 219, 255),
	bg = Color(52, 73, 94, 255),
	inbg = Color(44, 62, 80, 255),

	close_hover = Color(231, 76, 60, 255),
	hover = Color(255, 255, 255, 10, 255),
	hover2 = Color(255, 255, 255, 5, 255),

	text = Color(255, 255, 255, 255),
	text_down = Color(0, 0, 0),
	textentry = Color(44, 62, 80),
	menu = Color(127, 140, 141),

	success = Color(46, 204, 113),
	failure = Color(231, 76, 60),
	rating = Color(241, 196, 15),
}

   
                        
   





SH_REPORTS.LanguageName = "french"

 